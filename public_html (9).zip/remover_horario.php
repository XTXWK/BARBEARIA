<?php
include("config.php");

$id = $_POST['id'] ?? 0;
$senha_admin = $_POST['senha'] ?? '';
$senha_correta = 'admin123';

if ($senha_admin !== $senha_correta) {
    die(json_encode(['success' => false, 'message' => 'Senha incorreta']));
}

$conn = new mysqli($db_host, $db_user, $db_password, $db_name);

if ($conn->connect_error) {
    die(json_encode(['success' => false, 'message' => 'Erro de conexão']));
}

// Verificar se o horário está disponível (não pode remover horários reservados ou pagos)
$sql = "SELECT status FROM horarios WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$horario = $result->fetch_assoc();

if (!$horario) {
    die(json_encode(['success' => false, 'message' => 'Horário não encontrado']));
}

if ($horario['status'] !== 'disponivel') {
    die(json_encode(['success' => false, 'message' => 'Não é possível remover um horário reservado ou pago']));
}

$sql = "DELETE FROM horarios WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id);

if ($stmt->execute()) {
    echo json_encode(['success' => true, 'message' => 'Horário removido com sucesso']);
} else {
    echo json_encode(['success' => false, 'message' => 'Erro ao remover horário']);
}

$conn->close();
?>
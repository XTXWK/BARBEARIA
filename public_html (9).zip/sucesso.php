<?php
// Página de sucesso após pagamento aprovado
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Agendamento Confirmado - Thomaz Black Barbearia</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;700;900&family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Inter', sans-serif;
            background: #0a0a0a;
            color: #fff;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        
        .success-container {
            max-width: 620px;
            width: 100%;
            background: rgba(26, 26, 26, 0.92);
            backdrop-filter: blur(20px);
            border-radius: 24px;
            padding: 50px 40px;
            border: 1px solid rgba(201, 168, 76, 0.15);
            box-shadow: 0 30px 60px rgba(0, 0, 0, 0.5);
            text-align: center;
            position: relative;
            overflow: hidden;
        }
        
        .success-container::before {
            content: '';
            position: absolute;
            top: -50%;
            left: -50%;
            width: 200%;
            height: 200%;
            background: radial-gradient(circle at 30% 50%, rgba(201, 168, 76, 0.03) 0%, transparent 60%);
            animation: glow 20s ease-in-out infinite;
        }
        
        @keyframes glow {
            0%, 100% { transform: translate(0, 0); }
            50% { transform: translate(10%, 5%); }
        }
        
        .success-container > * {
            position: relative;
            z-index: 2;
        }
        
        .success-icon {
            font-size: 5em;
            color: #28a745;
            animation: scaleUp 0.6s ease;
            margin-bottom: 15px;
        }
        
        @keyframes scaleUp {
            0% { transform: scale(0); }
            100% { transform: scale(1); }
        }
        
        .success-title {
            font-family: 'Playfair Display', serif;
            font-size: 2.2em;
            font-weight: 900;
            color: #c9a84c;
            margin-bottom: 8px;
        }
        
        .success-subtitle {
            color: #888;
            font-size: 1em;
            margin-bottom: 25px;
        }
        
        /* === ALERTA DE CANCELAMENTO === */
        .cancel-alert {
            background: rgba(255, 193, 7, 0.06);
            border: 1px solid rgba(255, 193, 7, 0.12);
            border-radius: 12px;
            padding: 14px 20px;
            margin: 15px 0 20px;
            display: flex;
            align-items: flex-start;
            gap: 14px;
            text-align: left;
        }
        
        .cancel-alert .alert-icon {
            font-size: 1.4em;
            color: #ffc107;
            flex-shrink: 0;
            margin-top: 2px;
        }
        
        .cancel-alert .alert-content {
            font-size: 0.85em;
            line-height: 1.6;
        }
        
        .cancel-alert .alert-content .alert-title {
            color: #ffc107;
            font-weight: 700;
            font-size: 0.95em;
            display: block;
            margin-bottom: 2px;
        }
        
        .cancel-alert .alert-content .highlight {
            color: #ffc107;
            font-weight: 700;
        }
        
        .cancel-alert .alert-content .highlight-50 {
            color: #ff6b6b;
            font-weight: 700;
            font-size: 1.1em;
        }
        
        .cancel-alert .alert-content .small-text {
            color: #666;
            font-size: 0.85em;
            margin-top: 4px;
            display: block;
        }
        
        .success-card {
            background: rgba(13, 13, 13, 0.6);
            border-radius: 16px;
            padding: 25px;
            margin: 20px 0;
            text-align: left;
            border: 1px solid #2d2d2d;
        }
        
        .success-card .row {
            display: flex;
            justify-content: space-between;
            padding: 8px 0;
            border-bottom: 1px solid rgba(255,255,255,0.04);
        }
        
        .success-card .row:last-child {
            border-bottom: none;
        }
        
        .success-card .row .label {
            color: #666;
            font-size: 0.85em;
        }
        
        .success-card .row .value {
            color: #c9a84c;
            font-weight: 600;
            font-size: 0.9em;
        }
        
        .success-card .row.total .value {
            color: #28a745;
            font-size: 1.2em;
        }
        
        .success-actions {
            display: flex;
            gap: 15px;
            margin-top: 25px;
            flex-wrap: wrap;
            justify-content: center;
        }
        
        .btn {
            padding: 12px 30px;
            border-radius: 10px;
            font-weight: 600;
            font-size: 0.9em;
            cursor: pointer;
            transition: all 0.3s;
            text-decoration: none;
            display: inline-block;
            font-family: 'Inter', sans-serif;
        }
        
        .btn-primary {
            background: linear-gradient(135deg, #c9a84c, #a8893a);
            color: #0a0a0a;
            border: none;
        }
        
        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 30px rgba(201, 168, 76, 0.3);
        }
        
        .btn-secondary {
            background: #2d2d2d;
            color: #fff;
            border: 1px solid #444;
        }
        
        .btn-secondary:hover {
            background: #3d3d3d;
        }
        
        .btn-success {
            background: #28a745;
            color: #fff;
            border: none;
        }
        
        .btn-success:hover {
            background: #218838;
            transform: translateY(-2px);
        }
        
        .referencia {
            color: #444;
            font-size: 0.7em;
            margin-top: 20px;
            padding: 10px;
            background: rgba(0,0,0,0.3);
            border-radius: 8px;
            line-height: 1.8;
        }
        
        .referencia strong {
            color: #666;
        }
        
        /* BADGE DE CONFIRMAÇÃO */
        .confirmation-badge {
            display: inline-block;
            background: rgba(40, 167, 69, 0.12);
            color: #28a745;
            padding: 4px 18px;
            border-radius: 30px;
            font-size: 0.75em;
            font-weight: 600;
            border: 1px solid rgba(40, 167, 69, 0.1);
            margin-bottom: 15px;
            letter-spacing: 1px;
        }
        
        @media (max-width: 480px) {
            .success-container {
                padding: 30px 18px;
            }
            
            .success-title {
                font-size: 1.6em;
            }
            
            .success-icon {
                font-size: 3.5em;
            }
            
            .btn {
                width: 100%;
                text-align: center;
            }
            
            .success-card .row {
                flex-direction: column;
                align-items: flex-start;
                gap: 2px;
            }
            
            .cancel-alert {
                flex-direction: column;
                align-items: center;
                text-align: center;
                padding: 16px;
            }
            
            .cancel-alert .alert-icon {
                font-size: 1.8em;
            }
        }
    </style>
</head>
<body>
    <div class="success-container">
        <!-- Ícone -->
        <div class="success-icon">
            <i class="fas fa-check-circle"></i>
        </div>
        
        <!-- Badge -->
        <div class="confirmation-badge">
            <i class="fas fa-check"></i> CONFIRMADO
        </div>
        
        <!-- Títulos -->
        <h1 class="success-title">Agendamento Confirmado!</h1>
        <p class="success-subtitle">Seu horário foi agendado com sucesso. Aguardamos você!</p>
        
        <!-- === ALERTA DE CANCELAMENTO === -->
        <div class="cancel-alert">
            <div class="alert-icon">
                <i class="fas fa-exclamation-triangle"></i>
            </div>
            <div class="alert-content">
                <span class="alert-title">📌 Política de Cancelamento</span>
                Em caso de cancelamento, apenas <span class="highlight-50">50%</span> do valor pago será reembolsado.
                <span class="small-text">
                    <i class="fas fa-info-circle" style="color:#666;"></i> 
                    Cancelamentos devem ser feitos com antecedência mínima de 2 horas.
                </span>
            </div>
        </div>
        
        <!-- Detalhes do Agendamento -->
        <div class="success-card">
            <div class="row">
                <span class="label">👨‍🦱 Barbeiro</span>
                <span class="value"><?php echo htmlspecialchars($_GET['barbeiro'] ?? '—'); ?></span>
            </div>
            <div class="row">
                <span class="label">💇 Serviço</span>
                <span class="value"><?php echo htmlspecialchars($_GET['servico'] ?? '—'); ?></span>
            </div>
            <div class="row">
                <span class="label">📅 Data</span>
                <span class="value"><?php 
                    $data = $_GET['data'] ?? '';
                    if ($data) {
                        $partes = explode('-', $data);
                        $meses = ['Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho', 
                                  'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro'];
                        echo $partes[2] . ' de ' . $meses[(int)$partes[1]-1] . ' de ' . $partes[0];
                    } else {
                        echo '—';
                    }
                ?></span>
            </div>
            <div class="row">
                <span class="label">⏰ Horário</span>
                <span class="value"><?php echo htmlspecialchars($_GET['horario'] ?? '—'); ?></span>
            </div>
            <div class="row total">
                <span class="label">💰 Valor Pago</span>
                <span class="value">R$ <?php echo number_format((float)($_GET['valor'] ?? 0), 2, ',', '.'); ?></span>
            </div>
            <div class="row">
                <span class="label">👤 Cliente</span>
                <span class="value"><?php echo htmlspecialchars($_GET['nome'] ?? '—'); ?></span>
            </div>
            <div class="row">
                <span class="label">📧 Email</span>
                <span class="value"><?php echo htmlspecialchars($_GET['email'] ?? '—'); ?></span>
            </div>
        </div>
        
        <!-- Mensagem adicional -->
        <div style="color: #666; font-size: 0.85em; margin: 15px 0; line-height: 1.6;">
            <i class="fas fa-info-circle" style="color: #c9a84c;"></i>
            Chegue 10 minutos antes do horário agendado. 
            Em caso de imprevistos, entre em contato pelo <strong style="color:#aaa;">(27) 99747-9413</strong>.
        </div>
        
        <!-- Ações -->
        <div class="success-actions">
            <a href="index.html" class="btn btn-primary">
                <i class="fas fa-home"></i> Voltar para o início
            </a>
            <a href="index.html#agendar" class="btn btn-secondary">
                <i class="fas fa-calendar-plus"></i> Novo Agendamento
            </a>
        </div>
        
        <!-- Referência do pagamento -->
        <div class="referencia">
            <strong>Referência:</strong> #<?php echo htmlspecialchars($_GET['referencia'] ?? 'N/A'); ?>
            <br>
            <span style="color: #333;">Agendamento confirmado em <?php echo date('d/m/Y H:i:s'); ?></span>
        </div>
    </div>
</body>
</html>
<?php
include("../config.php");

header('Content-Type: application/json');

$barbeiro_id = $_POST['barbeiro_id'] ?? 0;

if (!$barbeiro_id) {
    echo json_encode(['error' => 'Barbeiro não informado']);
    exit;
}

$conn = new mysqli($db_host, $db_user, $db_password, $db_name);

if ($conn->connect_error) {
    echo json_encode(['error' => 'Erro de conexão: ' . $conn->connect_error]);
    exit;
}

// 🔥 Buscar serviços SEM verificar sessão
$sql = "SELECT * FROM servicos_barbeiro WHERE barbeiro_id = ? AND ativo = 1 ORDER BY nome";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $barbeiro_id);
$stmt->execute();
$result = $stmt->get_result();

$servicos = [];
while ($row = $result->fetch_assoc()) {
    $servicos[] = $row;
}

$conn->close();

echo json_encode($servicos);
?>
<?php
session_start();
include("../config.php");

// Verificar se está logado
if (!isset($_SESSION['barbeiro_id'])) {
    echo json_encode(['success' => false, 'message' => 'Não autenticado']);
    exit;
}

$barbeiro_id = $_SESSION['barbeiro_id'];

if (!isset($_POST['id']) || empty($_POST['id'])) {
    echo json_encode(['success' => false, 'message' => 'ID do agendamento não informado']);
    exit;
}

$id = intval($_POST['id']);

$conn = new mysqli($db_host, $db_user, $db_password, $db_name);

if ($conn->connect_error) {
    echo json_encode(['success' => false, 'message' => 'Erro de conexão: ' . $conn->connect_error]);
    exit;
}

// Verificar se o agendamento pertence ao barbeiro
$sql = "SELECT id, status FROM horarios WHERE id = ? AND barbeiro_id = ? AND status NOT IN ('cancelado', 'concluido')";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ii", $id, $barbeiro_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    echo json_encode(['success' => false, 'message' => 'Agendamento não encontrado ou já foi concluído/cancelado']);
    $conn->close();
    exit;
}

// Cancelar
$sql = "UPDATE horarios SET status = 'cancelado' WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id);

if ($stmt->execute()) {
    echo json_encode(['success' => true, 'message' => 'Agendamento cancelado com sucesso!']);
} else {
    echo json_encode(['success' => false, 'message' => 'Erro ao cancelar: ' . $conn->error]);
}

$conn->close();
?>
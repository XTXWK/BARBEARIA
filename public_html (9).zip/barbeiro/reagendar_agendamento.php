<?php
session_start();
include("../config.php");

// Verificar se está logado
if (!isset($_SESSION['barbeiro_id'])) {
    echo json_encode(['success' => false, 'message' => 'Não autenticado']);
    exit;
}

$barbeiro_id = $_SESSION['barbeiro_id'];

if (!isset($_POST['id']) || empty($_POST['id'])) {
    echo json_encode(['success' => false, 'message' => 'ID do agendamento não informado']);
    exit;
}

if (!isset($_POST['data']) || empty($_POST['data'])) {
    echo json_encode(['success' => false, 'message' => 'Nova data não informada']);
    exit;
}

if (!isset($_POST['horario']) || empty($_POST['horario'])) {
    echo json_encode(['success' => false, 'message' => 'Novo horário não informado']);
    exit;
}

$id = intval($_POST['id']);
$nova_data = $_POST['data'];
$novo_horario = $_POST['horario'];
$motivo = isset($_POST['motivo']) ? trim($_POST['motivo']) : '';

$conn = new mysqli($db_host, $db_user, $db_password, $db_name);

if ($conn->connect_error) {
    echo json_encode(['success' => false, 'message' => 'Erro de conexão: ' . $conn->connect_error]);
    exit;
}

// Verificar se o agendamento pertence ao barbeiro e está pago
$sql = "SELECT id, status FROM horarios WHERE id = ? AND barbeiro_id = ? AND status = 'pago'";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ii", $id, $barbeiro_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    echo json_encode(['success' => false, 'message' => 'Agendamento não encontrado ou não pode ser reagendado']);
    $conn->close();
    exit;
}

// Verificar se o novo horário está disponível
$sql = "SELECT id FROM horarios 
        WHERE barbeiro_id = ? AND data = ? AND horario = ? AND status = 'disponivel' 
        AND id != ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("issi", $barbeiro_id, $nova_data, $novo_horario, $id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    echo json_encode(['success' => false, 'message' => 'Horário indisponível para reagendamento']);
    $conn->close();
    exit;
}

// Liberar o horário antigo
$sql_antigo = "SELECT data, horario FROM horarios WHERE id = ?";
$stmt = $conn->prepare($sql_antigo);
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$antigo = $result->fetch_assoc();

// Atualizar o horário antigo para disponível
if ($antigo) {
    $sql = "UPDATE horarios SET status = 'disponivel', cliente_id = NULL, servico_id = NULL, preco = NULL, observacoes = NULL WHERE data = ? AND horario = ? AND barbeiro_id = ? AND status = 'pago'";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssi", $antigo['data'], $antigo['horario'], $barbeiro_id);
    $stmt->execute();
}

// Reservar o novo horário com os dados do cliente
$sql = "UPDATE horarios h
        JOIN (
            SELECT cliente_id, servico_id, preco, observacoes 
            FROM horarios 
            WHERE id = ? AND barbeiro_id = ?
        ) AS dados ON 1=1
        SET h.status = 'pago',
            h.cliente_id = dados.cliente_id,
            h.servico_id = dados.servico_id,
            h.preco = dados.preco,
            h.observacoes = CONCAT(
                IFNULL(dados.observacoes, ''),
                IF(? != '', CONCAT(' [REAGENDADO] Motivo: ', ?), '')
            ),
            h.data = ?,
            h.horario = ?
        WHERE h.id = ? AND h.barbeiro_id = ?";

$stmt = $conn->prepare($sql);
$stmt->bind_param("iisssii", $id, $barbeiro_id, $motivo, $motivo, $nova_data, $novo_horario, $id, $barbeiro_id);

if ($stmt->execute()) {
    // Remover o horário antigo que foi marcado como disponível (se não estiver sendo usado)
    echo json_encode(['success' => true, 'message' => 'Agendamento reagendado com sucesso!']);
} else {
    echo json_encode(['success' => false, 'message' => 'Erro ao reagendar: ' . $conn->error]);
}

$conn->close();
?>
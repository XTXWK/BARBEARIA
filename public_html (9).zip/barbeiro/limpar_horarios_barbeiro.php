<?php
session_start();
include("../config.php");

header('Content-Type: application/json');

if (!isset($_SESSION['barbeiro_id'])) {
    echo json_encode(['success' => false, 'message' => 'Não autenticado']);
    exit;
}

$barbeiro_id = $_SESSION['barbeiro_id'];
$data = $_POST['data'] ?? '';

if (!$data) {
    echo json_encode(['success' => false, 'message' => 'Data não informada']);
    exit;
}

$conn = new mysqli($db_host, $db_user, $db_password, $db_name);

if ($conn->connect_error) {
    echo json_encode(['success' => false, 'message' => 'Erro de conexão: ' . $conn->connect_error]);
    exit;
}

$sql = "DELETE FROM horarios WHERE data = ? AND barbeiro_id = ? AND status = 'disponivel'";
$stmt = $conn->prepare($sql);
$stmt->bind_param("si", $data, $barbeiro_id);

if ($stmt->execute()) {
    $count = $stmt->affected_rows;
    echo json_encode(['success' => true, 'message' => "$count horário(s) removido(s)"]);
} else {
    echo json_encode(['success' => false, 'message' => 'Erro ao remover horários: ' . $conn->error]);
}

$conn->close();
?>
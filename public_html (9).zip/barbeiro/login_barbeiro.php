<?php
session_start();
include("../config.php");

$erro = '';

if ($_POST['email'] ?? '') {
    $email = $_POST['email'];
    $senha = md5($_POST['senha']);
    
    $conn = new mysqli($db_host, $db_user, $db_password, $db_name);
    
    if ($conn->connect_error) {
        $erro = "Erro de conexão";
    } else {
        $sql = "SELECT * FROM barbeiros WHERE email = ? AND senha = ? AND ativo = 1";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ss", $email, $senha);
        $stmt->execute();
        $result = $stmt->get_result();
        $barbeiro = $result->fetch_assoc();
        
        if ($barbeiro) {
            $_SESSION['barbeiro_id'] = $barbeiro['id'];
            $_SESSION['barbeiro_nome'] = $barbeiro['nome'];
            $_SESSION['barbeiro_email'] = $barbeiro['email'];
            header('Location: dashboard_barbeiro.php');
            exit;
        } else {
            $erro = "Email ou senha incorretos";
        }
        $conn->close();
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Barbeiro - Barbearia</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { 
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #1a1a1a;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            color: #fff;
        }
        .login-box {
            background: #2d2d2d;
            padding: 40px;
            border-radius: 12px;
            border: 1px solid #3d3d3d;
            max-width: 400px;
            width: 90%;
        }
        .login-box h1 {
            color: #c9a84c;
            text-align: center;
            margin-bottom: 10px;
        }
        .login-box p {
            color: #aaa;
            text-align: center;
            margin-bottom: 30px;
        }
        .login-box input {
            width: 100%;
            padding: 12px;
            border-radius: 6px;
            border: 1px solid #444;
            background: #1a1a1a;
            color: #fff;
            font-size: 1em;
            margin-bottom: 15px;
        }
        .login-box input:focus {
            outline: none;
            border-color: #c9a84c;
        }
        .login-box button {
            width: 100%;
            padding: 12px;
            background: #c9a84c;
            color: #1a1a1a;
            border: none;
            border-radius: 6px;
            font-weight: bold;
            font-size: 1em;
            cursor: pointer;
            transition: all 0.3s;
        }
        .login-box button:hover {
            background: #dbb95c;
        }
        .erro {
            background: #f8d7da;
            color: #721c24;
            padding: 10px;
            border-radius: 6px;
            margin-bottom: 15px;
            text-align: center;
        }
        .voltar {
            display: block;
            text-align: center;
            margin-top: 15px;
            color: #666;
            text-decoration: none;
        }
        .voltar:hover {
            color: #c9a84c;
        }
    </style>
</head>
<body>
    <div class="login-box">
        <h1>✂️ Barbearia</h1>
        <p>Login do Barbeiro</p>
        <?php if ($erro): ?>
            <div class="erro">❌ <?php echo $erro; ?></div>
        <?php endif; ?>
        <form method="POST">
            <input type="email" name="email" placeholder="Seu email" required>
            <input type="password" name="senha" placeholder="Sua senha" required>
            <button type="submit">🔐 Entrar</button>
        </form>
        <a href="../index.html" class="voltar">← Voltar para agendamento</a>
        <p style="color: #666; font-size: 0.8em; margin-top: 15px;">
            Padrão: ze@barbearia.com / barbeiro123
        </p>
    </div>
</body>
</html>
<?php
session_start();
include("../config.php");

header('Content-Type: application/json');

if (!isset($_SESSION['barbeiro_id'])) {
    echo json_encode(['error' => 'Não autenticado']);
    exit;
}

$barbeiro_id = $_SESSION['barbeiro_id'];
$data = $_POST['data'] ?? date('Y-m-d');

$conn = new mysqli($db_host, $db_user, $db_password, $db_name);

if ($conn->connect_error) {
    echo json_encode(['error' => 'Erro de conexão: ' . $conn->connect_error]);
    exit;
}

$sql = "SELECT h.*, 
        s.nome as servico_nome,
        s.preco as servico_preco,
        s.duracao_minutos as servico_duracao
        FROM horarios h
        LEFT JOIN servicos_barbeiro s ON h.servico_id = s.id
        WHERE h.barbeiro_id = ? AND h.data = ?
        ORDER BY h.horario ASC";

$stmt = $conn->prepare($sql);
$stmt->bind_param("is", $barbeiro_id, $data);
$stmt->execute();
$result = $stmt->get_result();

$horarios = [];
while ($row = $result->fetch_assoc()) {
    $row['horario_formatado'] = substr($row['horario'], 0, 5);
    
    $status_labels = [
        'disponivel' => 'Disponível',
        'reservado' => 'Reservado',
        'pago' => 'Confirmado',
        'cancelado' => 'Cancelado'
    ];
    $row['status_label'] = $status_labels[$row['status']] ?? $row['status'];
    
    $status_classes = [
        'disponivel' => 'status-disponivel',
        'reservado' => 'status-reservado',
        'pago' => 'status-pago',
        'cancelado' => 'status-cancelado'
    ];
    $row['status_class'] = $status_classes[$row['status']] ?? '';
    
    $horarios[] = $row;
}

$conn->close();

echo json_encode([
    'success' => true,
    'data' => $data,
    'data_formatada' => date('d/m/Y', strtotime($data)),
    'total' => count($horarios),
    'horarios' => $horarios
]);
?>
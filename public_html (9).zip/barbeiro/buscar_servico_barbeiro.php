<?php
session_start();
include("../config.php");

header('Content-Type: application/json');

if (!isset($_SESSION['barbeiro_id'])) {
    echo json_encode(['error' => 'Não autenticado']);
    exit;
}

$barbeiro_id = $_SESSION['barbeiro_id'];
$id = $_POST['id'] ?? 0;

if (!$id) {
    echo json_encode(['error' => 'ID não informado']);
    exit;
}

$conn = new mysqli($db_host, $db_user, $db_password, $db_name);

if ($conn->connect_error) {
    echo json_encode(['error' => 'Erro de conexão: ' . $conn->connect_error]);
    exit;
}

$sql = "SELECT * FROM servicos_barbeiro WHERE id = ? AND barbeiro_id = ? AND ativo = 1";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ii", $id, $barbeiro_id);
$stmt->execute();
$result = $stmt->get_result();
$servico = $result->fetch_assoc();

$conn->close();

if (!$servico) {
    echo json_encode(['error' => 'Serviço não encontrado']);
    exit;
}

echo json_encode($servico);
?>
<?php
session_start();
include("../config.php");

header('Content-Type: application/json');

if (!isset($_SESSION['barbeiro_id'])) {
    echo json_encode(['success' => false, 'message' => 'Não autenticado']);
    exit;
}

$barbeiro_id = $_SESSION['barbeiro_id'];
$data = $_POST['data'] ?? '';
$horarios_input = $_POST['horarios'] ?? '';

if (!$data || !$horarios_input) {
    echo json_encode(['success' => false, 'message' => 'Dados incompletos']);
    exit;
}

$conn = new mysqli($db_host, $db_user, $db_password, $db_name);

if ($conn->connect_error) {
    echo json_encode(['success' => false, 'message' => 'Erro de conexão: ' . $conn->connect_error]);
    exit;
}

// Processar horários
$horarios = array_map('trim', explode(',', $horarios_input));
$horarios = array_filter($horarios);

if (empty($horarios)) {
    echo json_encode(['success' => false, 'message' => 'Nenhum horário válido']);
    exit;
}

$inserted = 0;
$errors = [];
$success = [];

foreach ($horarios as $horario) {
    if (!preg_match('/^(\d{1,2}):(\d{2})$/', $horario, $matches)) {
        $errors[] = "Horário '$horario' inválido (use HH:MM)";
        continue;
    }
    
    $hora = str_pad($matches[1], 2, '0', STR_PAD_LEFT);
    $minuto = $matches[2];
    $horario_completo = "$hora:$minuto:00";
    
    // Verificar se já existe
    $sql = "SELECT id FROM horarios WHERE data = ? AND horario = ? AND barbeiro_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssi", $data, $horario_completo, $barbeiro_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        $errors[] = "Horário $horario já existe para esta data";
        continue;
    }
    
    $sql = "INSERT INTO horarios (data, horario, barbeiro_id, status) VALUES (?, ?, ?, 'disponivel')";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssi", $data, $horario_completo, $barbeiro_id);
    
    if ($stmt->execute()) {
        $inserted++;
        $success[] = $horario;
    } else {
        $errors[] = "Erro ao inserir $horario: " . $conn->error;
    }
}

$conn->close();

echo json_encode([
    'success' => $inserted > 0,
    'message' => "$inserted horário(s) adicionado(s) para $data",
    'success_list' => $success,
    'errors' => $errors
]);
?>
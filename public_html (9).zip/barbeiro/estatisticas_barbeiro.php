<?php
session_start();
include("../config.php");

// Verificar se está logado
if (!isset($_SESSION['barbeiro_id'])) {
    echo json_encode(['success' => false, 'error' => 'Não autenticado']);
    exit;
}

$barbeiro_id = $_SESSION['barbeiro_id'];
$hoje = date('Y-m-d');
$primeiro_dia_mes = date('Y-m-01');

$conn = new mysqli($db_host, $db_user, $db_password, $db_name);

if ($conn->connect_error) {
    echo json_encode(['success' => false, 'error' => 'Erro de conexão: ' . $conn->connect_error]);
    exit;
}

// Total de agendamentos (pago + concluido)
$sql = "SELECT COUNT(*) as total FROM horarios WHERE barbeiro_id = ? AND status IN ('pago', 'concluido')";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $barbeiro_id);
$stmt->execute();
$result = $stmt->get_result();
$total = $result->fetch_assoc()['total'] ?? 0;

// Agendamentos de hoje
$sql = "SELECT COUNT(*) as hoje FROM horarios WHERE barbeiro_id = ? AND data = ? AND status IN ('pago', 'concluido')";
$stmt = $conn->prepare($sql);
$stmt->bind_param("is", $barbeiro_id, $hoje);
$stmt->execute();
$result = $stmt->get_result();
$hoje_count = $result->fetch_assoc()['hoje'] ?? 0;

// Agendamentos pendentes (pagos para hoje ou futuro)
$sql = "SELECT COUNT(*) as pendentes FROM horarios WHERE barbeiro_id = ? AND status = 'pago' AND data >= ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("is", $barbeiro_id, $hoje);
$stmt->execute();
$result = $stmt->get_result();
$pendentes = $result->fetch_assoc()['pendentes'] ?? 0;

// Faturamento do mês
$sql = "SELECT SUM(preco) as faturamento FROM horarios 
        WHERE barbeiro_id = ? AND data >= ? AND status IN ('pago', 'concluido')";
$stmt = $conn->prepare($sql);
$stmt->bind_param("is", $barbeiro_id, $primeiro_dia_mes);
$stmt->execute();
$result = $stmt->get_result();
$faturamento = $result->fetch_assoc()['faturamento'] ?? 0;

// Total de concluídos
$sql = "SELECT COUNT(*) as total_concluidos FROM horarios WHERE barbeiro_id = ? AND status = 'concluido'";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $barbeiro_id);
$stmt->execute();
$result = $stmt->get_result();
$total_concluidos = $result->fetch_assoc()['total_concluidos'] ?? 0;

$conn->close();

echo json_encode([
    'success' => true,
    'total' => intval($total),
    'hoje' => intval($hoje_count),
    'pendentes' => intval($pendentes),
    'faturamento' => floatval($faturamento),
    'total_concluidos' => intval($total_concluidos)
]);
?>
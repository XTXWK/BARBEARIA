<?php
session_start();
include("../config.php");

// Verificar se está logado
if (!isset($_SESSION['barbeiro_id'])) {
    header('Location: login_barbeiro.php');
    exit;
}

$barbeiro_id = $_SESSION['barbeiro_id'];
$barbeiro_nome = $_SESSION['barbeiro_nome'];
$barbeiro_email = $_SESSION['barbeiro_email'];

$conn = new mysqli($db_host, $db_user, $db_password, $db_name);

if ($conn->connect_error) {
    die("Erro de conexão: " . $conn->connect_error);
}

// Buscar dados do barbeiro
$sql = "SELECT * FROM barbeiros WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $barbeiro_id);
$stmt->execute();
$result = $stmt->get_result();
$barbeiro = $result->fetch_assoc();

// Buscar serviços do barbeiro
$sql = "SELECT * FROM servicos_barbeiro WHERE barbeiro_id = ? AND ativo = 1 ORDER BY nome";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $barbeiro_id);
$stmt->execute();
$result = $stmt->get_result();
$servicos_barbeiro = [];
while ($row = $result->fetch_assoc()) {
    $servicos_barbeiro[] = $row;
}

// Buscar estatísticas
$hoje = date('Y-m-d');

// Total de agendamentos
$sql = "SELECT COUNT(*) as total FROM horarios WHERE barbeiro_id = ? AND status IN ('pago', 'concluido')";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $barbeiro_id);
$stmt->execute();
$result = $stmt->get_result();
$stats['total'] = $result->fetch_assoc()['total'] ?? 0;

// Agendamentos de hoje
$sql = "SELECT COUNT(*) as hoje FROM horarios WHERE barbeiro_id = ? AND data = ? AND status IN ('pago', 'concluido')";
$stmt = $conn->prepare($sql);
$stmt->bind_param("is", $barbeiro_id, $hoje);
$stmt->execute();
$result = $stmt->get_result();
$stats['hoje'] = $result->fetch_assoc()['hoje'] ?? 0;

// Agendamentos pendentes (não concluídos)
$sql = "SELECT COUNT(*) as pendentes FROM horarios WHERE barbeiro_id = ? AND status = 'pago' AND data >= ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("is", $barbeiro_id, $hoje);
$stmt->execute();
$result = $stmt->get_result();
$stats['pendentes'] = $result->fetch_assoc()['pendentes'] ?? 0;

// Faturamento do mês
$primeiro_dia_mes = date('Y-m-01');
$sql = "SELECT SUM(preco) as faturamento FROM horarios 
        WHERE barbeiro_id = ? AND data >= ? AND status IN ('pago', 'concluido')";
$stmt = $conn->prepare($sql);
$stmt->bind_param("is", $barbeiro_id, $primeiro_dia_mes);
$stmt->execute();
$result = $stmt->get_result();
$stats['faturamento'] = $result->fetch_assoc()['faturamento'] ?? 0;

// Total de serviços concluídos (histórico)
$sql = "SELECT COUNT(*) as total_concluidos FROM horarios WHERE barbeiro_id = ? AND status = 'concluido'";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $barbeiro_id);
$stmt->execute();
$result = $stmt->get_result();
$stats['total_concluidos'] = $result->fetch_assoc()['total_concluidos'] ?? 0;

$conn->close();
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - <?php echo $barbeiro_nome; ?> | Thomaz Black Barbearia</title>
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;700;900&family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Inter', sans-serif;
            background: #0a0a0a;
            color: #fff;
            min-height: 100vh;
            padding: 20px;
        }
        ::-webkit-scrollbar { width: 8px; }
        ::-webkit-scrollbar-track { background: #1a1a1a; }
        ::-webkit-scrollbar-thumb { background: #c9a84c; border-radius: 4px; }
        .container { max-width: 1400px; margin: 0 auto; }
        
        /* HEADER */
        .header {
            background: rgba(26, 26, 26, 0.9);
            backdrop-filter: blur(20px);
            padding: 20px 30px;
            border-radius: 16px;
            border: 1px solid rgba(201, 168, 76, 0.1);
            margin-bottom: 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 15px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.3);
        }
        .header .logo-section { display: flex; align-items: center; gap: 15px; }
        .header .logo-section .logo-icon { font-size: 2em; color: #c9a84c; }
        .header .logo-section h1 { font-family: 'Playfair Display', serif; font-size: 1.6em; color: #fff; }
        .header .logo-section h1 span { color: #c9a84c; }
        .header .logo-section .subtitle { color: #666; font-size: 0.75em; font-weight: 400; letter-spacing: 1px; text-transform: uppercase; }
        .header .user-info { display: flex; align-items: center; gap: 20px; flex-wrap: wrap; }
        .header .user-info .user-avatar {
            width: 45px; height: 45px; border-radius: 50%;
            background: linear-gradient(135deg, #c9a84c, #a8893a);
            display: flex; align-items: center; justify-content: center;
            font-weight: 700; font-size: 1.2em; color: #0a0a0a;
        }
        .header .user-info .user-details { line-height: 1.4; }
        .header .user-info .user-details .name { font-weight: 600; color: #fff; }
        .header .user-info .user-details .email { color: #666; font-size: 0.8em; }
        .header .user-info .logout-btn {
            background: #dc3545; color: white; border: none;
            padding: 8px 20px; border-radius: 8px; cursor: pointer;
            font-weight: 600; transition: all 0.3s;
            font-family: 'Inter', sans-serif; font-size: 0.85em;
        }
        .header .user-info .logout-btn:hover {
            background: #c82333; transform: translateY(-2px);
            box-shadow: 0 5px 20px rgba(220, 53, 69, 0.3);
        }
        
        /* STATS */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        .stat-card {
            background: rgba(26, 26, 26, 0.8);
            backdrop-filter: blur(10px);
            padding: 20px 25px;
            border-radius: 14px;
            border: 1px solid rgba(201, 168, 76, 0.08);
            transition: all 0.3s;
            cursor: default;
        }
        .stat-card:hover {
            transform: translateY(-3px);
            border-color: rgba(201, 168, 76, 0.2);
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
        }
        .stat-card .stat-icon { font-size: 1.8em; margin-bottom: 10px; }
        .stat-card .stat-number {
            font-family: 'Playfair Display', serif;
            font-size: 2em;
            font-weight: 700;
            color: #c9a84c;
        }
        .stat-card .stat-label { color: #666; font-size: 0.85em; margin-top: 5px; }
        .stat-card.destaque { border-color: rgba(40, 167, 69, 0.3); }
        
        /* TABS */
        .tab-buttons {
            display: flex;
            gap: 10px;
            margin-bottom: 25px;
            flex-wrap: wrap;
        }
        .tab-buttons button {
            padding: 12px 24px;
            background: rgba(26, 26, 26, 0.6);
            border: 1px solid #2d2d2d;
            color: #888;
            border-radius: 10px;
            cursor: pointer;
            transition: all 0.3s;
            font-weight: 600;
            font-size: 0.9em;
            font-family: 'Inter', sans-serif;
        }
        .tab-buttons button:hover {
            background: rgba(26, 26, 26, 0.9);
            color: #fff;
            border-color: #3d3d3d;
        }
        .tab-buttons button.active {
            background: linear-gradient(135deg, #c9a84c, #a8893a);
            color: #0a0a0a;
            border-color: #c9a84c;
            box-shadow: 0 5px 25px rgba(201, 168, 76, 0.2);
        }
        .tab-content { display: none; animation: fadeIn 0.4s ease; }
        .tab-content.active { display: block; }
        @keyframes fadeIn { from { opacity: 0; transform: translateY(15px); } to { opacity: 1; transform: translateY(0); } }
        
        /* CARDS */
        .card {
            background: rgba(26, 26, 26, 0.8);
            backdrop-filter: blur(10px);
            border-radius: 16px;
            border: 1px solid rgba(201, 168, 76, 0.08);
            padding: 25px;
            margin-bottom: 20px;
            box-shadow: 0 5px 30px rgba(0,0,0,0.2);
        }
        .card-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
            flex-wrap: wrap;
            gap: 15px;
        }
        .card-header h3 {
            font-family: 'Playfair Display', serif;
            color: #c9a84c;
            font-size: 1.3em;
        }
        .card-header .card-actions { display: flex; gap: 10px; flex-wrap: wrap; }
        .card-header .card-actions button {
            padding: 8px 18px;
            background: #2d2d2d;
            border: 1px solid #3d3d3d;
            color: #aaa;
            border-radius: 8px;
            cursor: pointer;
            transition: all 0.3s;
            font-size: 0.85em;
            font-family: 'Inter', sans-serif;
            font-weight: 500;
        }
        .card-header .card-actions button:hover { background: #3d3d3d; color: #fff; }
        .card-header .card-actions .btn-primary {
            background: linear-gradient(135deg, #c9a84c, #a8893a);
            color: #0a0a0a;
            border: none;
        }
        .card-header .card-actions .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 20px rgba(201, 168, 76, 0.3);
        }
        .card-header .card-actions .btn-success {
            background: #28a745;
            color: white;
            border: none;
        }
        .card-header .card-actions .btn-success:hover {
            background: #218838;
        }
        .card-header .card-actions .btn-info {
            background: #17a2b8;
            color: white;
            border: none;
        }
        .card-header .card-actions .btn-info:hover {
            background: #138496;
        }
        
        /* FILTROS */
        .filters-section {
            display: flex;
            gap: 12px;
            flex-wrap: wrap;
            margin-bottom: 20px;
            padding: 15px;
            background: rgba(13, 13, 13, 0.6);
            border-radius: 10px;
            border: 1px solid rgba(255,255,255,0.05);
            align-items: center;
        }
        .filters-section .filter-group {
            display: flex;
            gap: 8px;
            align-items: center;
            flex-wrap: wrap;
        }
        .filters-section .filter-group label {
            color: #888;
            font-size: 0.75em;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        .filters-section .filter-group input,
        .filters-section .filter-group select {
            padding: 8px 14px;
            border-radius: 8px;
            border: 1px solid #2d2d2d;
            background: rgba(0,0,0,0.3);
            color: #fff;
            font-size: 0.9em;
            font-family: 'Inter', sans-serif;
            min-width: 130px;
        }
        .filters-section .filter-group input:focus,
        .filters-section .filter-group select:focus {
            outline: none;
            border-color: #c9a84c;
        }
        .filters-section .filter-group .search-input { min-width: 200px; flex: 1; }
        .filters-section .filter-group .clear-btn {
            padding: 8px 16px;
            background: #dc3545;
            color: white;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-size: 0.8em;
            font-weight: 600;
        }
        .filters-section .filter-group .clear-btn:hover { background: #c82333; }
        
        /* LISTA */
        .agendamentos-container { max-height: 600px; overflow-y: auto; }
        .agendamento-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 16px 20px;
            border-bottom: 1px solid rgba(255,255,255,0.05);
            flex-wrap: wrap;
            gap: 12px;
            border-radius: 10px;
            transition: all 0.3s;
            position: relative;
        }
        .agendamento-item:hover { background: rgba(201, 168, 76, 0.05); }
        .agendamento-item.concluido {
            opacity: 0.7;
            background: rgba(40, 167, 69, 0.05);
            border-left: 3px solid #28a745;
        }
        .agendamento-item.cancelado {
            opacity: 0.5;
            background: rgba(220, 53, 69, 0.05);
            border-left: 3px solid #dc3545;
        }
        .agendamento-item .info { flex: 2; min-width: 200px; }
        .agendamento-item .info .data-hora {
            font-weight: 700;
            font-size: 1.05em;
            color: #c9a84c;
        }
        .agendamento-item .info .cliente { color: #fff; font-weight: 600; margin-top: 2px; }
        .agendamento-item .info .cliente .telefone { color: #888; font-weight: 400; font-size: 0.85em; }
        .agendamento-item .info .servico { color: #888; font-size: 0.85em; margin-top: 2px; }
        .agendamento-item .info .observacoes { color: #666; font-size: 0.8em; font-style: italic; margin-top: 2px; }
        .agendamento-item .info .concluido-em { color: #28a745; font-size: 0.75em; margin-top: 2px; }
        .agendamento-item .actions {
            display: flex;
            gap: 8px;
            flex-wrap: wrap;
            align-items: center;
        }
        .agendamento-item .actions .status-badge {
            padding: 4px 14px;
            border-radius: 20px;
            font-size: 0.7em;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        .status-pago { background: #17a2b8; color: white; }
        .status-concluido { background: #28a745; color: white; }
        .status-cancelado { background: #dc3545; color: white; }
        .status-reservado { background: #ffc107; color: #0a0a0a; }
        
        .agendamento-item .actions .btn-action {
            padding: 6px 14px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-size: 0.75em;
            font-weight: 600;
            transition: all 0.3s;
            font-family: 'Inter', sans-serif;
            display: inline-flex;
            align-items: center;
            gap: 5px;
        }
        .agendamento-item .actions .btn-action:hover { transform: translateY(-2px); }
        .btn-whatsapp { background: #25D366; color: white; }
        .btn-whatsapp:hover { background: #1da851; }
        .btn-concluir { background: #28a745; color: white; }
        .btn-concluir:hover { background: #218838; }
        .btn-restaurar { background: #28a745; color: white; }
        .btn-restaurar:hover { background: #218838; }
        .btn-reagendar { background: #ffc107; color: #0a0a0a; }
        .btn-reagendar:hover { background: #e0a800; }
        .btn-remover { background: #dc3545; color: white; }
        .btn-remover:hover { background: #c82333; }
        
        /* PAGINAÇÃO */
        .pagination {
            display: flex;
            justify-content: center;
            gap: 8px;
            margin-top: 20px;
            flex-wrap: wrap;
        }
        .pagination button {
            padding: 8px 16px;
            background: #2d2d2d;
            border: 1px solid #3d3d3d;
            color: #aaa;
            border-radius: 6px;
            cursor: pointer;
            transition: all 0.3s;
            font-family: 'Inter', sans-serif;
            font-weight: 500;
        }
        .pagination button:hover:not(.active) { background: #3d3d3d; color: #fff; }
        .pagination button.active {
            background: #c9a84c;
            color: #0a0a0a;
            border-color: #c9a84c;
        }
        .pagination button:disabled { opacity: 0.3; cursor: not-allowed; }
        
        .empty-message {
            color: #666;
            text-align: center;
            padding: 40px 20px;
        }
        
        /* MODAL */
        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.85);
            backdrop-filter: blur(10px);
            z-index: 2000;
            justify-content: center;
            align-items: center;
        }
        .modal.active { display: flex; animation: fadeIn 0.3s ease; }
        .modal-content {
            background: rgba(26, 26, 26, 0.95);
            padding: 35px;
            border-radius: 16px;
            max-width: 550px;
            width: 90%;
            max-height: 85vh;
            overflow-y: auto;
            border: 1px solid rgba(201, 168, 76, 0.1);
            box-shadow: 0 30px 60px rgba(0,0,0,0.5);
        }
        .modal-content h2 { font-family: 'Playfair Display', serif; color: #c9a84c; margin-bottom: 20px; }
        .modal-content .form-group { margin-bottom: 18px; }
        .modal-content .form-group label {
            display: block;
            color: #aaa;
            font-size: 0.8em;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            margin-bottom: 5px;
        }
        .modal-content .form-group input,
        .modal-content .form-group select,
        .modal-content .form-group textarea {
            width: 100%;
            padding: 10px 14px;
            border-radius: 8px;
            border: 1px solid #2d2d2d;
            background: rgba(0,0,0,0.3);
            color: #fff;
            font-size: 0.95em;
            font-family: 'Inter', sans-serif;
            transition: all 0.3s;
        }
        .modal-content .form-group input:focus,
        .modal-content .form-group select:focus,
        .modal-content .form-group textarea:focus {
            outline: none;
            border-color: #c9a84c;
            box-shadow: 0 0 0 3px rgba(201, 168, 76, 0.1);
        }
        .modal-content .form-group textarea { resize: vertical; min-height: 60px; }
        .modal-actions { display: flex; gap: 12px; margin-top: 20px; }
        .modal-actions button {
            padding: 10px 25px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-weight: 600;
            transition: all 0.3s;
            font-family: 'Inter', sans-serif;
            font-size: 0.9em;
        }
        .modal-actions .btn-primary {
            background: linear-gradient(135deg, #c9a84c, #a8893a);
            color: #0a0a0a;
            flex: 1;
        }
        .modal-actions .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 20px rgba(201, 168, 76, 0.3);
        }
        .modal-actions .btn-secondary { background: #2d2d2d; color: #aaa; }
        .modal-actions .btn-secondary:hover { background: #3d3d3d; color: #fff; }
        
        /* ALERTAS */
        .alert {
            padding: 12px 18px;
            border-radius: 8px;
            margin: 10px 0;
            font-size: 0.9em;
        }
        .alert-success {
            background: rgba(40, 167, 69, 0.15);
            border: 1px solid rgba(40, 167, 69, 0.2);
            color: #28a745;
        }
        .alert-error {
            background: rgba(220, 53, 69, 0.15);
            border: 1px solid rgba(220, 53, 69, 0.2);
            color: #dc3545;
        }
        .alert-info {
            background: rgba(23, 162, 184, 0.15);
            border: 1px solid rgba(23, 162, 184, 0.2);
            color: #17a2b8;
        }
        .alert-warning {
            background: rgba(255, 193, 7, 0.15);
            border: 1px solid rgba(255, 193, 7, 0.2);
            color: #ffc107;
        }
        
        .loading { text-align: center; padding: 30px; }
        .spinner {
            border: 3px solid #2d2d2d;
            border-top: 3px solid #c9a84c;
            border-radius: 50%;
            width: 35px;
            height: 35px;
            animation: spin 1s linear infinite;
            margin: 0 auto 15px;
        }
        @keyframes spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }
        
        .hidden { display: none !important; }
        .mt-10 { margin-top: 10px; }
        .mt-15 { margin-top: 15px; }
        .mt-20 { margin-top: 20px; }
        .mb-10 { margin-bottom: 10px; }
        .mb-15 { margin-bottom: 15px; }
        .text-center { text-align: center; }
        
        .stats-resumo {
            display: flex;
            gap: 20px;
            flex-wrap: wrap;
            padding: 12px 16px;
            background: rgba(13, 13, 13, 0.6);
            border-radius: 8px;
            margin-top: 15px;
            font-size: 0.85em;
        }
        .stats-resumo span { color: #aaa; }
        .stats-resumo strong { color: #fff; }
        
        /* SERVIÇOS */
        .servicos-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
            gap: 15px;
        }
        .servico-card {
            background: rgba(13, 13, 13, 0.6);
            padding: 18px 20px;
            border-radius: 12px;
            border-left: 4px solid #c9a84c;
            transition: all 0.3s;
        }
        .servico-card:hover { transform: translateX(5px); background: rgba(13, 13, 13, 0.8); }
        .servico-card .nome { font-weight: 600; font-size: 1.1em; }
        .servico-card .preco { color: #c9a84c; font-weight: 700; }
        .servico-card .duracao { color: #666; font-size: 0.85em; }
        .servico-card .descricao { color: #666; font-size: 0.8em; margin-top: 5px; }
        .servico-card .actions { margin-top: 12px; display: flex; gap: 8px; }
        
        .btn-small {
            padding: 5px 14px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-size: 0.75em;
            font-weight: 600;
            transition: all 0.3s;
            font-family: 'Inter', sans-serif;
        }
        .btn-small:hover { transform: translateY(-2px); }
        .btn-edit { background: #c9a84c; color: #0a0a0a; }
        .btn-edit:hover { background: #dbb95c; }
        .btn-delete { background: #dc3545; color: white; }
        .btn-delete:hover { background: #c82333; }
        
        /* HORÁRIOS */
        .horarios-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(110px, 1fr));
            gap: 10px;
            max-height: 500px;
            overflow-y: auto;
            padding: 5px;
        }
        .horario-item {
            background: rgba(13, 13, 13, 0.6);
            padding: 14px 10px;
            border-radius: 12px;
            text-align: center;
            border: 2px solid #2d2d2d;
            transition: all 0.3s;
        }
        .horario-item:hover { transform: scale(1.03); box-shadow: 0 5px 20px rgba(0,0,0,0.3); }
        .horario-item .hora { font-weight: 700; font-size: 1.2em; }
        .horario-item .status-badge {
            display: inline-block;
            padding: 2px 10px;
            border-radius: 12px;
            font-size: 0.6em;
            font-weight: 600;
            margin-top: 4px;
        }
        .horario-item .cliente-info { font-size: 0.7em; color: #aaa; margin-top: 4px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
        .horario-item .servico-info { font-size: 0.65em; color: #c9a84c; margin-top: 2px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
        .horario-item .btn-delete-small {
            margin-top: 6px;
            padding: 3px 10px;
            background: #dc3545;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 0.65em;
            transition: all 0.3s;
        }
        .horario-item .btn-delete-small:hover { background: #c82333; }
        .horario-item.status-disponivel { border-color: #28a745; background: rgba(40, 167, 69, 0.05); }
        .horario-item.status-disponivel .status-badge { background: #28a745; color: white; }
        .horario-item.status-pago { border-color: #17a2b8; background: rgba(23, 162, 184, 0.05); }
        .horario-item.status-pago .status-badge { background: #17a2b8; color: white; }
        .horario-item.status-reservado { border-color: #ffc107; background: rgba(255, 193, 7, 0.05); }
        .horario-item.status-reservado .status-badge { background: #ffc107; color: #0a0a0a; }
        .horario-item.status-cancelado { border-color: #dc3545; background: rgba(220, 53, 69, 0.05); opacity: 0.6; }
        .horario-item.status-cancelado .status-badge { background: #dc3545; color: white; }
        
        /* QUICK ADD */
        .quick-add-area {
            background: rgba(13, 13, 13, 0.6);
            padding: 20px;
            border-radius: 12px;
            border: 1px solid rgba(201, 168, 76, 0.1);
            margin-bottom: 20px;
        }
        .quick-add-area .quick-row { display: flex; gap: 15px; flex-wrap: wrap; align-items: flex-end; }
        .quick-add-area .quick-row .field { flex: 1; min-width: 180px; }
        .quick-add-area .quick-row .field label {
            display: block;
            color: #888;
            font-size: 0.75em;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            margin-bottom: 5px;
        }
        .quick-add-area .quick-row .field input {
            width: 100%;
            padding: 10px 14px;
            border-radius: 8px;
            border: 1px solid #2d2d2d;
            background: rgba(0,0,0,0.3);
            color: #fff;
            font-size: 0.95em;
            font-family: 'Inter', sans-serif;
            transition: all 0.3s;
        }
        .quick-add-area .quick-row .field input:focus {
            outline: none;
            border-color: #c9a84c;
            box-shadow: 0 0 0 3px rgba(201, 168, 76, 0.1);
        }
        .quick-add-area .quick-row .btn-add {
            padding: 10px 30px;
            background: linear-gradient(135deg, #c9a84c, #a8893a);
            color: #0a0a0a;
            border: none;
            border-radius: 8px;
            font-weight: 700;
            cursor: pointer;
            transition: all 0.3s;
            font-family: 'Inter', sans-serif;
            font-size: 0.95em;
        }
        .quick-add-area .quick-row .btn-add:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 25px rgba(201, 168, 76, 0.3);
        }
        .quick-add-area .preset-buttons {
            display: flex;
            gap: 8px;
            flex-wrap: wrap;
            margin-top: 15px;
            padding-top: 15px;
            border-top: 1px solid rgba(255,255,255,0.05);
        }
        .quick-add-area .preset-buttons .preset-label { color: #666; font-size: 0.8em; display: flex; align-items: center; margin-right: 5px; }
        .quick-add-area .preset-buttons button {
            padding: 5px 14px;
            background: #2d2d2d;
            border: 1px solid #3d3d3d;
            color: #aaa;
            border-radius: 6px;
            cursor: pointer;
            font-size: 0.75em;
            transition: all 0.3s;
            font-family: 'Inter', sans-serif;
        }
        .quick-add-area .preset-buttons button:hover { background: #3d3d3d; color: #fff; transform: translateY(-1px); }
        
        @media (max-width: 768px) {
            .header { padding: 15px 20px; }
            .stats-grid { grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); }
            .stat-card .stat-number { font-size: 1.5em; }
            .filters-section { flex-direction: column; align-items: stretch; }
            .filters-section .filter-group .search-input { min-width: unset; }
            .agendamento-item { flex-direction: column; align-items: stretch; }
            .agendamento-item .actions { justify-content: flex-start; margin-top: 5px; }
            .quick-add-area .quick-row { flex-direction: column; align-items: stretch; }
            .quick-add-area .quick-row .field { min-width: unset; }
            .quick-add-area .quick-row .btn-add { width: 100%; }
            .tab-buttons button { padding: 8px 16px; font-size: 0.8em; }
            .card { padding: 18px 15px; }
            .modal-content { padding: 25px 20px; }
        }
        @media (max-width: 480px) {
            .stats-grid { grid-template-columns: 1fr 1fr; gap: 10px; }
            .stat-card { padding: 15px; }
            .stat-card .stat-number { font-size: 1.3em; }
            .agendamento-item { padding: 12px 14px; }
            .agendamento-item .actions .btn-action { font-size: 0.65em; padding: 4px 10px; }
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- HEADER -->
        <header class="header">
            <div class="logo-section">
                <div class="logo-icon"><i class="fas fa-scissors"></i></div>
                <div>
                    <h1>Thomaz Black <span>Barbearia</span></h1>
                    <div class="subtitle">Dashboard do Barbeiro</div>
                </div>
            </div>
            <div class="user-info">
                <div class="user-avatar">
                    <?php echo strtoupper(substr($barbeiro_nome, 0, 1)); ?>
                </div>
                <div class="user-details">
                    <div class="name"><?php echo $barbeiro_nome; ?></div>
                    <div class="email"><?php echo $barbeiro_email; ?></div>
                </div>
                <button class="logout-btn" onclick="window.location.href='logout_barbeiro.php'">
                    <i class="fas fa-sign-out-alt"></i> Sair
                </button>
            </div>
        </header>

        <!-- STATS -->
        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-icon">📋</div>
                <div class="stat-number"><?php echo $stats['total']; ?></div>
                <div class="stat-label">Total de Atendimentos</div>
            </div>
            <div class="stat-card">
                <div class="stat-icon">📅</div>
                <div class="stat-number"><?php echo $stats['hoje']; ?></div>
                <div class="stat-label">Atendimentos Hoje</div>
            </div>
            <div class="stat-card">
                <div class="stat-icon">⏳</div>
                <div class="stat-number"><?php echo $stats['pendentes']; ?></div>
                <div class="stat-label">Pendentes</div>
            </div>
            <div class="stat-card">
                <div class="stat-icon">💰</div>
                <div class="stat-number">R$ <?php echo number_format($stats['faturamento'], 2, ',', '.'); ?></div>
                <div class="stat-label">Faturamento do Mês</div>
            </div>
            <div class="stat-card destaque">
                <div class="stat-icon">✅</div>
                <div class="stat-number"><?php echo $stats['total_concluidos']; ?></div>
                <div class="stat-label">Serviços Concluídos</div>
            </div>
        </div>

        <!-- TABS -->
        <div class="tab-buttons">
            <button class="active" onclick="showTab('agendamentos')">
                <i class="fas fa-calendar-check"></i> Agendamentos
            </button>
            <button onclick="showTab('historico')">
                <i class="fas fa-history"></i> Histórico
            </button>
            <button onclick="showTab('servicos')">
                <i class="fas fa-cut"></i> Serviços
            </button>
            <button onclick="showTab('horarios')">
                <i class="fas fa-clock"></i> Horários
            </button>
        </div>

        <!-- TAB: AGENDAMENTOS -->
        <div id="tab-agendamentos" class="tab-content active">
            <div class="card">
                <div class="card-header">
                    <h3>📋 Gerenciar Agendamentos</h3>
                    <div class="card-actions">
                        <button class="btn-success" onclick="carregarAgendamentos()">
                            <i class="fas fa-sync"></i> Atualizar
                        </button>
                    </div>
                </div>
                <div class="filters-section">
                    <div class="filter-group" style="flex:2;">
                        <label><i class="fas fa-search"></i> Pesquisar</label>
                        <input type="text" id="search-input" class="search-input" placeholder="Nome, email ou telefone..." oninput="filtrarAgendamentos()">
                    </div>
                    <div class="filter-group">
                        <label><i class="fas fa-filter"></i> Status</label>
                        <select id="status-filter" onchange="filtrarAgendamentos()">
                            <option value="todos">Todos</option>
                            <option value="pago">Confirmados</option>
                            <option value="concluido">Concluídos</option>
                            <option value="reservado">Reservados</option>
                            <option value="cancelado">Cancelados</option>
                        </select>
                    </div>
                    <div class="filter-group">
                        <label><i class="fas fa-calendar"></i> Data</label>
                        <input type="date" id="data-filter" onchange="filtrarAgendamentos()">
                    </div>
                    <div class="filter-group">
                        <button class="clear-btn" onclick="limparFiltros()">
                            <i class="fas fa-times"></i> Limpar
                        </button>
                    </div>
                </div>
                <div id="agendamentos-lista">
                    <div class="loading"><div class="spinner"></div><p>Carregando agendamentos...</p></div>
                </div>
                <div id="pagination" class="pagination"></div>
            </div>
        </div>

        <!-- TAB: HISTÓRICO -->
        <div id="tab-historico" class="tab-content">
            <div class="card">
                <div class="card-header">
                    <h3>📜 Histórico de Serviços</h3>
                    <div class="card-actions">
                        <button class="btn-success" onclick="carregarHistorico()">
                            <i class="fas fa-sync"></i> Atualizar
                        </button>
                    </div>
                </div>
                <div class="filters-section">
                    <div class="filter-group" style="flex:2;">
                        <label><i class="fas fa-search"></i> Pesquisar</label>
                        <input type="text" id="historico-search" class="search-input" placeholder="Nome, serviço ou telefone..." oninput="filtrarHistorico()">
                    </div>
                    <div class="filter-group">
                        <label><i class="fas fa-calendar"></i> De</label>
                        <input type="date" id="historico-data-inicio" onchange="filtrarHistorico()">
                    </div>
                    <div class="filter-group">
                        <label><i class="fas fa-calendar"></i> Até</label>
                        <input type="date" id="historico-data-fim" onchange="filtrarHistorico()">
                    </div>
                    <div class="filter-group">
                        <button class="clear-btn" onclick="limparFiltrosHistorico()">
                            <i class="fas fa-times"></i> Limpar
                        </button>
                    </div>
                </div>
                <div id="historico-lista">
                    <div class="loading"><div class="spinner"></div><p>Carregando histórico...</p></div>
                </div>
                <div id="historico-pagination" class="pagination"></div>
            </div>
        </div>

        <!-- TAB: SERVIÇOS -->
        <div id="tab-servicos" class="tab-content">
            <div class="card">
                <div class="card-header">
                    <h3>💇 Meus Serviços</h3>
                    <div class="card-actions">
                        <button class="btn-primary" onclick="abrirModalServico()">
                            <i class="fas fa-plus"></i> Novo Serviço
                        </button>
                        <button onclick="carregarServicos()">
                            <i class="fas fa-sync"></i> Atualizar
                        </button>
                    </div>
                </div>
                <div id="servicos-container">
                    <?php if (empty($servicos_barbeiro)): ?>
                        <p class="empty-message">Nenhum serviço cadastrado. Clique em "Novo Serviço" para adicionar.</p>
                    <?php else: ?>
                        <div class="servicos-grid">
                            <?php foreach ($servicos_barbeiro as $servico): ?>
                                <div class="servico-card" style="border-left-color: <?php echo $servico['cor'] ?? '#c9a84c'; ?>;">
                                    <div class="nome"><?php echo $servico['nome']; ?></div>
                                    <div class="preco">R$ <?php echo number_format($servico['preco'], 2, ',', '.'); ?></div>
                                    <div class="duracao">⏱️ <?php echo $servico['duracao_minutos']; ?> min</div>
                                    <?php if ($servico['descricao']): ?>
                                        <div class="descricao"><?php echo $servico['descricao']; ?></div>
                                    <?php endif; ?>
                                    <div class="actions">
                                        <button class="btn-small btn-edit" onclick="editarServico(<?php echo $servico['id']; ?>)">✏️ Editar</button>
                                        <button class="btn-small btn-delete" onclick="deletarServico(<?php echo $servico['id']; ?>)">🗑️</button>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- TAB: HORÁRIOS -->
        <div id="tab-horarios" class="tab-content">
            <div class="card">
                <div class="card-header">
                    <h3>⏰ Gerenciar Horários</h3>
                    <div class="card-actions">
                        <button onclick="carregarHorarios()">
                            <i class="fas fa-sync"></i> Atualizar
                        </button>
                    </div>
                </div>
                <div class="quick-add-area">
                    <div class="quick-row">
                        <div class="field">
                            <label><i class="fas fa-calendar-day"></i> Data</label>
                            <input type="date" id="add-data" value="<?php echo date('Y-m-d'); ?>">
                        </div>
                        <div class="field" style="flex: 2;">
                            <label><i class="fas fa-clock"></i> Horários</label>
                            <input type="text" id="add-horarios" placeholder="Ex: 09:00,10:00,11:00...">
                        </div>
                        <button class="btn-add" onclick="adicionarHorarios()">
                            <i class="fas fa-plus"></i> Adicionar
                        </button>
                    </div>
                    <div class="preset-buttons">
                        <span class="preset-label">📌 Presets:</span>
                        <button onclick="aplicarPreset('09:00,10:00,11:00,12:00,13:00,14:00,15:00,16:00,17:00,18:00,19:00,20:00')">🌅 Manhã/Tarde</button>
                        <button onclick="aplicarPreset('14:00,15:00,16:00,17:00,18:00,19:00,20:00,21:00')">🌙 Tarde/Noite</button>
                        <button onclick="aplicarPreset('08:00,09:00,10:00,11:00,12:00')">☀️ Manhã</button>
                        <button onclick="gerarHorariosAutomaticos()">🔮 Automático</button>
                        <button onclick="limparCampoHorarios()" style="background:#dc3545;color:white;border-color:#dc3545;">🗑️ Limpar</button>
                    </div>
                    <div id="add-resultado" class="mt-10"></div>
                </div>
                <div style="margin-top: 20px;">
                    <div style="display: flex; gap: 12px; flex-wrap: wrap; align-items: center; margin-bottom: 15px;">
                        <div style="flex: 1; min-width: 180px;">
                            <label style="color: #aaa; font-size: 0.75em; display: block; text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 4px;">📅 Visualizar Data</label>
                            <input type="date" id="list-data" value="<?php echo date('Y-m-d'); ?>" style="width: 100%; padding: 10px 14px; border-radius: 8px; border: 1px solid #2d2d2d; background: rgba(0,0,0,0.3); color: #fff; font-family: 'Inter', sans-serif;">
                        </div>
                        <button onclick="carregarHorarios()" style="padding: 10px 25px; background: #c9a84c; color: #0a0a0a; border: none; border-radius: 8px; font-weight: 700; cursor: pointer; margin-top: 18px; font-family: 'Inter', sans-serif;">
                            <i class="fas fa-search"></i> Buscar
                        </button>
                        <button onclick="limparHorariosDisponiveis()" style="padding: 10px 25px; background: #dc3545; color: white; border: none; border-radius: 8px; font-weight: 700; cursor: pointer; margin-top: 18px; font-family: 'Inter', sans-serif;">
                            <i class="fas fa-trash"></i> Limpar Disponíveis
                        </button>
                    </div>
                    <div id="horarios-lista">
                        <p style="color: #666; text-align: center; padding: 30px;">📅 Selecione uma data para visualizar os horários</p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- MODAL: SERVIÇO -->
    <div class="modal" id="modal-servico">
        <div class="modal-content">
            <h2 id="modal-servico-title">✏️ Novo Serviço</h2>
            <form id="servico-form">
                <div class="form-group">
                    <label>Nome do Serviço *</label>
                    <input type="text" id="servico-nome" placeholder="Ex: Corte de Cabelo" required>
                </div>
                <div class="form-group">
                    <label>Descrição</label>
                    <textarea id="servico-descricao" placeholder="Descrição do serviço" rows="2"></textarea>
                </div>
                <div class="form-group">
                    <label>Preço (R$) *</label>
                    <input type="number" id="servico-preco" placeholder="30.00" step="0.01" required>
                </div>
                <div class="form-group">
                    <label>Duração (minutos) *</label>
                    <input type="number" id="servico-duracao" placeholder="30" min="5" step="5" required>
                </div>
                <div class="form-group">
                    <label>Cor</label>
                    <input type="color" id="servico-cor" value="#c9a84c">
                </div>
                <input type="hidden" id="servico-id">
                <div class="modal-actions">
                    <button type="button" class="btn-primary" onclick="salvarServico()">💾 Salvar</button>
                    <button type="button" class="btn-secondary" onclick="fecharModalServico()">Cancelar</button>
                </div>
            </form>
        </div>
    </div>

    <!-- MODAL: REAGENDAR -->
    <div class="modal" id="modal-reagendar">
        <div class="modal-content">
            <h2>🔄 Reagendar</h2>
            <input type="hidden" id="reagendar-id">
            <div class="form-group">
                <label>Nova Data</label>
                <input type="date" id="reagendar-data" min="<?php echo date('Y-m-d'); ?>">
            </div>
            <div class="form-group">
                <label>Novo Horário</label>
                <select id="reagendar-horario">
                    <option value="">Selecione um horário</option>
                </select>
            </div>
            <div class="form-group">
                <label>Motivo (opcional)</label>
                <textarea id="reagendar-motivo" placeholder="Motivo do reagendamento..." rows="2"></textarea>
            </div>
            <div class="modal-actions">
                <button type="button" class="btn-primary" onclick="confirmarReagendar()">✅ Confirmar</button>
                <button type="button" class="btn-secondary" onclick="fecharModalReagendar()">Cancelar</button>
            </div>
        </div>
    </div>

    <script>
        // ============================================
        // VARIÁVEIS GLOBAIS
        // ============================================
        let agendamentosData = [];
        let historicoData = [];
        let currentPage = 1;
        let historicoPage = 1;
        const itemsPerPage = 10;

        // ============================================
        // TABS
        // ============================================
        function showTab(tab) {
            document.querySelectorAll('.tab-content').forEach(el => el.classList.remove('active'));
            document.querySelectorAll('.tab-buttons button').forEach(el => el.classList.remove('active'));
            document.getElementById('tab-' + tab).classList.add('active');
            document.querySelector(`.tab-buttons button[onclick="showTab('${tab}')"]`).classList.add('active');
            
            if (tab === 'agendamentos') carregarAgendamentos();
            else if (tab === 'historico') carregarHistorico();
            else if (tab === 'horarios') carregarHorarios();
        }

        // ============================================
        // AGENDAMENTOS
        // ============================================
        function carregarAgendamentos() {
            $('#agendamentos-lista').html(`<div class="loading"><div class="spinner"></div><p>Carregando agendamentos...</p></div>`);
            
            $.ajax({
                url: 'listar_agendamentos_barbeiro.php',
                type: 'POST',
                dataType: 'json',
                success: function(response) {
                    if (response.error) {
                        if (response.error === 'Não autenticado') {
                            alert('⚠️ Sua sessão expirou. Faça login novamente.');
                            window.location.href = 'login_barbeiro.php';
                            return;
                        }
                        $('#agendamentos-lista').html(`<div class="alert alert-error">❌ ${response.error}</div>`);
                        return;
                    }
                    agendamentosData = response.agendamentos || [];
                    currentPage = 1;
                    renderizarAgendamentos();
                },
                error: function() {
                    $('#agendamentos-lista').html(`<div class="alert alert-error">❌ Erro ao carregar agendamentos</div>`);
                }
            });
        }

        function renderizarAgendamentos() {
            const searchTerm = $('#search-input').val().toLowerCase().trim();
            const statusFilter = $('#status-filter').val();
            const dataFilter = $('#data-filter').val();
            
            let filtered = agendamentosData;
            if (searchTerm) {
                filtered = filtered.filter(item => 
                    (item.cliente_nome && item.cliente_nome.toLowerCase().includes(searchTerm)) ||
                    (item.cliente_email && item.cliente_email.toLowerCase().includes(searchTerm)) ||
                    (item.cliente_telefone && item.cliente_telefone.includes(searchTerm))
                );
            }
            if (statusFilter !== 'todos') {
                filtered = filtered.filter(item => item.status === statusFilter);
            }
            if (dataFilter) {
                filtered = filtered.filter(item => item.data === dataFilter);
            }
            
            filtered.sort((a, b) => {
                if (a.data !== b.data) return a.data.localeCompare(b.data);
                return a.horario.localeCompare(b.horario);
            });
            
            const totalPages = Math.ceil(filtered.length / itemsPerPage);
            const start = (currentPage - 1) * itemsPerPage;
            const paginated = filtered.slice(start, start + itemsPerPage);
            
            if (filtered.length === 0) {
                $('#agendamentos-lista').html(`<p class="empty-message"><i class="fas fa-calendar-times" style="font-size: 2em; display: block; margin-bottom: 15px; color: #444;"></i>Nenhum agendamento encontrado</p>`);
                $('#pagination').html('');
                return;
            }
            
            let html = `<div class="agendamentos-container">`;
            paginated.forEach(item => {
                const statusClass = item.status === 'concluido' ? 'concluido' : item.status === 'cancelado' ? 'cancelado' : '';
                const statusLabel = { 'pago': 'Confirmado', 'concluido': 'Concluído ✅', 'reservado': 'Reservado', 'cancelado': 'Cancelado ❌' }[item.status] || item.status;
                const statusBadgeClass = 'status-' + item.status;
                
                html += `
                    <div class="agendamento-item ${statusClass}" data-id="${item.id}">
                        <div class="info">
                            <div class="data-hora">📅 ${formatarData(item.data)} às ${item.horario_formatado || '--:--'}</div>
                            <div class="cliente">👤 ${item.cliente_nome || 'Cliente não informado'} ${item.cliente_telefone ? `<span class="telefone">📱 ${formatarTelefone(item.cliente_telefone)}</span>` : ''}</div>
                            <div class="servico">💇 ${item.servico_nome || 'Serviço não definido'} ${item.preco ? `- R$ ${parseFloat(item.preco).toFixed(2).replace('.', ',')}` : ''}</div>
                            ${item.observacoes ? `<div class="observacoes">📝 ${item.observacoes}</div>` : ''}
                        </div>
                        <div class="actions">
                            <span class="status-badge ${statusBadgeClass}">${statusLabel}</span>
                            ${item.cliente_telefone ? `<button class="btn-action btn-whatsapp" onclick="enviarWhatsApp(${item.id})" title="WhatsApp"><i class="fab fa-whatsapp"></i></button>` : ''}
                            ${item.status === 'pago' ? `
                                <button class="btn-action btn-concluir" onclick="marcarComoConcluido(${item.id})" title="Concluir"><i class="fas fa-check"></i> Concluir</button>
                                <button class="btn-action btn-reagendar" onclick="abrirModalReagendar(${item.id})" title="Reagendar"><i class="fas fa-calendar-alt"></i></button>
                            ` : ''}
                            ${item.status === 'concluido' ? `<button class="btn-action btn-restaurar" onclick="restaurarAgendamento(${item.id})" title="Restaurar"><i class="fas fa-undo"></i></button>` : ''}
                            ${item.status !== 'cancelado' && item.status !== 'concluido' ? `<button class="btn-action btn-remover" onclick="cancelarAgendamento(${item.id})" title="Cancelar"><i class="fas fa-times"></i></button>` : ''}
                        </div>
                    </div>
                `;
            });
            html += `</div>`;
            $('#agendamentos-lista').html(html);
            
            let pagHtml = '';
            if (totalPages > 1) {
                pagHtml += `<button onclick="mudarPagina(1)" ${currentPage === 1 ? 'disabled' : ''}><i class="fas fa-angle-double-left"></i></button>`;
                pagHtml += `<button onclick="mudarPagina(${currentPage - 1})" ${currentPage === 1 ? 'disabled' : ''}><i class="fas fa-angle-left"></i></button>`;
                for (let i = Math.max(1, currentPage - 2); i <= Math.min(totalPages, currentPage + 2); i++) {
                    pagHtml += `<button onclick="mudarPagina(${i})" class="${i === currentPage ? 'active' : ''}">${i}</button>`;
                }
                pagHtml += `<button onclick="mudarPagina(${currentPage + 1})" ${currentPage === totalPages ? 'disabled' : ''}><i class="fas fa-angle-right"></i></button>`;
                pagHtml += `<button onclick="mudarPagina(${totalPages})" ${currentPage === totalPages ? 'disabled' : ''}><i class="fas fa-angle-double-right"></i></button>`;
            }
            $('#pagination').html(pagHtml);
        }

        // ============================================
        // HISTÓRICO
        // ============================================
        function carregarHistorico() {
            $('#historico-lista').html(`<div class="loading"><div class="spinner"></div><p>Carregando histórico...</p></div>`);
            
            $.ajax({
                url: 'listar_historico_barbeiro.php',
                type: 'POST',
                dataType: 'json',
                success: function(response) {
                    if (response.error) {
                        if (response.error === 'Não autenticado') {
                            alert('⚠️ Sua sessão expirou. Faça login novamente.');
                            window.location.href = 'login_barbeiro.php';
                            return;
                        }
                        $('#historico-lista').html(`<div class="alert alert-error">❌ ${response.error}</div>`);
                        return;
                    }
                    historicoData = response.historico || [];
                    historicoPage = 1;
                    renderizarHistorico();
                },
                error: function() {
                    $('#historico-lista').html(`<div class="alert alert-error">❌ Erro ao carregar histórico</div>`);
                }
            });
        }

        function renderizarHistorico() {
            const searchTerm = $('#historico-search').val().toLowerCase().trim();
            const dataInicio = $('#historico-data-inicio').val();
            const dataFim = $('#historico-data-fim').val();
            
            let filtered = historicoData;
            if (searchTerm) {
                filtered = filtered.filter(item => 
                    (item.cliente_nome && item.cliente_nome.toLowerCase().includes(searchTerm)) ||
                    (item.cliente_email && item.cliente_email.toLowerCase().includes(searchTerm)) ||
                    (item.cliente_telefone && item.cliente_telefone.includes(searchTerm)) ||
                    (item.servico_nome && item.servico_nome.toLowerCase().includes(searchTerm))
                );
            }
            if (dataInicio) filtered = filtered.filter(item => item.data >= dataInicio);
            if (dataFim) filtered = filtered.filter(item => item.data <= dataFim);
            
            filtered.sort((a, b) => {
                if (a.data !== b.data) return b.data.localeCompare(a.data);
                return b.horario.localeCompare(a.horario);
            });
            
            const totalPages = Math.ceil(filtered.length / itemsPerPage);
            const start = (historicoPage - 1) * itemsPerPage;
            const paginated = filtered.slice(start, start + itemsPerPage);
            
            if (filtered.length === 0) {
                $('#historico-lista').html(`<p class="empty-message"><i class="fas fa-history" style="font-size: 2em; display: block; margin-bottom: 15px; color: #444;"></i>Nenhum serviço concluído no histórico</p>`);
                $('#historico-pagination').html('');
                return;
            }
            
            const totalValor = filtered.reduce((sum, item) => sum + (parseFloat(item.preco) || 0), 0);
            
            let html = `
                <div class="stats-resumo">
                    <span>📊 Total: <strong>${filtered.length}</strong> serviços</span>
                    <span>💰 Valor total: <strong>R$ ${totalValor.toFixed(2).replace('.', ',')}</strong></span>
                    <span>📅 Período: ${dataInicio || 'Desde o início'} ${dataFim ? `até ${formatarData(dataFim)}` : ''}</span>
                </div>
                <div class="agendamentos-container">
            `;
            
            paginated.forEach(item => {
                html += `
                    <div class="agendamento-item concluido">
                        <div class="info">
                            <div class="data-hora">📅 ${formatarData(item.data)} às ${item.horario_formatado || '--:--'}</div>
                            <div class="cliente">👤 ${item.cliente_nome || 'Cliente não informado'} ${item.cliente_telefone ? `<span class="telefone">📱 ${formatarTelefone(item.cliente_telefone)}</span>` : ''}</div>
                            <div class="servico">💇 ${item.servico_nome || 'Serviço não definido'} ${item.preco ? `- R$ ${parseFloat(item.preco).toFixed(2).replace('.', ',')}` : ''}</div>
                            ${item.observacoes ? `<div class="observacoes">📝 ${item.observacoes}</div>` : ''}
                            <div class="concluido-em">✅ Concluído em ${item.data_conclusao_formatada || formatarData(item.data)}</div>
                        </div>
                        <div class="actions">
                            <span class="status-badge status-concluido">Concluído ✅</span>
                            ${item.cliente_telefone ? `<button class="btn-action btn-whatsapp" onclick="enviarWhatsAppHistorico(${item.id})" title="WhatsApp"><i class="fab fa-whatsapp"></i></button>` : ''}
                            <button class="btn-action btn-restaurar" onclick="restaurarAgendamento(${item.id})" title="Restaurar"><i class="fas fa-undo"></i> Restaurar</button>
                        </div>
                    </div>
                `;
            });
            html += `</div>`;
            $('#historico-lista').html(html);
            
            let pagHtml = '';
            if (totalPages > 1) {
                pagHtml += `<button onclick="mudarPaginaHistorico(1)" ${historicoPage === 1 ? 'disabled' : ''}><i class="fas fa-angle-double-left"></i></button>`;
                pagHtml += `<button onclick="mudarPaginaHistorico(${historicoPage - 1})" ${historicoPage === 1 ? 'disabled' : ''}><i class="fas fa-angle-left"></i></button>`;
                for (let i = Math.max(1, historicoPage - 2); i <= Math.min(totalPages, historicoPage + 2); i++) {
                    pagHtml += `<button onclick="mudarPaginaHistorico(${i})" class="${i === historicoPage ? 'active' : ''}">${i}</button>`;
                }
                pagHtml += `<button onclick="mudarPaginaHistorico(${historicoPage + 1})" ${historicoPage === totalPages ? 'disabled' : ''}><i class="fas fa-angle-right"></i></button>`;
                pagHtml += `<button onclick="mudarPaginaHistorico(${totalPages})" ${historicoPage === totalPages ? 'disabled' : ''}><i class="fas fa-angle-double-right"></i></button>`;
            }
            $('#historico-pagination').html(pagHtml);
        }

        // ============================================
        // FILTROS
        // ============================================
        function filtrarAgendamentos() { currentPage = 1; renderizarAgendamentos(); }
        function limparFiltros() { $('#search-input').val(''); $('#status-filter').val('todos'); $('#data-filter').val(''); currentPage = 1; renderizarAgendamentos(); }
        function mudarPagina(page) { currentPage = page; renderizarAgendamentos(); }
        function filtrarHistorico() { historicoPage = 1; renderizarHistorico(); }
        function limparFiltrosHistorico() { $('#historico-search').val(''); $('#historico-data-inicio').val(''); $('#historico-data-fim').val(''); historicoPage = 1; renderizarHistorico(); }
        function mudarPaginaHistorico(page) { historicoPage = page; renderizarHistorico(); }

        // ============================================
        // AÇÕES
        // ============================================
        function marcarComoConcluido(id) {
            if (!confirm('Marcar este agendamento como concluído?')) return;
            $.ajax({
                url: 'concluir_agendamento.php',
                type: 'POST',
                data: { id: id },
                dataType: 'json',
                success: function(response) {
                    if (response.success) {
                        alert('✅ Agendamento concluído!');
                        carregarAgendamentos();
                        carregarHistorico();
                        atualizarStats();
                    } else {
                        alert('❌ ' + response.message);
                    }
                }
            });
        }

        function restaurarAgendamento(id) {
            if (!confirm('Restaurar este agendamento?')) return;
            $.ajax({
                url: 'restaurar_agendamento.php',
                type: 'POST',
                data: { id: id },
                dataType: 'json',
                success: function(response) {
                    if (response.success) {
                        alert('✅ Agendamento restaurado!');
                        carregarAgendamentos();
                        carregarHistorico();
                        atualizarStats();
                    } else {
                        alert('❌ ' + response.message);
                    }
                }
            });
        }

        function cancelarAgendamento(id) {
            if (!confirm('Cancelar este agendamento?')) return;
            $.ajax({
                url: 'cancelar_agendamento.php',
                type: 'POST',
                data: { id: id },
                dataType: 'json',
                success: function(response) {
                    if (response.success) {
                        alert('✅ Agendamento cancelado!');
                        carregarAgendamentos();
                        carregarHistorico();
                        atualizarStats();
                    } else {
                        alert('❌ ' + response.message);
                    }
                }
            });
        }

        function enviarWhatsApp(id) {
            const item = agendamentosData.find(a => a.id === id);
            if (!item || !item.cliente_telefone) { alert('⚠️ Cliente sem telefone.'); return; }
            enviarWhatsAppCliente(item);
        }

        function enviarWhatsAppHistorico(id) {
            const item = historicoData.find(a => a.id === id);
            if (!item || !item.cliente_telefone) { alert('⚠️ Cliente sem telefone.'); return; }
            enviarWhatsAppCliente(item);
        }

        function enviarWhatsAppCliente(item) {
            const telefone = item.cliente_telefone.replace(/\D/g, '');
            const nome = item.cliente_nome || 'Cliente';
            const data = formatarData(item.data);
            const hora = item.horario_formatado || '--:--';
            const servico = item.servico_nome || 'serviço';
            const mensagem = `Olá ${nome}! Tudo bem? \nAqui é do Thomaz Black Barbearia. \nSeu agendamento para ${data} às ${hora} (${servico}) está confirmado. \nQualquer dúvida, estamos à disposição! ✂️`;
            window.open(`https://wa.me/55${telefone}?text=${encodeURIComponent(mensagem)}`, '_blank');
        }

        // ============================================
        // REAGENDAR
        // ============================================
        function abrirModalReagendar(id) {
            const item = agendamentosData.find(a => a.id === id);
            if (!item) return;
            $('#reagendar-id').val(id);
            $('#reagendar-data').val(item.data);
            carregarHorariosDisponiveis(item.data);
            $('#modal-reagendar').addClass('active');
        }

        function fecharModalReagendar() { $('#modal-reagendar').removeClass('active'); }

        function carregarHorariosDisponiveis(data) {
            $.ajax({
                url: 'listar_horarios_disponiveis_barbeiro.php',
                type: 'POST',
                data: { data: data },
                dataType: 'json',
                success: function(response) {
                    const select = $('#reagendar-horario');
                    select.html('<option value="">Selecione um horário</option>');
                    if (response.horarios && response.horarios.length > 0) {
                        response.horarios.forEach(h => select.append(`<option value="${h}">${h}</option>`));
                    } else {
                        select.append('<option value="">Nenhum horário disponível</option>');
                    }
                }
            });
        }

        function confirmarReagendar() {
            const id = $('#reagendar-id').val();
            const data = $('#reagendar-data').val();
            const horario = $('#reagendar-horario').val();
            const motivo = $('#reagendar-motivo').val();
            if (!data || !horario) { alert('⚠️ Selecione data e horário.'); return; }
            $.ajax({
                url: 'reagendar_agendamento.php',
                type: 'POST',
                data: { id: id, data: data, horario: horario, motivo: motivo },
                dataType: 'json',
                success: function(response) {
                    if (response.success) {
                        alert('✅ Reagendado!');
                        fecharModalReagendar();
                        carregarAgendamentos();
                        carregarHistorico();
                    } else {
                        alert('❌ ' + response.message);
                    }
                }
            });
        }

        // ============================================
        // SERVIÇOS
        // ============================================
        function carregarServicos() {
            $('#servicos-container').html('<div class="loading"><div class="spinner"></div><p>Carregando...</p></div>');
            $.ajax({
                url: 'listar_servicos_barbeiro.php',
                type: 'POST',
                dataType: 'json',
                success: function(data) {
                    if (data.error) { $('#servicos-container').html('<div class="alert alert-error">❌ ' + data.error + '</div>'); return; }
                    if (data.length === 0) { $('#servicos-container').html('<p class="empty-message">Nenhum serviço cadastrado.</p>'); return; }
                    let html = '<div class="servicos-grid">';
                    data.forEach(function(s) {
                        html += `
                            <div class="servico-card" style="border-left-color: ${s.cor || '#c9a84c'};">
                                <div class="nome">${s.nome}</div>
                                <div class="preco">R$ ${parseFloat(s.preco).toFixed(2).replace('.', ',')}</div>
                                <div class="duracao">⏱️ ${s.duracao_minutos} min</div>
                                ${s.descricao ? `<div class="descricao">${s.descricao}</div>` : ''}
                                <div class="actions">
                                    <button class="btn-small btn-edit" onclick="editarServico(${s.id})">✏️ Editar</button>
                                    <button class="btn-small btn-delete" onclick="deletarServico(${s.id})">🗑️</button>
                                </div>
                            </div>
                        `;
                    });
                    html += '</div>';
                    $('#servicos-container').html(html);
                },
                error: function() { $('#servicos-container').html('<div class="alert alert-error">❌ Erro ao carregar serviços</div>'); }
            });
        }

        function abrirModalServico() {
            $('#modal-servico-title').text('✏️ Novo Serviço');
            $('#servico-form')[0].reset();
            $('#servico-id').val('');
            $('#servico-cor').val('#c9a84c');
            $('#modal-servico').addClass('active');
        }

        function fecharModalServico() { $('#modal-servico').removeClass('active'); }

        function salvarServico() {
            const data = {
                id: $('#servico-id').val(),
                nome: $('#servico-nome').val().trim(),
                descricao: $('#servico-descricao').val().trim(),
                preco: $('#servico-preco').val(),
                duracao: $('#servico-duracao').val(),
                cor: $('#servico-cor').val()
            };
            if (!data.nome || !data.preco || !data.duracao) { alert('⚠️ Preencha todos os campos.'); return; }
            $.ajax({
                url: 'salvar_servico_barbeiro.php',
                type: 'POST',
                data: data,
                dataType: 'json',
                success: function(response) {
                    if (response.success) {
                        alert('✅ ' + response.message);
                        fecharModalServico();
                        carregarServicos();
                    } else { alert('❌ ' + response.message); }
                }
            });
        }

        function editarServico(id) {
            $.ajax({
                url: 'buscar_servico_barbeiro.php',
                type: 'POST',
                data: { id: id },
                dataType: 'json',
                success: function(s) {
                    if (s.error) { alert('❌ ' + s.error); return; }
                    $('#modal-servico-title').text('✏️ Editar Serviço');
                    $('#servico-id').val(s.id);
                    $('#servico-nome').val(s.nome);
                    $('#servico-descricao').val(s.descricao || '');
                    $('#servico-preco').val(s.preco);
                    $('#servico-duracao').val(s.duracao_minutos);
                    $('#servico-cor').val(s.cor || '#c9a84c');
                    $('#modal-servico').addClass('active');
                }
            });
        }

        function deletarServico(id) {
            if (!confirm('Deletar este serviço?')) return;
            $.ajax({
                url: 'deletar_servico_barbeiro.php',
                type: 'POST',
                data: { id: id },
                dataType: 'json',
                success: function(response) {
                    if (response.success) { alert('✅ ' + response.message); carregarServicos(); } 
                    else { alert('❌ ' + response.message); }
                }
            });
        }

        // ============================================
        // HORÁRIOS
        // ============================================
        function aplicarPreset(horarios) {
            document.getElementById('add-horarios').value = horarios;
            const input = document.getElementById('add-horarios');
            input.style.borderColor = '#c9a84c';
            input.style.background = 'rgba(201,168,76,0.1)';
            setTimeout(() => { input.style.borderColor = '#2d2d2d'; input.style.background = 'rgba(0,0,0,0.3)'; }, 1000);
        }

        function limparCampoHorarios() { document.getElementById('add-horarios').value = ''; }

        function gerarHorariosAutomaticos() {
            const opcao = confirm('✅ OK = De hora em hora\n❌ Cancelar = De meia em meia hora');
            const horarios = [];
            if (opcao) { for (let h = 8; h <= 20; h++) horarios.push(String(h).padStart(2,'0') + ':00'); }
            else { for (let h = 8; h <= 20; h++) { horarios.push(String(h).padStart(2,'0') + ':00'); horarios.push(String(h).padStart(2,'0') + ':30'); } }
            document.getElementById('add-horarios').value = horarios.join(',');
            $('#add-resultado').html(`<div class="alert alert-success">✅ ${horarios.length} horários gerados!</div>`);
            setTimeout(() => $('#add-resultado').html(''), 3000);
        }

        function adicionarHorarios() {
            const data = $('#add-data').val();
            const horarios = $('#add-horarios').val();
            if (!data || !horarios) { $('#add-resultado').html('<div class="alert alert-warning">⚠️ Preencha data e horários</div>'); return; }
            $('#add-resultado').html('<div class="alert alert-info">⏳ Adicionando...</div>');
            $.ajax({
                url: 'adicionar_horarios_barbeiro.php',
                type: 'POST',
                data: { data: data, horarios: horarios },
                dataType: 'json',
                success: function(response) {
                    let html = '';
                    if (response.success) { html += `<div class="alert alert-success">✅ ${response.message}</div>`; document.getElementById('add-horarios').value = ''; carregarHorarios(); }
                    else { html += `<div class="alert alert-error">❌ ${response.message || 'Erro'}</div>`; }
                    if (response.errors && response.errors.length > 0) { html += `<div class="alert alert-warning">⚠️ ${response.errors.join('<br>')}</div>`; }
                    $('#add-resultado').html(html);
                    setTimeout(() => { if ($('#add-resultado .alert-success').length > 0) $('#add-resultado').html(''); }, 5000);
                },
                error: function() { $('#add-resultado').html('<div class="alert alert-error">❌ Erro no servidor</div>'); }
            });
        }

        function carregarHorarios() {
            const data = $('#list-data').val();
            if (!data) { $('#horarios-lista').html('<p style="color:#ffc107;text-align:center;padding:20px;">⚠️ Selecione uma data</p>'); return; }
            $('#horarios-lista').html(`<div style="text-align:center;padding:30px;color:#666;"><div class="spinner"></div><p>Carregando...</p></div>`);
            $.ajax({
                url: 'listar_horarios_barbeiro.php',
                type: 'POST',
                data: { data: data },
                dataType: 'json',
                success: function(response) {
                    if (response.error) {
                        if (response.error === 'Não autenticado') { alert('⚠️ Sessão expirou.'); window.location.href = 'login_barbeiro.php'; return; }
                        $('#horarios-lista').html(`<div class="alert alert-error">❌ ${response.error}</div>`); return;
                    }
                    if (!response.success) { $('#horarios-lista').html(`<div class="alert alert-error">❌ ${response.message || 'Erro'}</div>`); return; }
                    const horarios = response.horarios || [];
                    if (horarios.length === 0) {
                        $('#horarios-lista').html(`<div style="text-align:center;padding:40px 20px;"><p style="color:#666;font-size:1.1em;">📅 Nenhum horário para ${response.data_formatada || data}</p></div>`);
                        return;
                    }
                    const disponiveis = horarios.filter(h => h.status === 'disponivel');
                    const reservados = horarios.filter(h => h.status === 'reservado');
                    const pagos = horarios.filter(h => h.status === 'pago');
                    const cancelados = horarios.filter(h => h.status === 'cancelado');
                    let html = `<div style="display:flex;justify-content:space-between;flex-wrap:wrap;gap:10px;padding:15px;background:rgba(13,13,13,0.6);border-radius:10px;margin-bottom:15px;">
                        <div><span style="color:#aaa;">📅 ${response.data_formatada || data}</span><span style="color:#666;margin-left:10px;">| Total: <strong style="color:#fff;">${horarios.length}</strong></span></div>
                        <div style="display:flex;gap:15px;flex-wrap:wrap;">
                            <span style="color:#28a745;">🟢 ${disponiveis.length} disponíveis</span>
                            <span style="color:#ffc107;">🟡 ${reservados.length} reservados</span>
                            <span style="color:#17a2b8;">🔵 ${pagos.length} confirmados</span>
                            <span style="color:#dc3545;">🔴 ${cancelados.length} cancelados</span>
                        </div>
                    </div><div class="horarios-grid">`;
                    horarios.sort((a, b) => a.horario.localeCompare(b.horario));
                    horarios.forEach(item => {
                        const statusClass = item.status_class || 'status-' + item.status;
                        const statusLabel = item.status_label || item.status;
                        let clienteInfo = item.cliente_nome ? `<div class="cliente-info">👤 ${item.cliente_nome}</div>` : '';
                        let servicoInfo = item.servico_nome ? `<div class="servico-info">💇 ${item.servico_nome}</div>` : '';
                        html += `<div class="horario-item ${statusClass}">
                            <div class="hora">${item.horario_formatado || item.horario}</div>
                            <span class="status-badge">${statusLabel}</span>
                            ${servicoInfo}${clienteInfo}
                            ${item.status === 'disponivel' ? `<button class="btn-delete-small" onclick="deletarHorario(${item.id})"><i class="fas fa-trash"></i></button>` : ''}
                        </div>`;
                    });
                    html += `</div>`;
                    if (disponiveis.length > 0) {
                        html += `<div style="margin-top:15px;display:flex;gap:10px;justify-content:center;flex-wrap:wrap;padding:10px;background:rgba(13,13,13,0.6);border-radius:8px;">
                            <button onclick="limparHorariosDisponiveis()" style="padding:6px 18px;background:#dc3545;color:white;border:none;border-radius:6px;cursor:pointer;font-size:0.8em;font-weight:600;">🗑️ Limpar ${disponiveis.length} disponíveis</button>
                        </div>`;
                    }
                    $('#horarios-lista').html(html);
                },
                error: function() { $('#horarios-lista').html('<div class="alert alert-error">❌ Erro ao carregar horários</div>'); }
            });
        }

        function deletarHorario(id) {
            if (!confirm('Remover este horário?')) return;
            $.ajax({
                url: 'deletar_horario_barbeiro.php',
                type: 'POST',
                data: { id: id },
                dataType: 'json',
                success: function(response) {
                    if (response.success) { carregarHorarios(); } else { alert('❌ ' + response.message); }
                }
            });
        }

        function limparHorariosDisponiveis() {
            const data = $('#list-data').val();
            if (!data) return;
            if (!confirm(`Remover TODOS os horários disponíveis de ${data}?`)) return;
            $.ajax({
                url: 'limpar_horarios_barbeiro.php',
                type: 'POST',
                data: { data: data },
                dataType: 'json',
                success: function(response) {
                    if (response.success) { alert('✅ ' + response.message); carregarHorarios(); } 
                    else { alert('❌ ' + response.message); }
                }
            });
        }

        // ============================================
        // UTILITÁRIOS
        // ============================================
        function formatarData(data) {
            if (!data) return '--/--/----';
            const partes = data.split('-');
            const meses = ['Janeiro','Fevereiro','Março','Abril','Maio','Junho','Julho','Agosto','Setembro','Outubro','Novembro','Dezembro'];
            return `${parseInt(partes[2])} de ${meses[parseInt(partes[1])-1]} de ${partes[0]}`;
        }

        function formatarTelefone(telefone) {
            const clean = telefone.replace(/\D/g, '');
            if (clean.length === 11) return `(${clean.slice(0,2)}) ${clean.slice(2,7)}-${clean.slice(7)}`;
            if (clean.length === 10) return `(${clean.slice(0,2)}) ${clean.slice(2,6)}-${clean.slice(6)}`;
            return telefone;
        }

        function atualizarStats() {
            $.ajax({
                url: 'estatisticas_barbeiro.php',
                type: 'POST',
                dataType: 'json',
                success: function(data) {
                    if (data.success) {
                        const cards = document.querySelectorAll('.stats-grid .stat-card');
                        if (cards.length >= 5) {
                            cards[0].querySelector('.stat-number').textContent = data.total || 0;
                            cards[1].querySelector('.stat-number').textContent = data.hoje || 0;
                            cards[2].querySelector('.stat-number').textContent = data.pendentes || 0;
                            cards[3].querySelector('.stat-number').textContent = 'R$ ' + (data.faturamento ? parseFloat(data.faturamento).toFixed(2).replace('.', ',') : '0,00');
                            cards[4].querySelector('.stat-number').textContent = data.total_concluidos || 0;
                        }
                    }
                }
            });
        }

        // ============================================
        // EVENTOS
        // ============================================
        $('#list-data').on('change', carregarHorarios);
        $('#add-horarios').on('keypress', function(e) { if (e.which === 13) { e.preventDefault(); adicionarHorarios(); } });
        $('#reagendar-data').on('change', function() { if ($(this).val()) carregarHorariosDisponiveis($(this).val()); });

        $('.modal').on('click', function(e) { if (e.target === this) $(this).removeClass('active'); });

        // ============================================
        // INICIALIZAÇÃO
        // ============================================
        $(document).ready(function() {
            carregarAgendamentos();
            carregarHorarios();
            setTimeout(carregarHistorico, 500);
        });
    </script>
</body>
</html>
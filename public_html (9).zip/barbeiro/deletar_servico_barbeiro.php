<?php
session_start();
include("../config.php");

header('Content-Type: application/json');

if (!isset($_SESSION['barbeiro_id'])) {
    echo json_encode(['success' => false, 'message' => 'Não autenticado']);
    exit;
}

$barbeiro_id = $_SESSION['barbeiro_id'];
$id = $_POST['id'] ?? 0;

if (!$id) {
    echo json_encode(['success' => false, 'message' => 'ID não informado']);
    exit;
}

$conn = new mysqli($db_host, $db_user, $db_password, $db_name);

if ($conn->connect_error) {
    echo json_encode(['success' => false, 'message' => 'Erro de conexão: ' . $conn->connect_error]);
    exit;
}

// Verificar se tem agendamentos com este serviço
$sql = "SELECT COUNT(*) as total FROM horarios WHERE servico_id = ? AND barbeiro_id = ? AND status IN ('pago', 'reservado')";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ii", $id, $barbeiro_id);
$stmt->execute();
$result = $stmt->get_result();
$row = $result->fetch_assoc();

if ($row['total'] > 0) {
    // Apenas desativar
    $sql = "UPDATE servicos_barbeiro SET ativo = 0 WHERE id = ? AND barbeiro_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ii", $id, $barbeiro_id);
    $msg = "Serviço desativado (tem agendamentos)";
} else {
    $sql = "DELETE FROM servicos_barbeiro WHERE id = ? AND barbeiro_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ii", $id, $barbeiro_id);
    $msg = "Serviço deletado";
}

if ($stmt->execute()) {
    echo json_encode(['success' => true, 'message' => $msg]);
} else {
    echo json_encode(['success' => false, 'message' => 'Erro ao deletar: ' . $conn->error]);
}

$conn->close();
?>
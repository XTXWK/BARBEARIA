<?php
session_start();
include("../config.php");

// Verificar se está logado
if (!isset($_SESSION['barbeiro_id'])) {
    echo json_encode(['error' => 'Não autenticado']);
    exit;
}

$barbeiro_id = $_SESSION['barbeiro_id'];

$conn = new mysqli($db_host, $db_user, $db_password, $db_name);

if ($conn->connect_error) {
    echo json_encode(['error' => 'Erro de conexão: ' . $conn->connect_error]);
    exit;
}

// Buscar todos os agendamentos do barbeiro
// Usando a estrutura REAL da tabela
$sql = "SELECT 
            h.id,
            h.data,
            h.horario,
            h.status,
            h.preco,
            h.observacoes,
            h.cliente_nome,
            h.cliente_email,
            h.cliente_telefone,
            h.created_at,
            h.referencia_pagamento,
            s.nome as servico_nome,
            s.duracao_minutos,
            s.preco as servico_preco
        FROM horarios h
        LEFT JOIN servicos_barbeiro s ON h.servico_id = s.id
        WHERE h.barbeiro_id = ? 
        AND h.status IN ('pago', 'concluido', 'reservado')
        ORDER BY h.data DESC, h.horario DESC";

$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $barbeiro_id);
$stmt->execute();
$result = $stmt->get_result();

$agendamentos = [];

while ($row = $result->fetch_assoc()) {
    // Formatar horário para exibição
    $row['horario_formatado'] = isset($row['horario']) ? substr($row['horario'], 0, 5) : '--:--';
    
    // Formatar data para exibição
    $row['data_formatada'] = isset($row['data']) ? date('d/m/Y', strtotime($row['data'])) : '--/--/----';
    
    // Data de criação como data de conclusão (aproximação)
    $row['data_conclusao_formatada'] = isset($row['created_at']) ? date('d/m/Y H:i', strtotime($row['created_at'])) : '-';
    
    // Garantir valores padrão
    $row['cliente_nome'] = $row['cliente_nome'] ?? 'Cliente não informado';
    $row['cliente_telefone'] = $row['cliente_telefone'] ?? '';
    $row['servico_nome'] = $row['servico_nome'] ?? 'Serviço não definido';
    $row['preco'] = $row['preco'] ?? 0;
    $row['observacoes'] = $row['observacoes'] ?? '';
    
    $agendamentos[] = $row;
}

$conn->close();

echo json_encode([
    'success' => true,
    'agendamentos' => $agendamentos,
    'total' => count($agendamentos)
]);
?>
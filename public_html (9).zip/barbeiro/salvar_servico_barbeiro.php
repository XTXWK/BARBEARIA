<?php
session_start();
include("../config.php");

header('Content-Type: application/json');

if (!isset($_SESSION['barbeiro_id'])) {
    echo json_encode(['success' => false, 'message' => 'Não autenticado']);
    exit;
}

$barbeiro_id = $_SESSION['barbeiro_id'];
$id = $_POST['id'] ?? 0;
$nome = trim($_POST['nome'] ?? '');
$descricao = trim($_POST['descricao'] ?? '');
$preco = floatval($_POST['preco'] ?? 0);
$duracao = intval($_POST['duracao'] ?? 30);
$cor = $_POST['cor'] ?? '#c9a84c';

if (!$nome || $preco <= 0 || $duracao <= 0) {
    echo json_encode(['success' => false, 'message' => 'Dados inválidos']);
    exit;
}

$conn = new mysqli($db_host, $db_user, $db_password, $db_name);

if ($conn->connect_error) {
    echo json_encode(['success' => false, 'message' => 'Erro de conexão: ' . $conn->connect_error]);
    exit;
}

if ($id > 0) {
    // Verificar se pertence ao barbeiro
    $sql = "SELECT id FROM servicos_barbeiro WHERE id = ? AND barbeiro_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ii", $id, $barbeiro_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows == 0) {
        echo json_encode(['success' => false, 'message' => 'Serviço não encontrado']);
        $conn->close();
        exit;
    }
    
    $sql = "UPDATE servicos_barbeiro SET 
            nome = ?, 
            descricao = ?, 
            preco = ?, 
            duracao_minutos = ?, 
            cor = ? 
            WHERE id = ? AND barbeiro_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssdisii", $nome, $descricao, $preco, $duracao, $cor, $id, $barbeiro_id);
} else {
    $sql = "INSERT INTO servicos_barbeiro (barbeiro_id, nome, descricao, preco, duracao_minutos, cor) 
            VALUES (?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("issdis", $barbeiro_id, $nome, $descricao, $preco, $duracao, $cor);
}

if ($stmt->execute()) {
    echo json_encode(['success' => true, 'message' => 'Serviço salvo com sucesso']);
} else {
    echo json_encode(['success' => false, 'message' => 'Erro ao salvar: ' . $conn->error]);
}

$conn->close();
?>
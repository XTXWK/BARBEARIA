<?php
session_start();
include("../config.php");

header('Content-Type: application/json');

if (!isset($_SESSION['barbeiro_id'])) {
    echo json_encode(['error' => 'Não autenticado']);
    exit;
}

$barbeiro_id = $_SESSION['barbeiro_id'];
$data = $_POST['data'] ?? date('Y-m-d');

$conn = new mysqli($db_host, $db_user, $db_password, $db_name);

if ($conn->connect_error) {
    echo json_encode(['error' => 'Erro de conexão: ' . $conn->connect_error]);
    exit;
}

// Buscar horários disponíveis
$sql = "SELECT horario FROM horarios 
        WHERE data = ? AND barbeiro_id = ? AND status = 'disponivel'
        ORDER BY horario";

$stmt = $conn->prepare($sql);
$stmt->bind_param("si", $data, $barbeiro_id);
$stmt->execute();
$result = $stmt->get_result();

$horarios = [];
while ($row = $result->fetch_assoc()) {
    $horarios[] = substr($row['horario'], 0, 5);
}

$conn->close();

echo json_encode([
    'success' => true,
    'data' => $data,
    'horarios' => $horarios
]);
?>
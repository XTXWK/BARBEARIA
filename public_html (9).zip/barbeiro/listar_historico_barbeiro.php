<?php
session_start();
include("../config.php");

// Verificar se está logado
if (!isset($_SESSION['barbeiro_id'])) {
    echo json_encode(['error' => 'Não autenticado']);
    exit;
}

$barbeiro_id = $_SESSION['barbeiro_id'];

$conn = new mysqli($db_host, $db_user, $db_password, $db_name);

if ($conn->connect_error) {
    echo json_encode(['error' => 'Erro de conexão: ' . $conn->connect_error]);
    exit;
}

// ============================================
// BUSCAR TODOS OS AGENDAMENTOS DO HISTÓRICO
// ============================================
$hoje = date('Y-m-d');
$hora_atual = date('H:i:s');

// Buscar:
// 1. Status 'concluido' 
// 2. Status 'pago' com data < hoje
// 3. Status 'pago' com data = hoje e horário < hora atual
$sql = "SELECT 
            h.id,
            h.data,
            h.horario,
            h.status,
            h.preco,
            h.observacoes,
            h.cliente_nome,
            h.cliente_email,
            h.cliente_telefone,
            h.created_at,
            h.referencia_pagamento,
            s.nome as servico_nome,
            s.duracao_minutos,
            s.preco as servico_preco
        FROM horarios h
        LEFT JOIN servicos_barbeiro s ON h.servico_id = s.id
        WHERE h.barbeiro_id = ? 
        AND h.status IN ('pago', 'concluido')
        AND (
            h.data < ? 
            OR (h.data = ? AND h.horario < ?)
            OR h.status = 'concluido'
        )
        ORDER BY h.data DESC, h.horario DESC";

$stmt = $conn->prepare($sql);

if (!$stmt) {
    echo json_encode(['error' => 'Erro na query: ' . $conn->error]);
    $conn->close();
    exit;
}

$stmt->bind_param("isss", $barbeiro_id, $hoje, $hoje, $hora_atual);
$stmt->execute();
$result = $stmt->get_result();

$historico = [];

while ($row = $result->fetch_assoc()) {
    // Formatar horário para exibição
    $row['horario_formatado'] = isset($row['horario']) ? substr($row['horario'], 0, 5) : '--:--';
    
    // Formatar data para exibição
    $row['data_formatada'] = isset($row['data']) ? date('d/m/Y', strtotime($row['data'])) : '--/--/----';
    
    // Data de criação
    $row['data_conclusao_formatada'] = isset($row['created_at']) ? date('d/m/Y H:i', strtotime($row['created_at'])) : '-';
    
    // Status para exibição
    $status_labels = [
        'pago' => '✅ Confirmado (Finalizado)',
        'concluido' => '✅ Concluído',
        'reservado' => '📌 Reservado',
        'cancelado' => '❌ Cancelado',
        'disponivel' => '🟢 Disponível'
    ];
    $row['status_label'] = $status_labels[$row['status']] ?? $row['status'];
    $row['status_class'] = 'status-' . $row['status'];
    
    // Garantir que campos nulos tenham valores padrão
    $row['cliente_nome'] = $row['cliente_nome'] ?? 'Cliente não informado';
    $row['cliente_email'] = $row['cliente_email'] ?? '';
    $row['cliente_telefone'] = $row['cliente_telefone'] ?? '';
    $row['servico_nome'] = $row['servico_nome'] ?? 'Serviço não definido';
    $row['preco'] = $row['preco'] ?? 0;
    $row['observacoes'] = $row['observacoes'] ?? '';
    
    $historico[] = $row;
}

$stmt->close();
$conn->close();

echo json_encode([
    'success' => true,
    'historico' => $historico,
    'total' => count($historico),
    'debug' => [
        'hoje' => $hoje,
        'hora_atual' => $hora_atual,
        'quantidade' => count($historico)
    ]
]);
?>
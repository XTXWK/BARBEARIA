<?php
session_start();
include("../config.php");

header('Content-Type: application/json');

if (!isset($_SESSION['barbeiro_id'])) {
    echo json_encode(['success' => false, 'message' => 'Não autenticado']);
    exit;
}

$barbeiro_id = $_SESSION['barbeiro_id'];
$id = $_POST['id'] ?? 0;

if (!$id) {
    echo json_encode(['success' => false, 'message' => 'ID não informado']);
    exit;
}

$conn = new mysqli($db_host, $db_user, $db_password, $db_name);

if ($conn->connect_error) {
    echo json_encode(['success' => false, 'message' => 'Erro de conexão: ' . $conn->connect_error]);
    exit;
}

// Verificar se o horário pertence ao barbeiro e está disponível
$sql = "SELECT status FROM horarios WHERE id = ? AND barbeiro_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ii", $id, $barbeiro_id);
$stmt->execute();
$result = $stmt->get_result();
$row = $result->fetch_assoc();

if (!$row) {
    echo json_encode(['success' => false, 'message' => 'Horário não encontrado']);
    $conn->close();
    exit;
}

if ($row['status'] !== 'disponivel') {
    echo json_encode(['success' => false, 'message' => 'Não é possível remover um horário reservado ou pago']);
    $conn->close();
    exit;
}

$sql = "DELETE FROM horarios WHERE id = ? AND barbeiro_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ii", $id, $barbeiro_id);

if ($stmt->execute()) {
    echo json_encode(['success' => true, 'message' => 'Horário removido com sucesso']);
} else {
    echo json_encode(['success' => false, 'message' => 'Erro ao remover: ' . $conn->error]);
}

$conn->close();
?>
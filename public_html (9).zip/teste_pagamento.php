<?php
include("config.php");

echo "<h1>Teste de Pagamentos</h1>";

$conn = new mysqli($db_host, $db_user, $db_password, $db_name);

if ($conn->connect_error) {
    die("Erro de conexão: " . $conn->connect_error);
}

echo "<p style='color:green;'>✅ Conectado ao banco</p>";

// Listar pagamentos
$sql = "SELECT * FROM pagamentos ORDER BY id DESC LIMIT 10";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    echo "<h2>Últimos 10 Pagamentos:</h2>";
    echo "<table border='1' cellpadding='8'>";
    echo "<tr>
            <th>ID</th>
            <th>Referência</th>
            <th>Payment ID</th>
            <th>Cliente</th>
            <th>Valor</th>
            <th>Status</th>
            <th>Data</th>
            <th>Ações</th>
          </tr>";
    while ($row = $result->fetch_assoc()) {
        $statusColor = $row['status'] == 'approved' ? 'green' : ($row['status'] == 'pending' ? 'orange' : 'red');
        echo "<tr>";
        echo "<td>" . $row['id'] . "</td>";
        echo "<td>" . $row['referencia'] . "</td>";
        echo "<td>" . ($row['payment_id'] ?? '—') . "</td>";
        echo "<td>" . ($row['cliente_nome'] ?? '—') . "</td>";
        echo "<td>R$ " . number_format($row['valor'] ?? 0, 2, ',', '.') . "</td>";
        echo "<td style='color:$statusColor; font-weight:bold;'>" . $row['status'] . "</td>";
        echo "<td>" . $row['data_criacao'] . "</td>";
        echo "<td>";
        if ($row['status'] == 'pending') {
            echo "<a href='api/verificar_manual.php?ref=" . $row['referencia'] . "' target='_blank'>Verificar</a>";
        }
        echo "</td>";
        echo "</tr>";
    }
    echo "</table>";
} else {
    echo "<p style='color:orange;'>⚠️ Nenhum pagamento encontrado</p>";
}

$conn->close();
?>
<?php
include("../config.php");

echo "<h1>🧪 Teste do Create.php</h1>";

// Dados de teste
$test_data = [
    'barbeiro_id' => 3,
    'servico_id' => 1,
    'data' => date('Y-m-d'),
    'horario' => '10:00',
    'nome' => 'Teste Silva',
    'email' => 'teste@email.com',
    'telefone' => '27999999999',
    'observacoes' => 'Teste',
    'preco' => 1.00
];

echo "<h3>📤 Enviando dados:</h3>";
echo "<pre>";
print_r($test_data);
echo "</pre>";

$ch = curl_init('https://cardosodistribuidora.com.br/api/create.php');
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($test_data));
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);

$response = curl_exec($ch);
$http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$curl_error = curl_error($ch);
curl_close($ch);

echo "<h3>📥 Resposta:</h3>";
echo "<p>HTTP Code: <strong>" . $http_code . "</strong></p>";

if ($curl_error) {
    echo "<p style='color:red;'>❌ Erro cURL: " . $curl_error . "</p>";
} else {
    echo "<p>Resposta:</p>";
    echo "<pre style='background:#1a1a1a;padding:15px;border-radius:10px;color:#0f0;overflow-x:auto;'>";
    echo htmlspecialchars($response);
    echo "</pre>";
    
    $data = json_decode($response, true);
    if ($data) {
        echo "<h3>📊 Dados decodificados:</h3>";
        echo "<pre>";
        print_r($data);
        echo "</pre>";
        
        if (isset($data['error'])) {
            echo "<p style='color:red;font-size:1.2em;'>❌ ERRO: " . $data['error'] . "</p>";
        } elseif (isset($data['qr_code_base64'])) {
            echo "<p style='color:green;font-size:1.2em;'>✅ QR Code gerado com sucesso!</p>";
            echo "<img src='data:image/png;base64," . $data['qr_code_base64'] . "' style='max-width:250px;'>";
        } else {
            echo "<p style='color:orange;'>⚠️ Resposta inesperada</p>";
        }
    }
}
?>
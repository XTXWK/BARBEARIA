<?php
header('Access-Control-Allow-Origin: *');
date_default_timezone_set('America/Sao_Paulo');

// Configurações do Banco de Dados - Hostinger
$db_host = "localhost";
$db_user = "u574500959_xtxwknr";
$db_password = "Kamaitachi3301";
$db_name = "u574500959_nr";

// Token do Mercado Pago - PRODUÇÃO
$acess_token = "APP_USR-5001768888617272-081914-b9971a48cd93bfe749d9ff322cd71df2-1976176579"; // COLE SEU TOKEN AQUI

// URL de notificação - URL COMPLETA DO SEU SITE
$notification_url = "https://cardosodistribuidora.com.br/api/notification.php"; // SUBSTITUA PELA URL DO SEU SITE

// Configurações
$valor_padrao = 30.00;
$senha_admin = 'admin123';

// Log de erros
error_log("Config carregada - Token: " . substr($acess_token, 0, 10) . "...");
?>
<?php
// 🔥 REMOVA session_start() - NÃO precisa de autenticação!
include("../config.php");

header('Content-Type: application/json');

$data = $_POST['data'] ?? date('Y-m-d');
$barbeiro_id = $_POST['barbeiro_id'] ?? 0;

if (!$barbeiro_id) {
    echo json_encode(['error' => 'Barbeiro não informado']);
    exit;
}

$conn = new mysqli($db_host, $db_user, $db_password, $db_name);

if ($conn->connect_error) {
    echo json_encode(['error' => 'Erro de conexão: ' . $conn->connect_error]);
    exit;
}

// 🔥 Busca SEM verificar sessão
$sql = "SELECT horario, status FROM horarios 
        WHERE data = ? AND barbeiro_id = ? AND status = 'disponivel'
        ORDER BY horario";

$stmt = $conn->prepare($sql);
$stmt->bind_param("si", $data, $barbeiro_id);
$stmt->execute();
$result = $stmt->get_result();

$horarios = [];
while ($row = $result->fetch_assoc()) {
    $horarios[] = [
        'horario' => substr($row['horario'], 0, 5),
        'disponivel' => true,
        'status' => $row['status']
    ];
}

$conn->close();

echo json_encode($horarios);
?>
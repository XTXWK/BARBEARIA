<?php
include("../config.php");

header('Content-Type: application/json');

$conn = new mysqli($db_host, $db_user, $db_password, $db_name);

if ($conn->connect_error) {
    echo json_encode(['error' => 'Erro de conexão: ' . $conn->connect_error]);
    exit;
}

$sql = "SELECT id, nome, especialidades, foto FROM barbeiros WHERE ativo = 1 ORDER BY nome";
$result = $conn->query($sql);

if (!$result) {
    echo json_encode(['error' => 'Erro na consulta: ' . $conn->error]);
    $conn->close();
    exit;
}

$barbeiros = [];
while ($row = $result->fetch_assoc()) {
    // Se não tiver foto, usar avatar gerado
    if (empty($row['foto'])) {
        $row['foto'] = 'https://ui-avatars.com/api/?name=' . urlencode($row['nome']) . '&background=c9a84c&color=0a0a0a&size=200&bold=true';
    }
    $barbeiros[] = $row;
}

$conn->close();

echo json_encode($barbeiros);
?>
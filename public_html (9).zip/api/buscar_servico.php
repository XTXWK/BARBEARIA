<?php
include("../config.php");

$id = $_POST['id'] ?? 0;

$conn = new mysqli($db_host, $db_user, $db_password, $db_name);

if ($conn->connect_error) {
    die(json_encode(['error' => 'Erro de conexão']));
}

$sql = "SELECT * FROM servicos WHERE id = ? AND ativo = 1";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$servico = $result->fetch_assoc();

$conn->close();

if (!$servico) {
    die(json_encode(['error' => 'Serviço não encontrado']));
}

header('Content-Type: application/json');
echo json_encode($servico);
?>
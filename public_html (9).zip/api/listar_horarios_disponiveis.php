<?php
include("../config.php");

$data = $_POST['data'] ?? date('Y-m-d');
$servico_id = $_POST['servico_id'] ?? 0;
$barbeiro_id = $_POST['barbeiro_id'] ?? 0;

if (!$servico_id) {
    die(json_encode(['error' => 'Serviço não informado']));
}

if (!$barbeiro_id) {
    die(json_encode(['error' => 'Barbeiro não informado']));
}

$conn = new mysqli($db_host, $db_user, $db_password, $db_name);

if ($conn->connect_error) {
    die(json_encode(['error' => 'Erro de conexão: ' . $conn->connect_error]));
}

// Buscar horários do barbeiro para a data
$sql = "SELECT horario, status FROM horarios 
        WHERE data = ? AND barbeiro_id = ? 
        ORDER BY horario";
$stmt = $conn->prepare($sql);
$stmt->bind_param("si", $data, $barbeiro_id);
$stmt->execute();
$result = $stmt->get_result();

$horarios_existentes = [];
while ($row = $result->fetch_assoc()) {
    $horarios_existentes[$row['horario']] = $row;
}

// Gerar horários disponíveis (de hora em hora)
$hora_inicio = 8;
$hora_fim = 22;
$horarios_disponiveis = [];

for ($h = $hora_inicio; $h <= $hora_fim; $h++) {
    $horario_str = sprintf("%02d:00:00", $h);
    $horario_exibicao = sprintf("%02d:00", $h);
    
    if (isset($horarios_existentes[$horario_str])) {
        $status = $horarios_existentes[$horario_str]['status'];
        $disponivel = ($status == 'disponivel');
    } else {
        // Criar horário disponível automaticamente
        $sql_insert = "INSERT INTO horarios (data, horario, barbeiro_id, status) 
                      VALUES (?, ?, ?, 'disponivel')";
        $stmt_insert = $conn->prepare($sql_insert);
        $stmt_insert->bind_param("ssi", $data, $horario_str, $barbeiro_id);
        $stmt_insert->execute();
        $disponivel = true;
        $status = 'disponivel';
    }
    
    $horarios_disponiveis[] = [
        'horario' => $horario_exibicao,
        'horario_completo' => $horario_str,
        'disponivel' => $disponivel,
        'status' => $status
    ];
}

$conn->close();

header('Content-Type: application/json');
echo json_encode($horarios_disponiveis);
?>
<?php
error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);

include("../config.php");

// Função de log
function logDebug($msg) {
    error_log("[VERIFY] " . date('Y-m-d H:i:s') . " - " . $msg);
}

logDebug("=== VERIFY INICIADO ===");
logDebug("POST: " . print_r($_POST, true));

$reference = $_POST['ref'] ?? '';

if (!$reference) {
    logDebug("ERRO: Referência não informada");
    echo json_encode(['status' => 'error', 'message' => 'Referência não informada']);
    exit;
}

$conn = new mysqli($db_host, $db_user, $db_password, $db_name);

if ($conn->connect_error) {
    logDebug("ERRO CONEXÃO: " . $conn->connect_error);
    echo json_encode(['status' => 'error', 'message' => 'Erro de conexão']);
    exit;
}

// Buscar pagamento
$sql = "SELECT * FROM pagamentos WHERE referencia = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $reference);
$stmt->execute();
$result = $stmt->get_result();
$pagamento = $result->fetch_assoc();

if (!$pagamento) {
    logDebug("ERRO: Pagamento não encontrado - $reference");
    $conn->close();
    echo json_encode(['status' => 'error', 'message' => 'Pagamento não encontrado']);
    exit;
}

logDebug("Pagamento encontrado: " . print_r($pagamento, true));

// Se já está aprovado
if ($pagamento['status'] == 'approved') {
    logDebug("Pagamento já aprovado");
    $conn->close();
    echo json_encode(['status' => 'approved', 'message' => 'Pagamento já confirmado']);
    exit;
}

$paymentId = $pagamento['payment_id'];
logDebug("Payment ID: $paymentId");

// CONSULTAR MERCADO PAGO
$curl = curl_init();
curl_setopt_array($curl, [
    CURLOPT_URL => 'https://api.mercadopago.com/v1/payments/' . $paymentId,
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_HTTPHEADER => [
        'Authorization: Bearer ' . $acess_token,
        'Content-Type: application/json'
    ],
    CURLOPT_TIMEOUT => 30,
    CURLOPT_SSL_VERIFYPEER => false // Para teste em desenvolvimento
]);

$response = curl_exec($curl);
$http_code = curl_getinfo($curl, CURLINFO_HTTP_CODE);
$curl_error = curl_error($curl);
curl_close($curl);

logDebug("HTTP Code: $http_code");
logDebug("Resposta MP: " . $response);

if ($curl_error) {
    logDebug("ERRO cURL: $curl_error");
    $conn->close();
    echo json_encode(['status' => 'error', 'message' => 'Erro ao consultar MP: ' . $curl_error]);
    exit;
}

if ($http_code != 200) {
    logDebug("HTTP Code não é 200: $http_code");
    $conn->close();
    echo json_encode(['status' => 'error', 'message' => 'Erro na consulta: HTTP ' . $http_code]);
    exit;
}

$data = json_decode($response, true);
$status = $data['status'] ?? 'unknown';

logDebug("Status do MP: $status");

// Se aprovado, processar
if ($status == 'approved') {
    logDebug("=== PROCESSANDO APROVAÇÃO ===");
    
    $data_agendada = $pagamento['data_agendada'];
    $horario_agendado = $pagamento['horario_agendado'];
    $barbeiro_id = $pagamento['barbeiro_id'];
    $servico_id = $pagamento['servico_id'];
    $valor = $pagamento['valor'];
    $cliente_nome = $pagamento['cliente_nome'];
    $cliente_email = $pagamento['cliente_email'];
    $cliente_telefone = $pagamento['cliente_telefone'];
    $observacoes = $pagamento['observacoes'];
    
    // 1. Verificar/ Criar horário
    $sql = "SELECT id, status FROM horarios 
            WHERE data = ? AND horario = ? AND barbeiro_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssi", $data_agendada, $horario_agendado, $barbeiro_id);
    $stmt->execute();
    $result = $conn->query($sql);
    $horario = $result->fetch_assoc();
    
    if (!$horario) {
        logDebug("Criando horário...");
        $sql = "INSERT INTO horarios (data, horario, barbeiro_id, status) 
                VALUES (?, ?, ?, 'disponivel')";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ssi", $data_agendada, $horario_agendado, $barbeiro_id);
        $stmt->execute();
        $horario_id = $conn->insert_id;
        logDebug("Horário criado: $horario_id");
    } else {
        if ($horario['status'] != 'disponivel') {
            logDebug("Horário NÃO disponível: " . $horario['status']);
            $conn->close();
            echo json_encode(['status' => 'error', 'message' => 'Horário não está mais disponível']);
            exit;
        }
        $horario_id = $horario['id'];
        logDebug("Horário existente: $horario_id");
    }
    
    // 2. Atualizar horário
    $sql = "UPDATE horarios SET 
            status = 'pago',
            servico_id = ?,
            cliente_nome = ?,
            cliente_email = ?,
            cliente_telefone = ?,
            referencia_pagamento = ?,
            preco = ?,
            observacoes = ?
            WHERE id = ?";
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param(
        "issssdsi",
        $servico_id,
        $cliente_nome,
        $cliente_email,
        $cliente_telefone,
        $reference,
        $valor,
        $observacoes,
        $horario_id
    );
    
    if ($stmt->execute()) {
        logDebug("Horário atualizado: $horario_id");
    } else {
        logDebug("ERRO ao atualizar horário: " . $stmt->error);
    }
    
    // 3. Atualizar pagamento
    $sql = "UPDATE pagamentos SET status = 'approved', horario_id = ? WHERE referencia = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("is", $horario_id, $reference);
    
    if ($stmt->execute()) {
        logDebug("Pagamento atualizado para approved: $reference");
    } else {
        logDebug("ERRO ao atualizar pagamento: " . $stmt->error);
    }
    
    $conn->close();
    echo json_encode(['status' => 'approved', 'message' => 'Pagamento confirmado!']);
    exit;
}

// Se não aprovado
$conn->close();
logDebug("Pagamento NÃO aprovado. Status: $status");
echo json_encode(['status' => $status, 'message' => 'Aguardando pagamento...']);
?>
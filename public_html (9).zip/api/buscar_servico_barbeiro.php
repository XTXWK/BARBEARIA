<?php
include("../config.php");

header('Content-Type: application/json');

$id = $_POST['id'] ?? 0;

if (!$id) {
    echo json_encode(['error' => 'ID não informado']);
    exit;
}

$conn = new mysqli($db_host, $db_user, $db_password, $db_name);

if ($conn->connect_error) {
    echo json_encode(['error' => 'Erro de conexão: ' . $conn->connect_error]);
    exit;
}

// 🔥 Buscar serviço na tabela correta
$sql = "SELECT * FROM servicos_barbeiro WHERE id = ? AND ativo = 1";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$servico = $result->fetch_assoc();

$conn->close();

if (!$servico) {
    echo json_encode(['error' => 'Serviço não encontrado ou inativo']);
    exit;
}

// 🔥 GARANTIR que o preço é um número válido
$servico['preco'] = floatval($servico['preco']);

echo json_encode($servico);
?>
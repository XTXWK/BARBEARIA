<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('log_errors', 1);

include("../config.php");

function logDebug($message) {
    error_log("[NOTIFICATION] " . date('Y-m-d H:i:s') . " - " . $message);
}

logDebug("=== WEBHOOK RECEBIDO ===");

// 🔥 LOG DE TUDO QUE CHEGOU
$input = file_get_contents('php://input');
logDebug("RAW INPUT: " . $input);
logDebug("POST: " . print_r($_POST, true));
logDebug("GET: " . print_r($_GET, true));
logDebug("SERVER: " . print_r($_SERVER, true));

// Tenta pegar o ID de várias formas
$paymentId = null;

// 1. Via POST (padrão do MP)
if (isset($_POST['id'])) {
    $paymentId = $_POST['id'];
    logDebug("✅ ID encontrado no POST: " . $paymentId);
}

// 2. Via GET (fallback)
if (!$paymentId && isset($_GET['id'])) {
    $paymentId = $_GET['id'];
    logDebug("✅ ID encontrado no GET: " . $paymentId);
}

// 3. Via JSON (se vier como JSON)
if (!$paymentId && $input) {
    $data = json_decode($input, true);
    if ($data && isset($data['id'])) {
        $paymentId = $data['id'];
        logDebug("✅ ID encontrado no JSON: " . $paymentId);
    }
}

if (!$paymentId) {
    logDebug("❌ Nenhum ID encontrado!");
    http_response_code(400);
    die(json_encode(['status' => 'error', 'message' => 'Payment ID não encontrado']));
}

logDebug("✅ Payment ID final: " . $paymentId);

$conn = new mysqli($db_host, $db_user, $db_password, $db_name);

if ($conn->connect_error) {
    logDebug("ERRO CONEXÃO: " . $conn->connect_error);
    http_response_code(500);
    die(json_encode(['status' => 'error', 'message' => 'Erro de conexão']));
}

// 🔥 PRIMEIRO: Verifica se o pagamento existe na tabela
$sql = "SELECT * FROM pagamentos WHERE payment_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $paymentId);
$stmt->execute();
$result = $stmt->get_result();
$pagamento = $result->fetch_assoc();

if (!$pagamento) {
    logDebug("❌ Pagamento NÃO encontrado para payment_id: " . $paymentId);
    
    // 🔥 TENTA BUSCAR POR REFERÊNCIA (fallback)
    $sql = "SELECT * FROM pagamentos WHERE referencia = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $paymentId);
    $stmt->execute();
    $result = $stmt->get_result();
    $pagamento = $result->fetch_assoc();
    
    if ($pagamento) {
        logDebug("✅ Pagamento encontrado por referência: " . $paymentId);
    } else {
        logDebug("❌ Pagamento NÃO encontrado por referência também!");
        
        // 🔥 LISTA TODOS OS PAGAMENTOS RECENTES PARA DEBUG
        $sql = "SELECT id, payment_id, referencia, status, data_criacao FROM pagamentos ORDER BY id DESC LIMIT 5";
        $result = $conn->query($sql);
        $recentes = [];
        while ($row = $result->fetch_assoc()) {
            $recentes[] = $row;
        }
        logDebug("Últimos pagamentos: " . print_r($recentes, true));
        
        $conn->close();
        http_response_code(404);
        die(json_encode(['status' => 'error', 'message' => 'Pagamento não encontrado']));
    }
}

logDebug("✅ Pagamento encontrado: " . print_r($pagamento, true));

// 🔥 BUSCA O STATUS NO MERCADO PAGO
$curl = curl_init();
curl_setopt_array($curl, [
    CURLOPT_URL => 'https://api.mercadopago.com/v1/payments/' . $paymentId,
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_CUSTOMREQUEST => 'GET',
    CURLOPT_HTTPHEADER => [
        'accept: application/json',
        'content-type: application/json',
        'Authorization: Bearer ' . $acess_token
    ],
    CURLOPT_TIMEOUT => 30,
    CURLOPT_SSL_VERIFYPEER => false // Para teste
]);

$response = curl_exec($curl);
$curl_error = curl_error($curl);
$http_code = curl_getinfo($curl, CURLINFO_HTTP_CODE);
curl_close($curl);

if ($curl_error) {
    logDebug("ERRO cURL: $curl_error");
    $conn->close();
    http_response_code(500);
    die(json_encode(['status' => 'error', 'message' => 'Erro ao consultar MP']));
}

logDebug("HTTP Code MP: $http_code");
logDebug("Resposta MP: " . $response);

if ($http_code != 200) {
    logDebug("❌ MP retornou erro: HTTP $http_code");
    $conn->close();
    http_response_code($http_code);
    die(json_encode(['status' => 'error', 'message' => 'Erro ao consultar MP: HTTP ' . $http_code]));
}

$response_data = json_decode($response, true);
$status = $response_data['status'] ?? '';

logDebug("Status do pagamento no MP: " . $status);

// 🔥 PROCESSAR APROVAÇÃO
if ($status == "approved" && $pagamento['status'] != 'approved') {
    logDebug("✅ PROCESSANDO APROVAÇÃO...");
    
    $data_agendada = $pagamento['data_agendada'];
    $horario_agendado = $pagamento['horario_agendado'];
    $barbeiro_id = $pagamento['barbeiro_id'];
    $servico_id = $pagamento['servico_id'];
    $reference = $pagamento['referencia'];
    
    // Verificar/ Criar horário
    $sql = "SELECT id, status FROM horarios 
            WHERE data = ? AND horario = ? AND barbeiro_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssi", $data_agendada, $horario_agendado, $barbeiro_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $horario = $result->fetch_assoc();
    
    if (!$horario) {
        logDebug("Criando horário...");
        $sql = "INSERT INTO horarios (data, horario, barbeiro_id, status) 
                VALUES (?, ?, ?, 'disponivel')";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ssi", $data_agendada, $horario_agendado, $barbeiro_id);
        $stmt->execute();
        $horario_id = $conn->insert_id;
        logDebug("Horário criado: $horario_id");
    } else {
        if ($horario['status'] != 'disponivel' && $horario['status'] != 'pago') {
            logDebug("⚠️ Horário com status inesperado: " . $horario['status']);
        }
        $horario_id = $horario['id'];
        logDebug("Horário existente: $horario_id");
    }
    
    // Atualizar horário
    $sql = "UPDATE horarios SET 
            status = 'pago',
            servico_id = ?,
            cliente_nome = ?,
            cliente_email = ?,
            cliente_telefone = ?,
            referencia_pagamento = ?,
            preco = ?,
            observacoes = ?
            WHERE id = ?";
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param(
        "issssdsi",
        $servico_id,
        $pagamento['cliente_nome'],
        $pagamento['cliente_email'],
        $pagamento['cliente_telefone'],
        $reference,
        $pagamento['valor'],
        $pagamento['observacoes'],
        $horario_id
    );
    $stmt->execute();
    logDebug("Horário atualizado: $horario_id");
    
    // Atualizar pagamento
    $sql = "UPDATE pagamentos SET status = 'approved', horario_id = ? WHERE payment_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("is", $horario_id, $paymentId);
    $stmt->execute();
    logDebug("✅ Pagamento atualizado para approved: $paymentId");
}

$conn->close();

logDebug("=== WEBHOOK FINALIZADO ===");
http_response_code(200);
echo json_encode(['status' => $status, 'message' => 'Webhook processado']);
?>
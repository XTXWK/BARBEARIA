<?php
error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);
ini_set('error_log', __DIR__ . '/../logs/php_error.log');

include("../config.php");

// Criar pasta de logs se não existir
if (!is_dir(__DIR__ . '/../logs')) {
    mkdir(__DIR__ . '/../logs', 0755, true);
}

// Função para log
function logDebug($message) {
    error_log("[CREATE] " . date('Y-m-d H:i:s') . " - " . $message);
}

logDebug("=== NOVA REQUISIÇÃO CREATE ===");
logDebug("POST: " . print_r($_POST, true));

$conn = new mysqli($db_host, $db_user, $db_password, $db_name);

if ($conn->connect_error) {
    logDebug("ERRO CONEXÃO: " . $conn->connect_error);
    $response = ['error' => 'Erro de conexão com o banco: ' . $conn->connect_error];
    header('Content-Type: application/json');
    echo json_encode($response);
    exit;
}

// Dados recebidos
$servico_id = $_POST['servico_id'] ?? null;
$barbeiro_id = $_POST['barbeiro_id'] ?? null;
$data = $_POST['data'] ?? null;
$horario = $_POST['horario'] ?? null;
$nome = trim($_POST['nome'] ?? '');
$email = trim($_POST['email'] ?? '');
$telefone = $_POST['telefone'] ?? '';
$observacoes = $_POST['observacoes'] ?? '';
$preco = floatval($_POST['preco'] ?? 0);

logDebug("Dados processados: servico_id=$servico_id, barbeiro_id=$barbeiro_id, data=$data, horario=$horario, nome=$nome, email=$email, telefone=$telefone, preco=$preco");

// 🔥 VALIDAÇÕES RÍGIDAS
if (!$servico_id || !$barbeiro_id || !$data || !$horario) {
    logDebug("DADOS INCOMPLETOS: " . print_r($_POST, true));
    $response = ['error' => 'Dados incompletos. Selecione barbeiro, serviço, data e horário.'];
    header('Content-Type: application/json');
    echo json_encode($response);
    exit;
}

// 🔥 VALIDAÇÃO DO NOME - IMPEDE '0' ou vazio
if (empty($nome) || strlen($nome) < 2 || $nome === '0' || !preg_match('/^[A-Za-zÀ-ÿ\s]{2,}$/', $nome)) {
    logDebug("NOME INVÁLIDO: '$nome'");
    $response = ['error' => 'Nome inválido. Digite seu nome completo (apenas letras, mínimo 2 caracteres).'];
    header('Content-Type: application/json');
    echo json_encode($response);
    exit;
}

// 🔥 VALIDAÇÃO DO EMAIL
if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
    logDebug("EMAIL INVÁLIDO: '$email'");
    $response = ['error' => 'Email inválido. Digite um email válido.'];
    header('Content-Type: application/json');
    echo json_encode($response);
    exit;
}

// 🔥 VALIDAÇÃO DO TELEFONE
$telefoneLimpo = preg_replace('/\D/', '', $telefone);
if (empty($telefone) || strlen($telefoneLimpo) < 10 || strlen($telefoneLimpo) > 11) {
    logDebug("TELEFONE INVÁLIDO: '$telefone'");
    $response = ['error' => 'Telefone inválido. Digite com DDD (ex: 27999999999).'];
    header('Content-Type: application/json');
    echo json_encode($response);
    exit;
}

// 🔥 BUSCAR SERVIÇO - SEM verificar barbeiro_id (apenas garante que existe)
$sql = "SELECT nome, preco FROM servicos_barbeiro WHERE id = ? AND ativo = 1";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $servico_id);
$stmt->execute();
$result = $stmt->get_result();
$servico = $result->fetch_assoc();

if (!$servico) {
    logDebug("SERVIÇO NÃO ENCONTRADO: ID $servico_id");
    $response = ['error' => 'Serviço não encontrado ou inativo.'];
    header('Content-Type: application/json');
    echo json_encode($response);
    $conn->close();
    exit;
}

// 🔥 BUSCAR BARBEIRO
$sql = "SELECT nome FROM barbeiros WHERE id = ? AND ativo = 1";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $barbeiro_id);
$stmt->execute();
$result = $stmt->get_result();
$barbeiro = $result->fetch_assoc();

if (!$barbeiro) {
    logDebug("BARBEIRO NÃO ENCONTRADO: ID $barbeiro_id");
    $response = ['error' => 'Barbeiro não encontrado ou inativo.'];
    header('Content-Type: application/json');
    echo json_encode($response);
    $conn->close();
    exit;
}

// 🔥 VALOR - usa o preço do serviço ou o enviado
if ($preco <= 0) {
    $preco = floatval($servico['preco']);
}

// 🔥 FORÇA VALOR MÍNIMO DE R$ 1,00 para evitar rejeição do MP
if ($preco < 1.00) {
    logDebug("VALOR MUITO BAIXO: R$ $preco - Corrigindo para R$ 1.00");
    $preco = 1.00;
}

// 🔥 VALOR MÁXIMO PARA TESTE (opcional)
if ($preco > 1000) {
    logDebug("VALOR MUITO ALTO: R$ $preco - Corrigindo para R$ 1000.00");
    $preco = 1000.00;
}

$description = $servico['nome'] . " com " . $barbeiro['nome'] . " - " . date('d/m/Y', strtotime($data)) . " às " . $horario;

// Verificar token
if (empty($acess_token) || $acess_token == "SEU_ACESS_TOKEN_AQUI" || $acess_token == "APP_USR-xxxxxxxxxxxxxx") {
    logDebug("TOKEN NÃO CONFIGURADO");
    $response = ['error' => 'Token do Mercado Pago não configurado.'];
    header('Content-Type: application/json');
    echo json_encode($response);
    $conn->close();
    exit;
}

// Gerar referencia
$externalReference = geraString(24);

function geraString($length) {
    return substr(str_shuffle(str_repeat('0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ', $length)), 0, $length);
}

$uuid = generateUUID();
function generateUUID() {
    return sprintf(
        '%04x%04x-%04x-%04x-%04x-%04x%04x%04x',
        mt_rand(0, 0xffff),
        mt_rand(0, 0xffff),
        mt_rand(0, 0xffff),
        mt_rand(0, 0x0fff) | 0x4000,
        mt_rand(0, 0x3fff) | 0x8000,
        mt_rand(0, 0xffff),
        mt_rand(0, 0xffff),
        mt_rand(0, 0xffff)
    );
}

// 🔥 DADOS DO PAGAMENTO
$payment_data = [
    "transaction_amount" => floatval($preco),
    "description" => $description,
    "payment_method_id" => "pix",
    "external_reference" => $externalReference,
    "payer" => [
        "email" => $email,
        "first_name" => $nome,
        "last_name" => ""
    ],
    "notification_url" => $notification_url
];

$payment = json_encode($payment_data);
logDebug("Dados enviados ao MP: " . $payment);

// 🔥 CURL COM CONFIGURAÇÕES CORRETAS
$curl = curl_init();
curl_setopt_array($curl, [
    CURLOPT_URL => "https://api.mercadopago.com/v1/payments/",
    CURLOPT_CUSTOMREQUEST => 'POST',
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_POSTFIELDS => $payment,
    CURLOPT_HTTPHEADER => [
        'Authorization: Bearer ' . $acess_token,
        'X-Idempotency-Key: ' . $uuid,
        'Content-Type: application/json'
    ],
    CURLOPT_TIMEOUT => 60,
    CURLOPT_SSL_VERIFYPEER => false, // 🔥 Para teste em desenvolvimento
    CURLOPT_SSL_VERIFYHOST => false
]);

$response = curl_exec($curl);
$curl_error = curl_error($curl);
$http_code = curl_getinfo($curl, CURLINFO_HTTP_CODE);
curl_close($curl);

logDebug("HTTP Code: $http_code");
logDebug("Resposta MP: " . $response);

if ($curl_error) {
    logDebug("ERRO cURL: $curl_error");
    $response_error = ['error' => 'Erro de conexão com o Mercado Pago: ' . $curl_error];
    header('Content-Type: application/json');
    echo json_encode($response_error);
    $conn->close();
    exit;
}

$data_response = json_decode($response, true);

if (!isset($data_response['id'])) {
    $msg = $data_response['message'] ?? 'Erro desconhecido';
    $error_detail = $data_response['cause'][0]['description'] ?? $msg;
    logDebug("ERRO MP: $error_detail - " . print_r($data_response, true));
    $response_error = ['error' => 'Erro ao criar pagamento: ' . $error_detail];
    header('Content-Type: application/json');
    echo json_encode($response_error);
    $conn->close();
    exit;
}

logDebug("Pagamento criado: ID " . $data_response['id'] . " - Ref: $externalReference");

// 🔥 SALVAR PAGAMENTO NO BANCO
$sql = "INSERT INTO pagamentos (referencia, servico_id, barbeiro_id, valor, payment_id, status, 
        cliente_nome, cliente_email, cliente_telefone, data_agendada, horario_agendado, observacoes) 
        VALUES (?, ?, ?, ?, ?, 'pending', ?, ?, ?, ?, ?, ?)";

$stmt = $conn->prepare($sql);
$stmt->bind_param(
    "siidsisssss", 
    $externalReference, 
    $servico_id, 
    $barbeiro_id, 
    $preco, 
    $data_response['id'],
    $nome,
    $email,
    $telefone,
    $data,
    $horario,
    $observacoes
);

if ($stmt->execute()) {
    logDebug("Pagamento salvo no banco: $externalReference");
} else {
    logDebug("ERRO ao salvar pagamento: " . $stmt->error);
}

$conn->close();

// 🔥 RESPOSTA PARA O FRONTEND
$transactionData = $data_response['point_of_interaction']['transaction_data'] ?? [];
$arr = [
    'qr_code' => $transactionData['qr_code'] ?? '',
    'qr_code_base64' => $transactionData['qr_code_base64'] ?? '',
    'payment_url' => $transactionData['ticket_url'] ?? '',
    'id' => $data_response['id'] ?? '',
    'ref' => $externalReference,
    'barbeiro_id' => $barbeiro_id,
    'status' => $data_response['status'] ?? 'pending',
    'transaction_amount' => $preco
];

logDebug("Resposta final: " . json_encode($arr));

header('Content-Type: application/json');
echo json_encode($arr);
?>
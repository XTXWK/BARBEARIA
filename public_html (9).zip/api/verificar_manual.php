<?php
include("../config.php");

header('Content-Type: text/html; charset=UTF-8');

$reference = $_GET['ref'] ?? '';

if (!$reference) {
    die("❌ Referência não informada. Use: verificar_manual.php?ref=CODIGO");
}

$conn = new mysqli($db_host, $db_user, $db_password, $db_name);

if ($conn->connect_error) {
    die("❌ Erro de conexão: " . $conn->connect_error);
}

// Buscar pagamento
$sql = "SELECT * FROM pagamentos WHERE referencia = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $reference);
$stmt->execute();
$result = $stmt->get_result();
$pagamento = $result->fetch_assoc();

if (!$pagamento) {
    die("❌ Pagamento não encontrado: $reference");
}

echo "<h1>🔍 Verificação Manual</h1>";
echo "<h3>Referência: " . $reference . "</h3>";
echo "<h3>Status atual: <strong style='color:" . ($pagamento['status'] == 'approved' ? 'green' : 'red') . "'>" . $pagamento['status'] . "</strong></h3>";

echo "<h3>Dados do Pagamento:</h3>";
echo "<pre>";
print_r($pagamento);
echo "</pre>";

$paymentId = $pagamento['payment_id'];
echo "<p><strong>Payment ID:</strong> " . $paymentId . "</p>";

// Consultar MP
echo "<h3>Consultando Mercado Pago...</h3>";

$curl = curl_init();
curl_setopt_array($curl, [
    CURLOPT_URL => 'https://api.mercadopago.com/v1/payments/' . $paymentId,
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_HTTPHEADER => [
        'Authorization: Bearer ' . $acess_token,
        'Content-Type: application/json'
    ],
    CURLOPT_TIMEOUT => 30,
    CURLOPT_SSL_VERIFYPEER => false
]);

$response = curl_exec($curl);
$http_code = curl_getinfo($curl, CURLINFO_HTTP_CODE);
$curl_error = curl_error($curl);
curl_close($curl);

if ($curl_error) {
    die("❌ Erro cURL: " . $curl_error);
}

if ($http_code != 200) {
    die("❌ HTTP Error: " . $http_code . " - " . $response);
}

$data = json_decode($response, true);
$status = $data['status'] ?? 'unknown';

echo "<h3>Status no Mercado Pago: <strong style='color:" . ($status == 'approved' ? 'green' : 'red') . "'>" . $status . "</strong></h3>";

if ($status == 'approved') {
    echo "<h3 style='color:green;'>✅ Pagamento confirmado no Mercado Pago!</h3>";
    
    if ($pagamento['status'] == 'approved') {
        echo "<p style='color:green;'>✅ Pagamento já estava confirmado no sistema.</p>";
    } else {
        echo "<h3>Processando aprovação...</h3>";
        
        // Processar aprovação
        $data_agendada = $pagamento['data_agendada'];
        $horario_agendado = $pagamento['horario_agendado'];
        $barbeiro_id = $pagamento['barbeiro_id'];
        $servico_id = $pagamento['servico_id'];
        
        // Verificar horário
        $sql = "SELECT id, status FROM horarios 
                WHERE data = ? AND horario = ? AND barbeiro_id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ssi", $data_agendada, $horario_agendado, $barbeiro_id);
        $stmt->execute();
        $result = $conn->query($sql);
        $horario = $result->fetch_assoc();
        
        if (!$horario) {
            $sql = "INSERT INTO horarios (data, horario, barbeiro_id, status) 
                    VALUES (?, ?, ?, 'disponivel')";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("ssi", $data_agendada, $horario_agendado, $barbeiro_id);
            $stmt->execute();
            $horario_id = $conn->insert_id;
            echo "<p>✅ Horário criado: ID $horario_id</p>";
        } else {
            $horario_id = $horario['id'];
            echo "<p>📌 Horário existente: ID $horario_id</p>";
        }
        
        // Atualizar horário
        $sql = "UPDATE horarios SET 
                status = 'pago',
                servico_id = ?,
                cliente_nome = ?,
                cliente_email = ?,
                cliente_telefone = ?,
                referencia_pagamento = ?,
                preco = ?,
                observacoes = ?
                WHERE id = ?";
        
        $stmt = $conn->prepare($sql);
        $stmt->bind_param(
            "issssdsi",
            $servico_id,
            $pagamento['cliente_nome'],
            $pagamento['cliente_email'],
            $pagamento['cliente_telefone'],
            $reference,
            $pagamento['valor'],
            $pagamento['observacoes'],
            $horario_id
        );
        
        if ($stmt->execute()) {
            echo "<p style='color:green;'>✅ Horário atualizado</p>";
        }
        
        // Atualizar pagamento
        $sql = "UPDATE pagamentos SET status = 'approved', horario_id = ? WHERE referencia = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("is", $horario_id, $reference);
        
        if ($stmt->execute()) {
            echo "<p style='color:green;'>✅ Pagamento atualizado para approved</p>";
        }
        
        echo "<p style='color:green;font-size:1.2em;'>✅ PROCESSO CONCLUÍDO!</p>";
        
        // Link para página de sucesso
        echo "<p><a href='../sucesso.php?nome=" . urlencode($pagamento['cliente_nome']) . 
             "&barbeiro=" . urlencode($pagamento['barbeiro_id']) . 
             "&servico=" . urlencode($pagamento['servico_id']) . 
             "&data=" . urlencode($data_agendada) . 
             "&horario=" . urlencode($horario_agendado) . 
             "&valor=" . urlencode($pagamento['valor']) . 
             "&referencia=" . urlencode($reference) . 
             "' style='color:gold; font-size:1.2em;'>🔗 Ir para página de sucesso</a></p>";
    }
} else {
    echo "<h3 style='color:orange;'>⏳ Pagamento ainda não aprovado. Status: $status</h3>";
}

$conn->close();
?>
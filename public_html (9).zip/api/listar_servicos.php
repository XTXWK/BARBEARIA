<?php
include("../config.php");

$conn = new mysqli($db_host, $db_user, $db_password, $db_name);

if ($conn->connect_error) {
    die(json_encode(['error' => 'Erro de conexão']));
}

$sql = "SELECT * FROM servicos WHERE ativo = 1 ORDER BY nome";
$result = $conn->query($sql);

$servicos = [];
while ($row = $result->fetch_assoc()) {
    $servicos[] = $row;
}

$conn->close();

header('Content-Type: application/json');
echo json_encode($servicos);
?>
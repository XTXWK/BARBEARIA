<?php
include("config.php");

echo "<h1>🧪 Teste de Webhook</h1>";

// Verificar último pagamento
$conn = new mysqli($db_host, $db_user, $db_password, $db_name);

if ($conn->connect_error) {
    die("Erro de conexão: " . $conn->connect_error);
}

// Buscar último pagamento pendente
$sql = "SELECT * FROM pagamentos WHERE status != 'approved' ORDER BY id DESC LIMIT 1";
$result = $conn->query($sql);
$pagamento = $result->fetch_assoc();

if (!$pagamento) {
    echo "<p style='color:orange;'>⚠️ Nenhum pagamento pendente encontrado</p>";
    
    // Buscar qualquer pagamento
    $sql = "SELECT * FROM pagamentos ORDER BY id DESC LIMIT 1";
    $result = $conn->query($sql);
    $pagamento = $result->fetch_assoc();
    
    if ($pagamento) {
        echo "<p>📌 Último pagamento: ID {$pagamento['id']} - Status: {$pagamento['status']}</p>";
        echo "<pre>";
        print_r($pagamento);
        echo "</pre>";
    }
    $conn->close();
    exit;
}

echo "<p>✅ Pagamento encontrado:</p>";
echo "<pre>";
print_r($pagamento);
echo "</pre>";

$payment_id = $pagamento['payment_id'];
echo "<p><strong>Payment ID:</strong> " . $payment_id . "</p>";

// Simular a notificação
$data = [
    'id' => $payment_id,
    'topic' => 'payment'
];

echo "<h3>📤 Enviando notificação simulada para:</h3>";
echo "<p><code>" . $notification_url . "</code></p>";

$ch = curl_init($notification_url);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_TIMEOUT, 30);

$response = curl_exec($ch);
$http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$curl_error = curl_error($ch);
curl_close($ch);

echo "<h3>📥 Resposta:</h3>";
echo "<p>HTTP Code: <strong>" . $http_code . "</strong></p>";

if ($curl_error) {
    echo "<p style='color:red;'>❌ Erro cURL: " . $curl_error . "</p>";
} else {
    echo "<p>Resposta: <pre>" . htmlspecialchars($response) . "</pre></p>";
}

// Verificar se o pagamento foi atualizado
$sql = "SELECT * FROM pagamentos WHERE payment_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $payment_id);
$stmt->execute();
$result = $stmt->get_result();
$pagamento_atualizado = $result->fetch_assoc();

echo "<h3>📊 Status atual do pagamento:</h3>";
echo "<pre>";
print_r($pagamento_atualizado);
echo "</pre>";

if ($pagamento_atualizado['status'] == 'approved') {
    echo "<p style='color:green;font-size:1.2em;'>✅ PAGAMENTO APROVADO COM SUCESSO!</p>";
} else {
    echo "<p style='color:orange;'>⏳ Status atual: " . $pagamento_atualizado['status'] . "</p>";
}

$conn->close();
?>
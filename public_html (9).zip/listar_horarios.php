<?php
include("config.php");

// Habilitar erro para debug
error_reporting(E_ALL);
ini_set('display_errors', 1);

$data = $_POST['data'] ?? date('Y-m-d');

// Validar data
if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $data)) {
    die(json_encode(['error' => 'Data inválida']));
}

$conn = new mysqli($db_host, $db_user, $db_password, $db_name);

if ($conn->connect_error) {
    die(json_encode(['error' => 'Erro de conexão: ' . $conn->connect_error]));
}

// Buscar horários existentes
$sql = "SELECT * FROM horarios WHERE data = ? ORDER BY horario";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $data);
$stmt->execute();
$result = $stmt->get_result();

$horarios = [];
while ($row = $result->fetch_assoc()) {
    $horarios[] = $row;
}

// Se não houver horários, criar horários padrão
if (empty($horarios)) {
    $horarios_padrao = [];
    for ($h = 9; $h <= 20; $h++) {
        $horario = sprintf("%02d:00:00", $h);
        $horarios_padrao[] = [
            'data' => $data,
            'horario' => $horario,
            'status' => 'disponivel',
            'preco' => 30.00
        ];
    }
    
    // Inserir horários padrão
    foreach ($horarios_padrao as $h) {
        $sql = "INSERT INTO horarios (data, horario, status, preco) VALUES (?, ?, ?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("sssd", $h['data'], $h['horario'], $h['status'], $h['preco']);
        $stmt->execute();
    }
    
    // Buscar novamente
    $sql = "SELECT * FROM horarios WHERE data = ? ORDER BY horario";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $data);
    $stmt->execute();
    $result = $stmt->get_result();
    
    $horarios = [];
    while ($row = $result->fetch_assoc()) {
        $horarios[] = $row;
    }
}

$conn->close();

// Garantir que o retorno seja JSON
header('Content-Type: application/json');
echo json_encode($horarios);
?>
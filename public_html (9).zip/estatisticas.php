<?php
include("config.php");

$conn = new mysqli($db_host, $db_user, $db_password, $db_name);

if ($conn->connect_error) {
    die(json_encode(['error' => 'Erro de conexão']));
}

$stats = [];

// Total de horários
$sql = "SELECT COUNT(*) as total FROM horarios";
$result = $conn->query($sql);
$stats['total'] = $result->fetch_assoc()['total'];

// Status
$sql = "SELECT status, COUNT(*) as count FROM horarios GROUP BY status";
$result = $conn->query($sql);
while ($row = $result->fetch_assoc()) {
    $stats[$row['status']] = $row['count'];
}

// Total de hoje
$hoje = date('Y-m-d');
$sql = "SELECT COUNT(*) as hoje FROM horarios WHERE data = '$hoje'";
$result = $conn->query($sql);
$stats['hoje'] = $result->fetch_assoc()['hoje'];

$conn->close();

echo json_encode($stats);
?>
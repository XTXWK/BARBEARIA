<?php
$log_file = __DIR__ . '/logs/php_error.log';

if (file_exists($log_file)) {
    echo "<h3>Últimas 50 linhas do log:</h3>";
    echo "<pre>";
    $lines = file($log_file);
    $last_lines = array_slice($lines, -50);
    foreach ($last_lines as $line) {
        echo htmlspecialchars($line);
    }
    echo "</pre>";
} else {
    echo "Arquivo de log não encontrado em: " . $log_file;
}
?>
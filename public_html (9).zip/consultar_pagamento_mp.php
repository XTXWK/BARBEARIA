<?php
include("config.php");

$payment_id = $_GET['id'] ?? '174243100215';

echo "<h1>🔍 Consultar Pagamento no Mercado Pago</h1>";
echo "<p><strong>Payment ID:</strong> " . $payment_id . "</p>";

$curl = curl_init();
curl_setopt_array($curl, [
    CURLOPT_URL => 'https://api.mercadopago.com/v1/payments/' . $payment_id,
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_HTTPHEADER => [
        'Authorization: Bearer ' . $acess_token,
        'Content-Type: application/json'
    ],
    CURLOPT_TIMEOUT => 30,
    CURLOPT_SSL_VERIFYPEER => false
]);

$response = curl_exec($curl);
$http_code = curl_getinfo($curl, CURLINFO_HTTP_CODE);
$curl_error = curl_error($curl);
curl_close($curl);

echo "<h3>HTTP Code: " . $http_code . "</h3>";

if ($curl_error) {
    echo "<p style='color:red;'>❌ Erro cURL: " . $curl_error . "</p>";
    exit;
}

if ($http_code != 200) {
    echo "<p style='color:red;'>❌ Erro na consulta</p>";
    echo "<pre>" . htmlspecialchars($response) . "</pre>";
    exit;
}

$data = json_decode($response, true);

echo "<h3>📊 Status do Pagamento:</h3>";
echo "<table border='1' cellpadding='8' style='border-collapse:collapse;'>";
echo "<tr><th>Campo</th><th>Valor</th></tr>";
echo "<tr><td><strong>Status</strong></td><td style='color:" . ($data['status'] == 'approved' ? 'green' : 'red') . ";font-weight:bold;'>" . ($data['status'] ?? 'N/A') . "</td></tr>";
echo "<tr><td><strong>Status Detail</strong></td><td>" . ($data['status_detail'] ?? 'N/A') . "</td></tr>";
echo "<tr><td><strong>Valor</strong></td><td>R$ " . number_format($data['transaction_amount'] ?? 0, 2, ',', '.') . "</td></tr>";
echo "<tr><td><strong>Descrição</strong></td><td>" . ($data['description'] ?? 'N/A') . "</td></tr>";
echo "<tr><td><strong>Método</strong></td><td>" . ($data['payment_method_id'] ?? 'N/A') . "</td></tr>";
echo "<tr><td><strong>Data de Criação</strong></td><td>" . ($data['date_created'] ?? 'N/A') . "</td></tr>";
echo "<tr><td><strong>Data de Aprovação</strong></td><td>" . ($data['date_approved'] ?? 'N/A') . "</td></tr>";
echo "<tr><td><strong>External Reference</strong></td><td>" . ($data['external_reference'] ?? 'N/A') . "</td></tr>";
echo "<tr><td><strong>Payer Email</strong></td><td>" . ($data['payer']['email'] ?? 'N/A') . "</td></tr>";
echo "</table>";

// Mostrar todos os dados
echo "<h3>📋 Dados Completos:</h3>";
echo "<pre style='background:#1a1a1a;padding:15px;border-radius:10px;color:#0f0;overflow-x:auto;'>";
print_r($data);
echo "</pre>";

// Verificar se está aprovado
if ($data['status'] == 'approved') {
    echo "<p style='color:green;font-size:1.2em;'>✅ PAGAMENTO APROVADO!</p>";
    echo "<p><a href='verificar_manual.php?ref=" . ($data['external_reference'] ?? '') . "'>Atualizar manualmente</a></p>";
} else {
    echo "<p style='color:orange;font-size:1.2em;'>⚠️ Pagamento NÃO está aprovado. Status: " . $data['status'] . "</p>";
    echo "<p>Motivo: " . ($data['status_detail'] ?? 'Desconhecido') . "</p>";
}
?>
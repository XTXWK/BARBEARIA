<?php
include("../config.php");

header('Content-Type: application/json');

$conn = new mysqli($db_host, $db_user, $db_password, $db_name);

if ($conn->connect_error) {
    echo json_encode(['error' => 'Erro de conexão: ' . $conn->connect_error]);
    exit;
}

$sql = "SELECT * FROM barbeiros ORDER BY nome";
$result = $conn->query($sql);

if (!$result) {
    echo json_encode(['error' => 'Erro na consulta: ' . $conn->error]);
    $conn->close();
    exit;
}

$barbeiros = [];
while ($row = $result->fetch_assoc()) {
    $barbeiros[] = $row;
}

$conn->close();

echo json_encode($barbeiros);
?>
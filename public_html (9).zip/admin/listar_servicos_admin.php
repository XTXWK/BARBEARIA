<?php
include("../config.php");

$conn = new mysqli($db_host, $db_user, $db_password, $db_name);

if ($conn->connect_error) {
    die(json_encode(['error' => 'Erro de conexão: ' . $conn->connect_error]));
}

$sql = "SELECT * FROM servicos ORDER BY nome";
$result = $conn->query($sql);

if (!$result) {
    die(json_encode(['error' => 'Erro na consulta: ' . $conn->error]));
}

$servicos = [];
while ($row = $result->fetch_assoc()) {
    $servicos[] = $row;
}

$conn->close();

header('Content-Type: application/json');
echo json_encode($servicos);
?>
<?php
include("../config.php");

header('Content-Type: application/json');

$id = $_POST['id'] ?? 0;

if (!$id) {
    echo json_encode(['error' => 'ID não informado']);
    exit;
}

$conn = new mysqli($db_host, $db_user, $db_password, $db_name);

if ($conn->connect_error) {
    echo json_encode(['error' => 'Erro de conexão: ' . $conn->connect_error]);
    exit;
}

$sql = "SELECT * FROM barbeiros WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$barbeiro = $result->fetch_assoc();

$conn->close();

if (!$barbeiro) {
    echo json_encode(['error' => 'Barbeiro não encontrado']);
    exit;
}

echo json_encode($barbeiro);
?>
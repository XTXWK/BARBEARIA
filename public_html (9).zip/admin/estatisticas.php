<?php
include("../config.php");

$conn = new mysqli($db_host, $db_user, $db_password, $db_name);

if ($conn->connect_error) {
    die(json_encode(['error' => 'Erro de conexão: ' . $conn->connect_error]));
}

$stats = [];

// Total de horários
$sql = "SELECT COUNT(*) as total FROM horarios";
$result = $conn->query($sql);
$stats['total'] = $result->fetch_assoc()['total'] ?? 0;

// Status
$sql = "SELECT status, COUNT(*) as count FROM horarios GROUP BY status";
$result = $conn->query($sql);
while ($row = $result->fetch_assoc()) {
    $stats[$row['status']] = $row['count'];
}

// Horários de hoje
$hoje = date('Y-m-d');
$sql = "SELECT COUNT(*) as hoje FROM horarios WHERE data = '$hoje'";
$result = $conn->query($sql);
$stats['hoje'] = $result->fetch_assoc()['hoje'] ?? 0;

// Disponíveis hoje
$sql = "SELECT COUNT(*) as disponiveis_hoje FROM horarios WHERE data = '$hoje' AND status = 'disponivel'";
$result = $conn->query($sql);
$stats['disponiveis_hoje'] = $result->fetch_assoc()['disponiveis_hoje'] ?? 0;

// Faturamento do mês
$primeiro_dia_mes = date('Y-m-01');
$sql = "SELECT SUM(preco) as faturamento FROM horarios WHERE data >= '$primeiro_dia_mes' AND status = 'pago'";
$result = $conn->query($sql);
$stats['faturamento_mes'] = $result->fetch_assoc()['faturamento'] ?? 0;

// Pagamentos pendentes
$sql = "SELECT COUNT(*) as pendentes FROM pagamentos WHERE status = 'pending'";
$result = $conn->query($sql);
$stats['pendentes'] = $result->fetch_assoc()['pendentes'] ?? 0;

// Total de serviços ativos
$sql = "SELECT COUNT(*) as total_servicos FROM servicos WHERE ativo = 1";
$result = $conn->query($sql);
$stats['total_servicos'] = $result->fetch_assoc()['total_servicos'] ?? 0;

// Taxa de conversão
$total = $stats['total'] ?? 1;
$pagos = $stats['pago'] ?? 0;
$stats['taxa_conversao'] = $total > 0 ? round(($pagos / $total) * 100, 1) : 0;

$conn->close();

header('Content-Type: application/json');
echo json_encode($stats);
?>
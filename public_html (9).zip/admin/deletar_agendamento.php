<?php
include("../config.php");

$id = $_POST['id'] ?? 0;
$senha = $_POST['senha'] ?? '';

if ($senha !== 'admin123') {
    die(json_encode(['success' => false, 'message' => 'Senha incorreta']));
}

if (!$id) {
    die(json_encode(['success' => false, 'message' => 'ID não informado']));
}

$conn = new mysqli($db_host, $db_user, $db_password, $db_name);

if ($conn->connect_error) {
    die(json_encode(['success' => false, 'message' => 'Erro de conexão: ' . $conn->connect_error]));
}

// Verificar se pode deletar
$sql = "SELECT status FROM horarios WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$row = $result->fetch_assoc();

if (!$row) {
    die(json_encode(['success' => false, 'message' => 'Agendamento não encontrado']));
}

if ($row['status'] !== 'disponivel') {
    die(json_encode(['success' => false, 'message' => 'Não é possível deletar um agendamento reservado ou pago']));
}

$sql = "DELETE FROM horarios WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id);

if ($stmt->execute()) {
    echo json_encode(['success' => true, 'message' => 'Deletado com sucesso']);
} else {
    echo json_encode(['success' => false, 'message' => 'Erro ao deletar: ' . $conn->error]);
}

$conn->close();
?>
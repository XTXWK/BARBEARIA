<?php
// listar_barbeiros_admin.php
include("../config.php");

$conn = new mysqli($db_host, $db_user, $db_password, $db_name);

if ($conn->connect_error) {
    die(json_encode(['error' => 'Erro de conexão: ' . $conn->connect_error]));
}

$sql = "SELECT * FROM barbeiros ORDER BY nome";
$result = $conn->query($sql);

if (!$result) {
    die(json_encode(['error' => 'Erro na consulta: ' . $conn->error]));
}

$barbeiros = [];
while ($row = $result->fetch_assoc()) {
    $barbeiros[] = $row;
}

$conn->close();

header('Content-Type: application/json');
echo json_encode($barbeiros);
?>

<?php
// salvar_barbeiro.php
include("../config.php");

$id = $_POST['id'] ?? 0;
$nome = $_POST['nome'] ?? '';
$email = $_POST['email'] ?? '';
$senha = $_POST['senha'] ?? '';
$telefone = $_POST['telefone'] ?? '';
$especialidades = $_POST['especialidades'] ?? '';
$ativo = $_POST['ativo'] ?? 1;
$senha_admin = $_POST['senha_admin'] ?? '';

if ($senha_admin !== 'admin123') {
    die(json_encode(['success' => false, 'message' => 'Senha admin incorreta']));
}

if (!$nome || !$email) {
    die(json_encode(['success' => false, 'message' => 'Nome e email são obrigatórios']));
}

$conn = new mysqli($db_host, $db_user, $db_password, $db_name);

if ($conn->connect_error) {
    die(json_encode(['success' => false, 'message' => 'Erro de conexão']));
}

if ($id > 0) {
    // Atualizar
    if ($senha) {
        $senha_md5 = md5($senha);
        $sql = "UPDATE barbeiros SET 
                nome = ?, email = ?, senha = ?, telefone = ?, 
                especialidades = ?, ativo = ? WHERE id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("sssssii", $nome, $email, $senha_md5, $telefone, $especialidades, $ativo, $id);
    } else {
        $sql = "UPDATE barbeiros SET 
                nome = ?, email = ?, telefone = ?, 
                especialidades = ?, ativo = ? WHERE id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ssssii", $nome, $email, $telefone, $especialidades, $ativo, $id);
    }
} else {
    // Inserir
    $senha_md5 = md5($senha ?: 'barbeiro123');
    $sql = "INSERT INTO barbeiros (nome, email, senha, telefone, especialidades, ativo) 
            VALUES (?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sssssi", $nome, $email, $senha_md5, $telefone, $especialidades, $ativo);
}

if ($stmt->execute()) {
    echo json_encode(['success' => true, 'message' => 'Barbeiro salvo com sucesso']);
} else {
    echo json_encode(['success' => false, 'message' => 'Erro ao salvar: ' . $conn->error]);
}

$conn->close();
?>

<?php
// deletar_barbeiro.php
include("../config.php");

$id = $_POST['id'] ?? 0;
$senha_admin = $_POST['senha_admin'] ?? '';

if ($senha_admin !== 'admin123') {
    die(json_encode(['success' => false, 'message' => 'Senha admin incorreta']));
}

$conn = new mysqli($db_host, $db_user, $db_password, $db_name);

if ($conn->connect_error) {
    die(json_encode(['success' => false, 'message' => 'Erro de conexão']));
}

// Verificar se tem agendamentos
$sql = "SELECT COUNT(*) as total FROM horarios WHERE barbeiro_id = ? AND status = 'pago'";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$row = $result->fetch_assoc();

if ($row['total'] > 0) {
    // Apenas desativar
    $sql = "UPDATE barbeiros SET ativo = 0 WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id);
    $msg = "Barbeiro desativado (tem agendamentos)";
} else {
    $sql = "DELETE FROM barbeiros WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id);
    $msg = "Barbeiro deletado";
}

if ($stmt->execute()) {
    echo json_encode(['success' => true, 'message' => $msg]);
} else {
    echo json_encode(['success' => false, 'message' => 'Erro ao deletar']);
}

$conn->close();
?>
<?php
include("../config.php");

$data = $_POST['data'] ?? '';
$senha = $_POST['senha'] ?? '';

if ($senha !== 'admin123') {
    die(json_encode(['success' => false, 'message' => 'Senha incorreta']));
}

if (!$data) {
    die(json_encode(['success' => false, 'message' => 'Data não informada']));
}

$conn = new mysqli($db_host, $db_user, $db_password, $db_name);

if ($conn->connect_error) {
    die(json_encode(['success' => false, 'message' => 'Erro de conexão']));
}

$sql = "DELETE FROM horarios WHERE data = ? AND status = 'disponivel'";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $data);

if ($stmt->execute()) {
    $count = $stmt->affected_rows;
    echo json_encode(['success' => true, 'message' => "$count horário(s) removido(s)"]);
} else {
    echo json_encode(['success' => false, 'message' => 'Erro ao remover horários']);
}

$conn->close();
?>
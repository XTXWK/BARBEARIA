<?php
session_start();
include("../config.php");

// Verificar autenticação
if (!isset($_SESSION['admin_logado']) && !isset($_COOKIE['admin_logado'])) {
    echo json_encode(['success' => false, 'message' => 'Não autenticado']);
    exit;
}

$id = isset($_POST['id']) ? intval($_POST['id']) : 0;
$senha_admin = $_POST['senha_admin'] ?? '';

if ($senha_admin !== 'admin123') {
    echo json_encode(['success' => false, 'message' => 'Senha administrativa incorreta']);
    exit;
}

if ($id <= 0) {
    echo json_encode(['success' => false, 'message' => 'ID inválido']);
    exit;
}

$conn = new mysqli($db_host, $db_user, $db_password, $db_name);

if ($conn->connect_error) {
    echo json_encode(['success' => false, 'message' => 'Erro de conexão: ' . $conn->connect_error]);
    exit;
}

// Buscar a foto atual para remover o arquivo
$sql = "SELECT foto FROM barbeiros WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$barbeiro = $result->fetch_assoc();

// Verificar se tem agendamentos pendentes
$sql = "SELECT COUNT(*) as total FROM horarios WHERE barbeiro_id = ? AND status IN ('pago', 'reservado')";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$row = $result->fetch_assoc();

if ($row['total'] > 0) {
    // Apenas desativar
    $sql = "UPDATE barbeiros SET ativo = 0 WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id);
    $msg = "Barbeiro desativado (possui agendamentos pendentes)";
} else {
    // Remover foto física
    if ($barbeiro && $barbeiro['foto']) {
        $caminho_arquivo = '../' . $barbeiro['foto'];
        if (file_exists($caminho_arquivo)) {
            unlink($caminho_arquivo);
        }
    }
    
    $sql = "DELETE FROM barbeiros WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id);
    $msg = "Barbeiro removido com sucesso!";
}

if ($stmt->execute()) {
    echo json_encode(['success' => true, 'message' => $msg]);
} else {
    echo json_encode(['success' => false, 'message' => 'Erro ao deletar: ' . $conn->error]);
}

$conn->close();
?>
<?php
include("../config.php");

$data = $_POST['data'] ?? '';
$horarios_input = $_POST['horarios'] ?? '';
$barbeiro_id = $_POST['barbeiro_id'] ?? 0;
$senha = $_POST['senha'] ?? '';

if ($senha !== 'admin123') {
    die(json_encode(['success' => false, 'message' => 'Senha incorreta']));
}

if (!$data || !$horarios_input || !$barbeiro_id) {
    die(json_encode(['success' => false, 'message' => 'Dados incompletos']));
}

$conn = new mysqli($db_host, $db_user, $db_password, $db_name);
if ($conn->connect_error) {
    die(json_encode(['success' => false, 'message' => 'Erro de conexão: ' . $conn->connect_error]));
}

// Verificar se o barbeiro existe
$sql = "SELECT id FROM barbeiros WHERE id = ? AND ativo = 1";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $barbeiro_id);
$stmt->execute();
$result = $stmt->get_result();
if ($result->num_rows == 0) {
    die(json_encode(['success' => false, 'message' => 'Barbeiro não encontrado ou inativo']));
}

// Processar horários
$horarios = array_map('trim', explode(',', $horarios_input));
$horarios = array_filter($horarios);

if (empty($horarios)) {
    die(json_encode(['success' => false, 'message' => 'Nenhum horário válido']));
}

$inserted = 0;
$errors = [];
$success = [];

foreach ($horarios as $horario) {
    if (!preg_match('/^(\d{1,2}):(\d{2})$/', $horario, $matches)) {
        $errors[] = "Horário '$horario' inválido (use HH:MM)";
        continue;
    }
    
    $hora = str_pad($matches[1], 2, '0', STR_PAD_LEFT);
    $minuto = $matches[2];
    $horario_completo = "$hora:$minuto:00";
    
    // Verificar se já existe para este barbeiro
    $sql = "SELECT id FROM horarios WHERE data = ? AND horario = ? AND barbeiro_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssi", $data, $horario_completo, $barbeiro_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        $errors[] = "Horário $horario já existe para este barbeiro nesta data";
        continue;
    }
    
    $sql = "INSERT INTO horarios (data, horario, barbeiro_id, status) VALUES (?, ?, ?, 'disponivel')";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssi", $data, $horario_completo, $barbeiro_id);
    
    if ($stmt->execute()) {
        $inserted++;
        $success[] = $horario;
    } else {
        $errors[] = "Erro ao inserir $horario: " . $conn->error;
    }
}

$conn->close();

echo json_encode([
    'success' => $inserted > 0,
    'message' => "$inserted horário(s) adicionado(s) para $data",
    'success_list' => $success,
    'errors' => $errors
]);
?>
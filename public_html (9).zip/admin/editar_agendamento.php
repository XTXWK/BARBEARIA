<?php
include("../config.php");

$id = $_POST['id'] ?? 0;
$data = $_POST['data'] ?? '';
$horario = $_POST['horario'] ?? '';
$servico_id = $_POST['servico_id'] ?? null;
$cliente = $_POST['cliente'] ?? '';
$email = $_POST['email'] ?? '';
$telefone = $_POST['telefone'] ?? '';
$status = $_POST['status'] ?? '';
$observacoes = $_POST['observacoes'] ?? '';
$senha = $_POST['senha'] ?? '';

if ($senha !== 'admin123') {
    die(json_encode(['success' => false, 'message' => 'Senha incorreta']));
}

if (!$id || !$data || !$horario) {
    die(json_encode(['success' => false, 'message' => 'Dados incompletos']));
}

$conn = new mysqli($db_host, $db_user, $db_password, $db_name);

if ($conn->connect_error) {
    die(json_encode(['success' => false, 'message' => 'Erro de conexão: ' . $conn->connect_error]));
}

// Se o status for 'disponivel', limpar dados do cliente
if ($status === 'disponivel') {
    $cliente = null;
    $email = null;
    $telefone = null;
    $observacoes = null;
    $servico_id = null;
}

$sql = "UPDATE horarios SET 
        data = ?,
        horario = ?,
        servico_id = ?,
        cliente_nome = ?,
        cliente_email = ?,
        cliente_telefone = ?,
        status = ?,
        observacoes = ?
        WHERE id = ?";

$stmt = $conn->prepare($sql);
$stmt->bind_param(
    "ssisssssi", 
    $data, 
    $horario, 
    $servico_id, 
    $cliente, 
    $email, 
    $telefone, 
    $status, 
    $observacoes, 
    $id
);

if ($stmt->execute()) {
    echo json_encode(['success' => true, 'message' => 'Atualizado com sucesso']);
} else {
    echo json_encode(['success' => false, 'message' => 'Erro ao atualizar: ' . $conn->error]);
}

$conn->close();
?>
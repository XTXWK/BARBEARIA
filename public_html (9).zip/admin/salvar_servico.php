<?php
include("../config.php");

$id = $_POST['id'] ?? 0;
$nome = $_POST['nome'] ?? '';
$descricao = $_POST['descricao'] ?? '';
$preco = $_POST['preco'] ?? 0;
$duracao = $_POST['duracao'] ?? 30;
$cor = $_POST['cor'] ?? '#c9a84c';
$ativo = $_POST['ativo'] ?? 1;
$senha = $_POST['senha'] ?? '';

if ($senha !== 'admin123') {
    die(json_encode(['success' => false, 'message' => 'Senha incorreta']));
}

if (!$nome || $preco <= 0 || $duracao <= 0) {
    die(json_encode(['success' => false, 'message' => 'Dados inválidos']));
}

$conn = new mysqli($db_host, $db_user, $db_password, $db_name);

if ($conn->connect_error) {
    die(json_encode(['success' => false, 'message' => 'Erro de conexão']));
}

if ($id > 0) {
    // Atualizar
    $sql = "UPDATE servicos SET 
            nome = ?, 
            descricao = ?, 
            preco = ?, 
            duracao_minutos = ?, 
            cor = ?, 
            ativo = ? 
            WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssdisi", $nome, $descricao, $preco, $duracao, $cor, $ativo, $id);
} else {
    // Inserir
    $sql = "INSERT INTO servicos (nome, descricao, preco, duracao_minutos, cor, ativo) 
            VALUES (?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssdisi", $nome, $descricao, $preco, $duracao, $cor, $ativo);
}

if ($stmt->execute()) {
    echo json_encode(['success' => true, 'message' => 'Serviço salvo com sucesso']);
} else {
    echo json_encode(['success' => false, 'message' => 'Erro ao salvar serviço: ' . $conn->error]);
}

$conn->close();
?>
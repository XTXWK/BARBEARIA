<?php
include("../config.php");

$conn = new mysqli($db_host, $db_user, $db_password, $db_name);

if ($conn->connect_error) {
    die(json_encode(['error' => 'Erro de conexão: ' . $conn->connect_error]));
}

$sql = "SELECT 
            cliente_nome as nome,
            cliente_email as email,
            cliente_telefone as telefone,
            COUNT(*) as total,
            MAX(data) as ultimo,
            (SELECT horario FROM horarios h2 
             WHERE h2.cliente_email = h.cliente_email 
             ORDER BY data DESC, horario DESC LIMIT 1) as ultimo_horario
        FROM horarios h
        WHERE cliente_email IS NOT NULL AND cliente_email != ''
        GROUP BY cliente_email
        ORDER BY total DESC";

$result = $conn->query($sql);

if (!$result) {
    die(json_encode(['error' => 'Erro na consulta: ' . $conn->error]));
}

$clientes = [];
while ($row = $result->fetch_assoc()) {
    $clientes[] = $row;
}

$conn->close();

header('Content-Type: application/json');
echo json_encode($clientes);
?>
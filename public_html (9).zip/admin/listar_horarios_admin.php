<?php
include("../config.php");

$data = $_POST['data'] ?? date('Y-m-d');

$conn = new mysqli($db_host, $db_user, $db_password, $db_name);

if ($conn->connect_error) {
    die(json_encode(['error' => 'Erro de conexão: ' . $conn->connect_error]));
}

$sql = "SELECT h.*, s.nome as servico_nome 
        FROM horarios h
        LEFT JOIN servicos s ON h.servico_id = s.id
        WHERE h.data = ?
        ORDER BY h.horario";

$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $data);
$stmt->execute();
$result = $stmt->get_result();

$horarios = [];
while ($row = $result->fetch_assoc()) {
    $row['horario_formatado'] = substr($row['horario'], 0, 5);
    $horarios[] = $row;
}

$conn->close();

header('Content-Type: application/json');
echo json_encode($horarios);
?>
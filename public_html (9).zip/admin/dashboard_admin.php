<?php
include("../config.php");

// Verificar autenticação via sessão ou cookie
session_start();
$senha_correta = 'admin123';

if (!isset($_SESSION['admin_logado']) && !isset($_COOKIE['admin_logado'])) {
    if ($_POST['senha'] ?? '') {
        if ($_POST['senha'] === $senha_correta) {
            $_SESSION['admin_logado'] = true;
            setcookie('admin_logado', true, time() + (86400 * 7));
            header('Location: ' . $_SERVER['PHP_SELF']);
            exit;
        } else {
            $erro = "Senha incorreta!";
        }
    }
    ?>
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Admin - Thomaz Black Barbearia</title>
        <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;700;900&family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
        <style>
            * { margin: 0; padding: 0; box-sizing: border-box; }
            body { 
                font-family: 'Inter', sans-serif;
                background: #0a0a0a;
                display: flex;
                justify-content: center;
                align-items: center;
                min-height: 100vh;
                color: #fff;
                background: radial-gradient(ellipse at center, #1a1a1a 0%, #0a0a0a 100%);
            }
            .login-box {
                background: rgba(26, 26, 26, 0.95);
                padding: 50px 40px;
                border-radius: 16px;
                border: 1px solid rgba(201, 168, 76, 0.15);
                max-width: 420px;
                width: 90%;
                box-shadow: 0 30px 80px rgba(0,0,0,0.8);
                position: relative;
                overflow: hidden;
            }
            .login-box::before {
                content: '';
                position: absolute;
                top: 0;
                left: 0;
                right: 0;
                height: 3px;
                background: linear-gradient(90deg, #c9a84c, #a8893a, #c9a84c);
            }
            .login-box .logo-icon { text-align: center; font-size: 3.5em; margin-bottom: 10px; }
            .login-box h1 {
                color: #c9a84c;
                text-align: center;
                font-family: 'Playfair Display', serif;
                font-size: 1.8em;
                font-weight: 700;
                margin-bottom: 4px;
            }
            .login-box .subtitle {
                color: #888;
                text-align: center;
                font-size: 0.8em;
                letter-spacing: 3px;
                text-transform: uppercase;
                margin-bottom: 30px;
            }
            .login-box .divider {
                width: 60px;
                height: 2px;
                background: linear-gradient(90deg, transparent, #c9a84c, transparent);
                margin: 0 auto 30px;
            }
            .login-box input {
                width: 100%;
                padding: 14px 18px;
                border-radius: 10px;
                border: 1.5px solid #2a2a2a;
                background: rgba(10, 10, 10, 0.8);
                color: #fff;
                font-size: 1em;
                margin-bottom: 18px;
                transition: all 0.3s;
                font-family: 'Inter', sans-serif;
            }
            .login-box input:focus {
                outline: none;
                border-color: #c9a84c;
                box-shadow: 0 0 0 3px rgba(201, 168, 76, 0.1);
            }
            .login-box input::placeholder { color: #555; }
            .login-box button {
                width: 100%;
                padding: 14px;
                background: linear-gradient(135deg, #c9a84c, #a8893a);
                color: #0a0a0a;
                border: none;
                border-radius: 10px;
                font-weight: 700;
                font-size: 1em;
                cursor: pointer;
                transition: all 0.3s;
                font-family: 'Inter', sans-serif;
                letter-spacing: 0.5px;
            }
            .login-box button:hover {
                transform: translateY(-2px);
                box-shadow: 0 10px 30px rgba(201, 168, 76, 0.25);
            }
            .erro {
                background: rgba(220, 53, 69, 0.12);
                color: #dc3545;
                padding: 12px 16px;
                border-radius: 8px;
                margin-bottom: 20px;
                text-align: center;
                border: 1px solid rgba(220, 53, 69, 0.15);
                font-size: 0.9em;
            }
            .login-box .footer-text {
                text-align: center;
                color: #444;
                font-size: 0.7em;
                margin-top: 20px;
                letter-spacing: 1px;
            }
            .login-box .footer-text strong { color: #c9a84c; }
        </style>
    </head>
    <body>
        <div class="login-box">
            <div class="logo-icon">✂️</div>
            <h1>Thomaz Black</h1>
            <div class="subtitle">Barbearia</div>
            <div class="divider"></div>
            <?php if (isset($erro)): ?>
                <div class="erro"><?php echo $erro; ?></div>
            <?php endif; ?>
            <form method="POST">
                <input type="password" name="senha" placeholder="Digite a senha administrativa" required>
                <button type="submit">Acessar Dashboard</button>
            </form>
            <div class="footer-text">Sistema de gerenciamento <strong>Thomaz Black</strong></div>
        </div>
    </body>
    </html>
    <?php
    exit;
}

// Conectar ao banco
$conn = new mysqli($db_host, $db_user, $db_password, $db_name);
if ($conn->connect_error) {
    die("Erro de conexão: " . $conn->connect_error);
}

// ============================================
// ESTATÍSTICAS GERAIS
// ============================================
$stats = [];

$sql = "SELECT COUNT(*) as total FROM horarios";
$result = $conn->query($sql);
$stats['total'] = $result->fetch_assoc()['total'] ?? 0;

$sql = "SELECT status, COUNT(*) as count FROM horarios GROUP BY status";
$result = $conn->query($sql);
while ($row = $result->fetch_assoc()) {
    $stats[$row['status']] = $row['count'];
}

$hoje = date('Y-m-d');
$sql = "SELECT COUNT(*) as hoje FROM horarios WHERE data = '$hoje'";
$result = $conn->query($sql);
$stats['hoje'] = $result->fetch_assoc()['hoje'] ?? 0;

$sql = "SELECT COUNT(*) as disponiveis_hoje FROM horarios WHERE data = '$hoje' AND status = 'disponivel'";
$result = $conn->query($sql);
$stats['disponiveis_hoje'] = $result->fetch_assoc()['disponiveis_hoje'] ?? 0;

$primeiro_dia_mes = date('Y-m-01');
$sql = "SELECT SUM(preco) as faturamento FROM horarios WHERE data >= '$primeiro_dia_mes' AND status IN ('pago', 'concluido')";
$result = $conn->query($sql);
$stats['faturamento_mes'] = $result->fetch_assoc()['faturamento'] ?? 0;

$sql = "SELECT COUNT(*) as total_servicos FROM servicos_barbeiro WHERE ativo = 1";
$result = $conn->query($sql);
$stats['total_servicos'] = $result->fetch_assoc()['total_servicos'] ?? 0;

$sql = "SELECT COUNT(*) as total_barbeiros FROM barbeiros WHERE ativo = 1";
$result = $conn->query($sql);
$stats['total_barbeiros'] = $result->fetch_assoc()['total_barbeiros'] ?? 0;

$sql = "SELECT COUNT(*) as pendentes FROM pagamentos WHERE status = 'pending'";
$result = $conn->query($sql);
$stats['pendentes'] = $result->fetch_assoc()['pendentes'] ?? 0;

$sql = "SELECT COUNT(*) as concluidos FROM horarios WHERE status = 'concluido'";
$result = $conn->query($sql);
$stats['concluidos'] = $result->fetch_assoc()['concluidos'] ?? 0;

// ============================================
// LISTA DE BARBEIROS
// ============================================
$sql = "SELECT id, nome, foto, email, telefone, especialidades, ativo FROM barbeiros WHERE ativo = 1 ORDER BY nome";
$result = $conn->query($sql);
$barbeiros_lista = [];
while ($row = $result->fetch_assoc()) {
    $barbeiros_lista[] = $row;
}

// ============================================
// AGENDAMENTOS POR BARBEIRO (EXCLUINDO CONCLUÍDOS)
// ============================================
$agendamentos_por_barbeiro = [];
foreach ($barbeiros_lista as $barbeiro) {
    $sql = "SELECT 
                h.id,
                h.data,
                h.horario,
                h.status,
                h.preco,
                h.cliente_nome,
                h.cliente_email,
                h.cliente_telefone,
                h.observacoes,
                s.nome as servico_nome
            FROM horarios h
            LEFT JOIN servicos_barbeiro s ON h.servico_id = s.id
            WHERE h.barbeiro_id = {$barbeiro['id']}
            AND h.status IN ('pago', 'reservado')
            ORDER BY h.data DESC, h.horario DESC
            LIMIT 50";
    $result = $conn->query($sql);
    $agendamentos = [];
    while ($row = $result->fetch_assoc()) {
        $row['data_formatada'] = date('d/m/Y', strtotime($row['data']));
        $row['horario_formatado'] = substr($row['horario'], 0, 5);
        $agendamentos[] = $row;
    }
    $agendamentos_por_barbeiro[$barbeiro['id']] = [
        'barbeiro' => $barbeiro,
        'agendamentos' => $agendamentos
    ];
}

// ============================================
// HISTÓRICO POR BARBEIRO (APENAS CONCLUÍDOS)
// ============================================
$historico_por_barbeiro = [];
foreach ($barbeiros_lista as $barbeiro) {
    $sql = "SELECT 
                h.id,
                h.data,
                h.horario,
                h.status,
                h.preco,
                h.cliente_nome,
                h.cliente_email,
                h.cliente_telefone,
                h.observacoes,
                s.nome as servico_nome
            FROM horarios h
            LEFT JOIN servicos_barbeiro s ON h.servico_id = s.id
            WHERE h.barbeiro_id = {$barbeiro['id']}
            AND h.status = 'concluido'
            ORDER BY h.data DESC, h.horario DESC
            LIMIT 50";
    $result = $conn->query($sql);
    $historico = [];
    while ($row = $result->fetch_assoc()) {
        $row['data_formatada'] = date('d/m/Y', strtotime($row['data']));
        $row['horario_formatado'] = substr($row['horario'], 0, 5);
        $historico[] = $row;
    }
    $historico_por_barbeiro[$barbeiro['id']] = [
        'barbeiro' => $barbeiro,
        'historico' => $historico
    ];
}

// ============================================
// FATURAMENTO ÚLTIMOS 7 DIAS
// ============================================
$sql = "SELECT 
            DATE(data) as dia,
            SUM(preco) as total_faturamento,
            COUNT(*) as total_agendamentos
        FROM horarios 
        WHERE status IN ('pago', 'concluido')
        AND data >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)
        GROUP BY DATE(data)
        ORDER BY dia ASC";
$result = $conn->query($sql);
$faturamento_semana = [];
while ($row = $result->fetch_assoc()) {
    $faturamento_semana[] = $row;
}

$dias_semana = [];
for ($i = 6; $i >= 0; $i--) {
    $dia = date('Y-m-d', strtotime("-$i days"));
    $dias_semana[$dia] = 0;
}
foreach ($faturamento_semana as $item) {
    $dias_semana[$item['dia']] = $item['total_faturamento'];
}
$faturamento_semana_dados = array_values($dias_semana);
$labels_semana = array_keys($dias_semana);
$labels_semana_formatados = array_map(function($d) {
    return date('d/m', strtotime($d));
}, $labels_semana);

// Status distribution
$status_distribution = [
    'Disponíveis' => $stats['disponivel'] ?? 0,
    'Reservados' => $stats['reservado'] ?? 0,
    'Confirmados' => $stats['pago'] ?? 0,
    'Cancelados' => $stats['cancelado'] ?? 0,
    'Concluídos' => $stats['concluidos'] ?? 0
];

// ============================================
// DADOS PARA RELATÓRIOS DETALHADOS
// ============================================

// Faturamento por barbeiro (mês atual)
$sql = "SELECT 
            b.id,
            b.nome,
            b.foto,
            COUNT(h.id) as total_servicos,
            SUM(h.preco) as faturamento,
            SUM(CASE WHEN h.status = 'concluido' THEN 1 ELSE 0 END) as concluidos,
            SUM(CASE WHEN h.status = 'pago' THEN 1 ELSE 0 END) as confirmados
        FROM barbeiros b
        LEFT JOIN horarios h ON b.id = h.barbeiro_id AND h.data >= '$primeiro_dia_mes'
        WHERE b.ativo = 1
        GROUP BY b.id
        ORDER BY faturamento DESC";
$result = $conn->query($sql);
$relatorio_barbeiros = [];
while ($row = $result->fetch_assoc()) {
    $relatorio_barbeiros[] = $row;
}

// Serviços mais populares
$sql = "SELECT 
            s.nome,
            COUNT(h.id) as total_agendamentos,
            SUM(CASE WHEN h.status = 'pago' THEN 1 ELSE 0 END) as confirmados,
            SUM(CASE WHEN h.status = 'concluido' THEN 1 ELSE 0 END) as concluidos
        FROM servicos_barbeiro s
        LEFT JOIN horarios h ON s.id = h.servico_id
        WHERE s.ativo = 1
        GROUP BY s.id
        ORDER BY total_agendamentos DESC
        LIMIT 10";
$result = $conn->query($sql);
$servicos_populares = [];
while ($row = $result->fetch_assoc()) {
    $servicos_populares[] = $row;
}

// Agendamentos por dia da semana (últimos 30 dias)
$sql = "SELECT 
            DAYOFWEEK(data) as dia_semana,
            COUNT(*) as total,
            SUM(CASE WHEN status = 'pago' THEN 1 ELSE 0 END) as confirmados,
            SUM(CASE WHEN status = 'concluido' THEN 1 ELSE 0 END) as concluidos
        FROM horarios
        WHERE data >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)
        GROUP BY DAYOFWEEK(data)
        ORDER BY dia_semana";
$result = $conn->query($sql);
$agendamentos_dia_semana = [];
$dias_nomes = ['', 'Domingo', 'Segunda', 'Terça', 'Quarta', 'Quinta', 'Sexta', 'Sábado'];
while ($row = $result->fetch_assoc()) {
    $row['dia_nome'] = $dias_nomes[$row['dia_semana']] ?? $row['dia_semana'];
    $agendamentos_dia_semana[] = $row;
}

// Faturamento mensal (últimos 6 meses)
$sql = "SELECT 
            DATE_FORMAT(data, '%Y-%m') as mes,
            SUM(preco) as total_faturamento,
            COUNT(*) as total_agendamentos
        FROM horarios
        WHERE status IN ('pago', 'concluido')
        AND data >= DATE_SUB(CURDATE(), INTERVAL 6 MONTH)
        GROUP BY DATE_FORMAT(data, '%Y-%m')
        ORDER BY mes ASC";
$result = $conn->query($sql);
$faturamento_mensal = [];
while ($row = $result->fetch_assoc()) {
    $mes_nome = date('M/Y', strtotime($row['mes'] . '-01'));
    $row['mes_nome'] = $mes_nome;
    $faturamento_mensal[] = $row;
}

// Dias com mais agendamentos
$sql = "SELECT 
            data,
            COUNT(*) as total,
            SUM(CASE WHEN status = 'pago' THEN 1 ELSE 0 END) as confirmados
        FROM horarios
        WHERE data >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)
        GROUP BY data
        ORDER BY total DESC
        LIMIT 10";
$result = $conn->query($sql);
$dias_mais_agendamentos = [];
while ($row = $result->fetch_assoc()) {
    $row['data_formatada'] = date('d/m/Y', strtotime($row['data']));
    $dias_mais_agendamentos[] = $row;
}

$conn->close();
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Admin - Thomaz Black Barbearia</title>
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;700;900&family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Inter', sans-serif;
            background: #0a0a0a;
            color: #fff;
            overflow-x: hidden;
        }
        ::-webkit-scrollbar { width: 8px; }
        ::-webkit-scrollbar-track { background: #1a1a1a; }
        ::-webkit-scrollbar-thumb { background: #c9a84c; border-radius: 4px; }

        .sidebar {
            position: fixed;
            left: 0;
            top: 0;
            width: 260px;
            height: 100vh;
            background: #0d0d0d;
            border-right: 1px solid rgba(201, 168, 76, 0.08);
            padding: 0;
            overflow-y: auto;
            z-index: 1000;
            transition: transform 0.3s ease;
        }
        .sidebar-header {
            text-align: center;
            padding: 28px 20px 20px;
            border-bottom: 1px solid rgba(201, 168, 76, 0.08);
            margin-bottom: 16px;
            background: linear-gradient(180deg, rgba(201, 168, 76, 0.03) 0%, transparent 100%);
        }
        .sidebar-header .logo-icon { font-size: 2.8em; display: block; margin-bottom: 4px; }
        .sidebar-header h2 {
            color: #c9a84c;
            font-family: 'Playfair Display', serif;
            font-size: 1.4em;
            font-weight: 700;
            letter-spacing: 1px;
        }
        .sidebar-header p {
            color: #666;
            font-size: 0.7em;
            letter-spacing: 3px;
            text-transform: uppercase;
            margin-top: 2px;
        }
        .sidebar-header .divider {
            width: 40px;
            height: 2px;
            background: linear-gradient(90deg, transparent, #c9a84c, transparent);
            margin: 10px auto 0;
        }
        .sidebar-menu { list-style: none; padding: 0 12px; }
        .sidebar-menu li { margin-bottom: 2px; }
        .sidebar-menu a {
            display: flex;
            align-items: center;
            padding: 12px 16px;
            color: #888;
            text-decoration: none;
            border-radius: 10px;
            transition: all 0.3s ease;
            font-size: 0.85em;
            font-weight: 500;
            position: relative;
            cursor: pointer;
        }
        .sidebar-menu a:hover { background: rgba(201, 168, 76, 0.06); color: #fff; }
        .sidebar-menu a.active {
            background: rgba(201, 168, 76, 0.1);
            color: #c9a84c;
        }
        .sidebar-menu a.active::before {
            content: '';
            position: absolute;
            left: 0;
            top: 50%;
            transform: translateY(-50%);
            width: 3px;
            height: 24px;
            background: #c9a84c;
            border-radius: 0 3px 3px 0;
        }
        .sidebar-menu a i { width: 24px; margin-right: 12px; font-size: 1em; text-align: center; }
        .sidebar-menu a .badge {
            margin-left: auto;
            background: #c9a84c;
            color: #0a0a0a;
            padding: 2px 10px;
            border-radius: 12px;
            font-size: 0.65em;
            font-weight: 700;
        }
        .sidebar-menu .menu-label {
            color: #444;
            font-size: 0.6em;
            text-transform: uppercase;
            letter-spacing: 2px;
            padding: 16px 16px 8px;
            font-weight: 600;
        }
        .sidebar-footer {
            position: absolute;
            bottom: 0;
            left: 0;
            right: 0;
            padding: 16px 20px 24px;
            border-top: 1px solid rgba(201, 168, 76, 0.06);
            background: #0d0d0d;
        }
        .sidebar-footer a {
            color: #555;
            text-decoration: none;
            display: block;
            padding: 10px 16px;
            border-radius: 10px;
            text-align: center;
            font-size: 0.8em;
            transition: all 0.3s;
            cursor: pointer;
        }
        .sidebar-footer a:hover { background: rgba(220, 53, 69, 0.1); color: #dc3545; }
        .sidebar-footer a i { margin-right: 8px; }

        .main-content {
            margin-left: 260px;
            padding: 24px 32px 40px;
            min-height: 100vh;
        }
        .top-bar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 16px 24px;
            background: rgba(22, 22, 22, 0.85);
            backdrop-filter: blur(12px);
            border-radius: 14px;
            margin-bottom: 28px;
            border: 1px solid rgba(201, 168, 76, 0.06);
            flex-wrap: wrap;
            gap: 12px;
        }
        .top-bar .left { display: flex; align-items: center; gap: 16px; }
        .top-bar h1 { font-size: 1.3em; font-weight: 600; }
        .top-bar h1 span {
            color: #c9a84c;
            font-family: 'Playfair Display', serif;
        }
        .top-bar .datetime { color: #666; font-size: 0.85em; font-weight: 300; }
        .top-bar .datetime i { color: #c9a84c; margin-right: 6px; }
        .top-bar .logout-btn {
            background: rgba(220, 53, 69, 0.12);
            color: #dc3545;
            border: 1px solid rgba(220, 53, 69, 0.15);
            padding: 8px 20px;
            border-radius: 10px;
            cursor: pointer;
            font-weight: 600;
            font-size: 0.8em;
            transition: all 0.3s;
            font-family: 'Inter', sans-serif;
        }
        .top-bar .logout-btn:hover {
            background: #dc3545;
            color: #fff;
            border-color: #dc3545;
        }
        .mobile-toggle {
            display: none;
            background: none;
            border: none;
            color: #c9a84c;
            font-size: 1.4em;
            cursor: pointer;
            padding: 4px;
        }

        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(140px, 1fr));
            gap: 16px;
            margin-bottom: 28px;
        }
        .stat-card {
            background: rgba(22, 22, 22, 0.7);
            backdrop-filter: blur(8px);
            padding: 18px 20px;
            border-radius: 12px;
            border: 1px solid rgba(201, 168, 76, 0.06);
            transition: all 0.4s ease;
            position: relative;
            overflow: hidden;
        }
        .stat-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 2px;
            background: linear-gradient(90deg, transparent, #c9a84c, transparent);
            opacity: 0;
            transition: opacity 0.4s;
        }
        .stat-card:hover::before { opacity: 1; }
        .stat-card:hover {
            transform: translateY(-4px);
            border-color: rgba(201, 168, 76, 0.15);
            box-shadow: 0 12px 40px rgba(0,0,0,0.3);
        }
        .stat-card .stat-number {
            font-size: 1.8em;
            font-weight: 700;
            color: #c9a84c;
            font-family: 'Playfair Display', serif;
            letter-spacing: 1px;
        }
        .stat-card .stat-label { color: #888; font-size: 0.7em; margin-top: 4px; font-weight: 400; text-transform: uppercase; letter-spacing: 0.5px; }

        .card {
            background: rgba(22, 22, 22, 0.7);
            backdrop-filter: blur(8px);
            border-radius: 14px;
            border: 1px solid rgba(201, 168, 76, 0.06);
            padding: 22px 24px;
            margin-bottom: 20px;
            transition: border-color 0.3s;
        }
        .card:hover { border-color: rgba(201, 168, 76, 0.1); }
        .card-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 16px;
            flex-wrap: wrap;
            gap: 10px;
        }
        .card-header h3 {
            color: #c9a84c;
            font-family: 'Playfair Display', serif;
            font-size: 1.1em;
            font-weight: 700;
        }
        .card-header .card-actions {
            display: flex;
            gap: 8px;
            flex-wrap: wrap;
        }
        .card-header .card-actions button {
            background: rgba(45, 45, 45, 0.6);
            border: 1px solid rgba(255,255,255,0.04);
            color: #aaa;
            padding: 6px 14px;
            border-radius: 8px;
            cursor: pointer;
            transition: all 0.3s;
            font-size: 0.75em;
            font-family: 'Inter', sans-serif;
        }
        .card-header .card-actions button:hover {
            background: rgba(201, 168, 76, 0.1);
            color: #c9a84c;
            border-color: rgba(201, 168, 76, 0.1);
        }
        .card-header .card-actions .btn-primary {
            background: linear-gradient(135deg, #c9a84c, #a8893a);
            color: #0a0a0a;
            border: none;
        }
        .card-header .card-actions .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 20px rgba(201, 168, 76, 0.3);
        }

        .two-column { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 20px; }
        .three-column { display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 20px; margin-bottom: 20px; }
        @media (max-width: 1024px) { .two-column { grid-template-columns: 1fr; } .three-column { grid-template-columns: 1fr 1fr; } }
        @media (max-width: 768px) { .three-column { grid-template-columns: 1fr; } }

        .chart-container { position: relative; height: 260px; width: 100%; }
        .chart-container-small { position: relative; height: 200px; width: 100%; }

        .barbeiro-filter-tabs {
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
            margin-bottom: 20px;
            padding: 12px 16px;
            background: rgba(13, 13, 13, 0.6);
            border-radius: 12px;
            border: 1px solid rgba(255,255,255,0.04);
        }
        .barbeiro-filter-tabs .filter-btn {
            display: flex;
            align-items: center;
            gap: 8px;
            padding: 8px 18px;
            border-radius: 10px;
            border: 1px solid #2a2a2a;
            background: rgba(10, 10, 10, 0.5);
            color: #888;
            cursor: pointer;
            transition: all 0.3s;
            font-family: 'Inter', sans-serif;
            font-size: 0.8em;
            font-weight: 500;
        }
        .barbeiro-filter-tabs .filter-btn:hover {
            border-color: #444;
            color: #fff;
            background: rgba(201, 168, 76, 0.05);
        }
        .barbeiro-filter-tabs .filter-btn.active {
            border-color: #c9a84c;
            color: #c9a84c;
            background: rgba(201, 168, 76, 0.08);
        }
        .barbeiro-filter-tabs .filter-btn .avatar-small {
            width: 24px;
            height: 24px;
            border-radius: 50%;
            object-fit: cover;
            border: 1px solid rgba(201, 168, 76, 0.15);
        }
        .barbeiro-filter-tabs .filter-btn .count {
            background: rgba(201, 168, 76, 0.12);
            color: #c9a84c;
            padding: 0 8px;
            border-radius: 10px;
            font-size: 0.7em;
            font-weight: 600;
        }
        .barbeiro-filter-tabs .filter-btn .count-historico {
            background: rgba(40, 167, 69, 0.12);
            color: #28a745;
            padding: 0 8px;
            border-radius: 10px;
            font-size: 0.7em;
            font-weight: 600;
        }

        .agendamentos-container {
            max-height: 500px;
            overflow-y: auto;
        }
        .agendamento-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 12px 16px;
            border-bottom: 1px solid rgba(255,255,255,0.03);
            transition: background 0.3s;
            flex-wrap: wrap;
            gap: 8px;
            border-radius: 8px;
        }
        .agendamento-item:hover { background: rgba(201, 168, 76, 0.03); }
        .agendamento-item:last-child { border-bottom: none; }
        .agendamento-item .info { flex: 1; min-width: 140px; }
        .agendamento-item .info .data {
            font-weight: 600;
            font-size: 0.85em;
            color: #c9a84c;
        }
        .agendamento-item .info .data i { margin-right: 4px; }
        .agendamento-item .info .cliente {
            color: #aaa;
            font-size: 0.8em;
        }
        .agendamento-item .info .cliente i { color: #666; margin-right: 4px; }
        .agendamento-item .info .servico {
            color: #17a2b8;
            font-size: 0.75em;
        }
        .agendamento-item .info .observacoes {
            color: #666;
            font-size: 0.7em;
            font-style: italic;
        }
        .agendamento-item .status-badge {
            padding: 4px 14px;
            border-radius: 20px;
            font-size: 0.65em;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        .status-pago { background: rgba(40, 167, 69, 0.15); color: #28a745; border: 1px solid rgba(40, 167, 69, 0.1); }
        .status-concluido { background: rgba(40, 167, 69, 0.15); color: #28a745; border: 1px solid rgba(40, 167, 69, 0.1); }
        .status-reservado { background: rgba(255, 193, 7, 0.12); color: #ffc107; border: 1px solid rgba(255, 193, 7, 0.08); }
        .status-disponivel { background: rgba(23, 162, 184, 0.12); color: #17a2b8; border: 1px solid rgba(23, 162, 184, 0.08); }
        .status-cancelado { background: rgba(220, 53, 69, 0.12); color: #dc3545; border: 1px solid rgba(220, 53, 69, 0.08); }

        .agendamento-item .valor {
            color: #c9a84c;
            font-weight: 700;
            font-size: 0.85em;
            min-width: 70px;
            text-align: right;
        }

        .historico-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px 16px;
            border-bottom: 1px solid rgba(255,255,255,0.02);
            flex-wrap: wrap;
            gap: 8px;
            border-radius: 8px;
            transition: background 0.3s;
        }
        .historico-item:hover { background: rgba(40, 167, 69, 0.02); }
        .historico-item .info { flex: 1; min-width: 140px; }
        .historico-item .info .data {
            font-weight: 600;
            font-size: 0.85em;
            color: #28a745;
        }
        .historico-item .info .data i { color: #28a745; margin-right: 4px; }
        .historico-item .info .cliente { color: #aaa; font-size: 0.8em; }
        .historico-item .info .servico { color: #c9a84c; font-size: 0.75em; }
        .historico-item .valor {
            color: #c9a84c;
            font-weight: 700;
            font-size: 0.85em;
            min-width: 70px;
            text-align: right;
        }

        /* RELATÓRIOS */
        .relatorio-card {
            background: rgba(10, 10, 10, 0.6);
            padding: 16px 20px;
            border-radius: 12px;
            border-left: 3px solid #c9a84c;
            transition: all 0.3s;
        }
        .relatorio-card:hover {
            border-color: #c9a84c;
            transform: translateX(5px);
        }
        .relatorio-card .relatorio-nome {
            font-weight: 600;
            font-size: 0.95em;
        }
        .relatorio-card .relatorio-valor {
            color: #c9a84c;
            font-weight: 700;
            font-size: 1.2em;
        }
        .relatorio-card .relatorio-detalhe {
            color: #666;
            font-size: 0.75em;
        }
        .relatorio-card .relatorio-barbeiro-foto {
            width: 32px;
            height: 32px;
            border-radius: 50%;
            object-fit: cover;
            border: 2px solid rgba(201, 168, 76, 0.15);
        }

        /* BARBEIROS - CARDS */
        .barbeiro-card {
            background: rgba(10, 10, 10, 0.6);
            padding: 16px 18px;
            border-radius: 12px;
            border-left: 3px solid #17a2b8;
            transition: all 0.3s ease;
            margin-bottom: 10px;
        }
        .barbeiro-card:hover {
            border-color: #c9a84c;
            transform: translateY(-2px);
            box-shadow: 0 8px 30px rgba(0,0,0,0.2);
        }
        .barbeiro-card .barbeiro-header {
            display: flex;
            gap: 15px;
            align-items: center;
            margin-bottom: 10px;
        }
        .barbeiro-card .barbeiro-avatar {
            width: 48px;
            height: 48px;
            border-radius: 50%;
            object-fit: cover;
            border: 2px solid rgba(201, 168, 76, 0.2);
        }
        .barbeiro-card .barbeiro-info { flex: 1; }
        .barbeiro-card .barbeiro-info .nome {
            font-size: 1.05em;
            font-weight: 600;
        }
        .barbeiro-card .barbeiro-info .email {
            color: #aaa;
            font-size: 0.8em;
        }
        .barbeiro-card .barbeiro-status {
            padding: 2px 12px;
            border-radius: 12px;
            font-size: 0.65em;
            font-weight: 600;
            white-space: nowrap;
        }
        .barbeiro-card .barbeiro-status.ativo {
            background: rgba(40, 167, 69, 0.15);
            color: #28a745;
            border: 1px solid rgba(40, 167, 69, 0.1);
        }
        .barbeiro-card .barbeiro-status.inativo {
            background: rgba(220, 53, 69, 0.12);
            color: #dc3545;
            border: 1px solid rgba(220, 53, 69, 0.08);
        }
        .barbeiro-card .barbeiro-detalhes {
            display: flex;
            gap: 15px;
            font-size: 0.8em;
            color: #aaa;
            flex-wrap: wrap;
        }
        .barbeiro-card .barbeiro-acoes {
            margin-top: 10px;
            display: flex;
            gap: 6px;
            flex-wrap: wrap;
        }
        .barbeiro-card .barbeiro-acoes button {
            padding: 5px 14px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-size: 0.75em;
            font-weight: 600;
            transition: all 0.3s;
            font-family: 'Inter', sans-serif;
        }
        .barbeiro-card .barbeiro-acoes button:hover { transform: translateY(-2px); }
        .btn-edit { background: rgba(201, 168, 76, 0.12); color: #c9a84c; border: 1px solid rgba(201, 168, 76, 0.08); }
        .btn-edit:hover { background: #c9a84c; color: #0a0a0a; }
        .btn-delete { background: rgba(220, 53, 69, 0.1); color: #dc3545; border: 1px solid rgba(220, 53, 69, 0.08); }
        .btn-delete:hover { background: #dc3545; color: #fff; }
        .btn-reset { background: rgba(255, 193, 7, 0.1); color: #ffc107; border: 1px solid rgba(255, 193, 7, 0.08); }
        .btn-reset:hover { background: #ffc107; color: #0a0a0a; }

        .section-content { display: none; }
        .section-content.active { display: block; }

        .empty-message {
            color: #666;
            text-align: center;
            padding: 30px 20px;
        }

        .loading { text-align: center; padding: 30px; }
        .spinner {
            border: 3px solid #2a2a2a;
            border-top: 3px solid #c9a84c;
            border-radius: 50%;
            width: 32px;
            height: 32px;
            animation: spin 1s linear infinite;
            margin: 10px auto;
        }
        @keyframes spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }

        /* MODAL */
        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.85);
            backdrop-filter: blur(8px);
            z-index: 2000;
            justify-content: center;
            align-items: center;
        }
        .modal.active { display: flex; }
        .modal-content {
            background: rgba(22, 22, 22, 0.95);
            padding: 32px 36px;
            border-radius: 16px;
            max-width: 580px;
            width: 92%;
            max-height: 85vh;
            overflow-y: auto;
            border: 1px solid rgba(201, 168, 76, 0.08);
            box-shadow: 0 30px 80px rgba(0,0,0,0.6);
        }
        .modal-content h2 {
            color: #c9a84c;
            font-family: 'Playfair Display', serif;
            margin-bottom: 20px;
            font-size: 1.3em;
        }
        .modal-content .form-group { margin-bottom: 16px; }
        .modal-content .form-group label {
            display: block;
            margin-bottom: 5px;
            color: #aaa;
            font-size: 0.8em;
            font-weight: 500;
        }
        .modal-content .form-group input,
        .modal-content .form-group select,
        .modal-content .form-group textarea {
            width: 100%;
            padding: 10px 14px;
            border-radius: 10px;
            border: 1.5px solid #2a2a2a;
            background: rgba(10, 10, 10, 0.8);
            color: #fff;
            font-size: 0.9em;
            font-family: 'Inter', sans-serif;
            transition: all 0.3s;
        }
        .modal-content .form-group input:focus,
        .modal-content .form-group select:focus,
        .modal-content .form-group textarea:focus {
            outline: none;
            border-color: #c9a84c;
            box-shadow: 0 0 0 3px rgba(201, 168, 76, 0.06);
        }
        .modal-actions {
            display: flex;
            gap: 10px;
            margin-top: 22px;
        }
        .modal-actions button {
            padding: 10px 24px;
            border: none;
            border-radius: 10px;
            cursor: pointer;
            font-weight: 600;
            transition: all 0.3s;
            font-family: 'Inter', sans-serif;
            font-size: 0.85em;
        }
        .modal-actions .btn-primary { background: #c9a84c; color: #0a0a0a; }
        .modal-actions .btn-primary:hover { background: #dbb95c; }
        .modal-actions .btn-secondary { background: #2a2a2a; color: #aaa; }
        .modal-actions .btn-secondary:hover { background: #3a3a3a; color: #fff; }

        /* UPLOAD FOTO */
        .barbeiro-foto-preview {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            object-fit: cover;
            border: 2px solid rgba(201, 168, 76, 0.2);
            transition: all 0.3s;
        }
        .barbeiro-foto-preview:hover {
            border-color: #c9a84c;
            transform: scale(1.05);
        }
        #upload-progress {
            margin-top: 8px;
            padding: 4px 0;
            display: none;
        }
        #upload-bar {
            height: 4px;
            background: linear-gradient(90deg, #c9a84c, #a8893a);
            border-radius: 2px;
            transition: width 0.3s ease;
            width: 0%;
        }
        #upload-text {
            font-size: 0.7em;
            color: #888;
            display: block;
            margin-top: 4px;
        }
        #upload-status {
            font-size: 0.6em;
            color: #28a745;
            background: rgba(0,0,0,0.8);
            padding: 2px 10px;
            border-radius: 4px;
            position: absolute;
            bottom: -8px;
            left: 50%;
            transform: translateX(-50%);
            white-space: nowrap;
            display: none;
        }
        .foto-upload-wrapper {
            position: relative;
            display: inline-block;
        }
        label[for="foto-upload"] {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            padding: 8px 18px;
            background: rgba(201, 168, 76, 0.12);
            color: #c9a84c;
            border: 1px solid rgba(201, 168, 76, 0.08);
            border-radius: 8px;
            cursor: pointer;
            font-size: 0.8em;
            font-weight: 500;
            transition: all 0.3s;
            font-family: 'Inter', sans-serif;
        }
        label[for="foto-upload"]:hover {
            background: rgba(201, 168, 76, 0.2);
            transform: translateY(-1px);
        }
        label[for="foto-upload"] i { font-size: 0.9em; }

        .filters-section {
            display: flex;
            gap: 12px;
            flex-wrap: wrap;
            margin-bottom: 20px;
            padding: 12px 16px;
            background: rgba(13, 13, 13, 0.6);
            border-radius: 10px;
            border: 1px solid rgba(255,255,255,0.05);
            align-items: center;
        }
        .filters-section .filter-group {
            display: flex;
            gap: 8px;
            align-items: center;
            flex-wrap: wrap;
        }
        .filters-section .filter-group label {
            color: #888;
            font-size: 0.7em;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        .filters-section .filter-group input,
        .filters-section .filter-group select {
            padding: 8px 14px;
            border-radius: 8px;
            border: 1px solid #2d2d2d;
            background: rgba(0,0,0,0.3);
            color: #fff;
            font-size: 0.85em;
            font-family: 'Inter', sans-serif;
            min-width: 120px;
        }
        .filters-section .filter-group input:focus,
        .filters-section .filter-group select:focus {
            outline: none;
            border-color: #c9a84c;
        }
        .filters-section .filter-group .search-input { min-width: 180px; flex: 1; }
        .filters-section .filter-group .clear-btn {
            padding: 8px 16px;
            background: rgba(220, 53, 69, 0.1);
            color: #dc3545;
            border: 1px solid rgba(220, 53, 69, 0.08);
            border-radius: 8px;
            cursor: pointer;
            font-size: 0.75em;
            font-weight: 600;
            transition: all 0.3s;
        }
        .filters-section .filter-group .clear-btn:hover {
            background: #dc3545;
            color: #fff;
        }

        @media (max-width: 992px) {
            .sidebar { transform: translateX(-100%); }
            .sidebar.open { transform: translateX(0); }
            .main-content { margin-left: 0; padding: 16px; }
            .top-bar { flex-direction: column; text-align: center; padding: 14px 18px; }
            .top-bar .left { flex-direction: column; width: 100%; }
            .mobile-toggle { display: block !important; }
            .stats-grid { grid-template-columns: 1fr 1fr; }
            .barbeiro-filter-tabs { justify-content: center; }
            .filters-section { flex-direction: column; align-items: stretch; }
            .filters-section .filter-group .search-input { min-width: unset; }
            .modal-content { padding: 24px 20px; max-width: 95%; }
        }
        @media (max-width: 576px) {
            .stats-grid { grid-template-columns: 1fr; }
            .top-bar h1 { font-size: 1.1em; }
            .two-column { grid-template-columns: 1fr; }
            .three-column { grid-template-columns: 1fr; }
            .barbeiro-filter-tabs .filter-btn { font-size: 0.7em; padding: 6px 12px; }
            .barbeiro-foto-preview { width: 64px; height: 64px; }
            .modal-content { padding: 18px 14px; }
        }

        @keyframes fadeInUp {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }
        .stat-card, .card { animation: fadeInUp 0.5s ease forwards; }
        .stat-card:nth-child(1) { animation-delay: 0.05s; }
        .stat-card:nth-child(2) { animation-delay: 0.10s; }
        .stat-card:nth-child(3) { animation-delay: 0.15s; }
        .stat-card:nth-child(4) { animation-delay: 0.20s; }
        .stat-card:nth-child(5) { animation-delay: 0.25s; }
        .stat-card:nth-child(6) { animation-delay: 0.30s; }
        .stat-card:nth-child(7) { animation-delay: 0.35s; }
        .stat-card:nth-child(8) { animation-delay: 0.40s; }
    </style>
</head>
<body>

    <!-- SIDEBAR -->
    <nav class="sidebar" id="sidebar">
        <div class="sidebar-header">
            <span class="logo-icon">✂️</span>
            <h2>Thomaz Black</h2>
            <p>Barbearia</p>
            <div class="divider"></div>
        </div>
        <ul class="sidebar-menu">
            <li class="menu-label">Navegação</li>
            <li><a class="active" onclick="showSection('dashboard')"><i class="fas fa-home"></i> Dashboard</a></li>
            <li><a onclick="showSection('agendamentos')"><i class="fas fa-calendar-check"></i> Agendamentos</a></li>
            <li><a onclick="showSection('historico')"><i class="fas fa-history"></i> Histórico</a></li>
            <li><a onclick="showSection('pagamentos')"><i class="fas fa-credit-card"></i> Pagamentos</a></li>
            <li class="menu-label">Gerenciamento</li>
            <li><a onclick="showSection('barbeiros')"><i class="fas fa-users"></i> Barbeiros</a></li>
            <li><a onclick="showSection('relatorios')"><i class="fas fa-chart-bar"></i> Relatórios</a></li>
        </ul>
        <div class="sidebar-footer">
            <a onclick="logout()"><i class="fas fa-sign-out-alt"></i> Sair</a>
        </div>
    </nav>

    <!-- MAIN CONTENT -->
    <div class="main-content">
        <!-- Top Bar -->
        <div class="top-bar">
            <div class="left">
                <button class="mobile-toggle" onclick="toggleSidebar()">
                    <i class="fas fa-bars"></i>
                </button>
                <h1>Dashboard <span>Thomaz Black</span></h1>
            </div>
            <div class="datetime" id="datetime">
                <i class="fas fa-calendar-alt"></i> 
                <span id="data-hora"></span>
            </div>
            <button class="logout-btn" onclick="logout()"><i class="fas fa-sign-out-alt"></i> Sair</button>
        </div>

        <!-- SECTION: DASHBOARD -->
        <div id="section-dashboard" class="section-content active">
            <div class="stats-grid">
                <div class="stat-card">
                    <div class="stat-number"><?php echo $stats['total'] ?? 0; ?></div>
                    <div class="stat-label">Total de Horários</div>
                </div>
                <div class="stat-card">
                    <div class="stat-number"><?php echo $stats['disponivel'] ?? 0; ?></div>
                    <div class="stat-label">Disponíveis</div>
                </div>
                <div class="stat-card">
                    <div class="stat-number"><?php echo $stats['reservado'] ?? 0; ?></div>
                    <div class="stat-label">Reservados</div>
                </div>
                <div class="stat-card">
                    <div class="stat-number"><?php echo $stats['pago'] ?? 0; ?></div>
                    <div class="stat-label">Confirmados</div>
                </div>
                <div class="stat-card" style="border-color: rgba(40, 167, 69, 0.15);">
                    <div class="stat-number" style="color: #28a745;"><?php echo $stats['concluidos'] ?? 0; ?></div>
                    <div class="stat-label">Concluídos</div>
                </div>
                <div class="stat-card" style="border-color: rgba(255, 193, 7, 0.15);">
                    <div class="stat-number" style="color: #ffc107;"><?php echo $stats['pendentes'] ?? 0; ?></div>
                    <div class="stat-label">Pagamentos Pendentes</div>
                </div>
                <div class="stat-card">
                    <div class="stat-number">R$ <?php echo number_format($stats['faturamento_mes'] ?? 0, 2, ',', '.'); ?></div>
                    <div class="stat-label">Faturamento do Mês</div>
                </div>
                <div class="stat-card">
                    <div class="stat-number"><?php echo $stats['total_barbeiros'] ?? 0; ?></div>
                    <div class="stat-label">Barbeiros Ativos</div>
                </div>
            </div>

            <div class="two-column">
                <div class="card">
                    <div class="card-header">
                        <h3>Faturamento Últimos 7 Dias</h3>
                    </div>
                    <div class="chart-container">
                        <canvas id="chartFaturamento"></canvas>
                    </div>
                </div>
                <div class="card">
                    <div class="card-header">
                        <h3>Distribuição de Status</h3>
                    </div>
                    <div class="chart-container-small">
                        <canvas id="chartStatus"></canvas>
                    </div>
                </div>
            </div>
        </div>

        <!-- SECTION: AGENDAMENTOS -->
        <div id="section-agendamentos" class="section-content">
            <div class="card">
                <div class="card-header">
                    <h3>Agendamentos por Barbeiro</h3>
                    <div class="card-actions">
                        <button onclick="location.reload()"><i class="fas fa-sync"></i> Atualizar</button>
                    </div>
                </div>
                
                <div class="barbeiro-filter-tabs" id="agendamento-filters">
                    <button class="filter-btn active" data-barbeiro="todos" onclick="filtrarAgendamentos('todos')">
                        <i class="fas fa-users"></i> Todos
                        <span class="count"><?php 
                            $total = 0;
                            foreach ($agendamentos_por_barbeiro as $item) $total += count($item['agendamentos']);
                            echo $total;
                        ?></span>
                    </button>
                    <?php foreach ($agendamentos_por_barbeiro as $id => $item): 
                        $count = count($item['agendamentos']);
                    ?>
                        <button class="filter-btn" data-barbeiro="<?php echo $id; ?>" onclick="filtrarAgendamentos(<?php echo $id; ?>)">
                            <?php if ($item['barbeiro']['foto']): ?>
                                <img class="avatar-small" src="<?php echo $item['barbeiro']['foto']; ?>" alt="Barbeiro">
                            <?php else: ?>
                                <i class="fas fa-user"></i>
                            <?php endif; ?>
                            <?php echo $item['barbeiro']['nome']; ?>
                            <span class="count"><?php echo $count; ?></span>
                        </button>
                    <?php endforeach; ?>
                </div>

                <div id="agendamentos-content">
                    <?php foreach ($agendamentos_por_barbeiro as $id => $item): ?>
                        <div class="agendamentos-barbeiro" data-barbeiro="<?php echo $id; ?>" style="<?php echo $id == array_key_first($agendamentos_por_barbeiro) ? '' : 'display:none;'; ?>">
                            <div style="display:flex; align-items:center; gap:12px; margin-bottom:12px; padding:10px 14px; background:rgba(13,13,13,0.6); border-radius:10px;">
                                <?php if ($item['barbeiro']['foto']): ?>
                                    <img src="<?php echo $item['barbeiro']['foto']; ?>" style="width:36px;height:36px;border-radius:50%;object-fit:cover;border:2px solid rgba(201,168,76,0.2);">
                                <?php else: ?>
                                    <div style="width:36px;height:36px;border-radius:50%;background:linear-gradient(135deg,#c9a84c,#a8893a);display:flex;align-items:center;justify-content:center;font-weight:700;color:#0a0a0a;">
                                        <?php echo strtoupper(substr($item['barbeiro']['nome'], 0, 1)); ?>
                                    </div>
                                <?php endif; ?>
                                <div>
                                    <strong><?php echo $item['barbeiro']['nome']; ?></strong>
                                    <span style="color:#666; font-size:0.8em; margin-left:8px;">
                                        <?php echo $item['barbeiro']['especialidades'] ? '✂️ ' . $item['barbeiro']['especialidades'] : ''; ?>
                                    </span>
                                </div>
                                <span style="margin-left:auto; color:#888; font-size:0.8em;">
                                    <i class="fas fa-calendar-check"></i> <?php echo count($item['agendamentos']); ?> agendamentos
                                </span>
                            </div>
                            
                            <div class="agendamentos-container">
                                <?php if (empty($item['agendamentos'])): ?>
                                    <p class="empty-message">Nenhum agendamento para este barbeiro</p>
                                <?php else: ?>
                                    <?php foreach ($item['agendamentos'] as $agendamento): ?>
                                        <div class="agendamento-item">
                                            <div class="info">
                                                <div class="data">
                                                    <i class="fas fa-calendar-day"></i>
                                                    <?php echo $agendamento['data_formatada']; ?> 
                                                    <?php echo $agendamento['horario_formatado']; ?>
                                                </div>
                                                <div class="servico"><?php echo $agendamento['servico_nome'] ?? 'Serviço não definido'; ?></div>
                                                <div class="cliente">
                                                    <i class="fas fa-user"></i>
                                                    <?php echo $agendamento['cliente_nome'] ?? 'Cliente não informado'; ?>
                                                    <?php if ($agendamento['cliente_telefone']): ?>
                                                        <span style="color:#666; font-size:0.85em;"><?php echo $agendamento['cliente_telefone']; ?></span>
                                                    <?php endif; ?>
                                                </div>
                                                <?php if ($agendamento['observacoes']): ?>
                                                    <div class="observacoes"><?php echo $agendamento['observacoes']; ?></div>
                                                <?php endif; ?>
                                            </div>
                                            <span class="status-badge status-<?php echo $agendamento['status']; ?>">
                                                <?php 
                                                    $labels = ['pago' => 'Confirmado', 'concluido' => 'Concluído', 
                                                               'reservado' => 'Reservado', 'disponivel' => 'Disponível', 
                                                               'cancelado' => 'Cancelado'];
                                                    echo $labels[$agendamento['status']] ?? ucfirst($agendamento['status']); 
                                                ?>
                                            </span>
                                            <?php if ($agendamento['preco']): ?>
                                                <span class="valor">R$ <?php echo number_format($agendamento['preco'], 2, ',', '.'); ?></span>
                                            <?php endif; ?>
                                        </div>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>

        <!-- SECTION: HISTÓRICO -->
        <div id="section-historico" class="section-content">
            <div class="card">
                <div class="card-header">
                    <h3>Histórico de Serviços</h3>
                    <div class="card-actions">
                        <button onclick="location.reload()"><i class="fas fa-sync"></i> Atualizar</button>
                    </div>
                </div>
                
                <div class="barbeiro-filter-tabs" id="historico-filters">
                    <button class="filter-btn active" data-barbeiro="todos" onclick="filtrarHistorico('todos')">
                        <i class="fas fa-users"></i> Todos
                        <span class="count-historico"><?php 
                            $total = 0;
                            foreach ($historico_por_barbeiro as $item) $total += count($item['historico']);
                            echo $total;
                        ?></span>
                    </button>
                    <?php foreach ($historico_por_barbeiro as $id => $item): 
                        $count = count($item['historico']);
                    ?>
                        <button class="filter-btn" data-barbeiro="<?php echo $id; ?>" onclick="filtrarHistorico(<?php echo $id; ?>)">
                            <?php if ($item['barbeiro']['foto']): ?>
                                <img class="avatar-small" src="<?php echo $item['barbeiro']['foto']; ?>" alt="Barbeiro">
                            <?php else: ?>
                                <i class="fas fa-user"></i>
                            <?php endif; ?>
                            <?php echo $item['barbeiro']['nome']; ?>
                            <span class="count-historico"><?php echo $count; ?></span>
                        </button>
                    <?php endforeach; ?>
                </div>

                <div id="historico-content">
                    <?php foreach ($historico_por_barbeiro as $id => $item): ?>
                        <div class="historico-barbeiro" data-barbeiro="<?php echo $id; ?>" style="<?php echo $id == array_key_first($historico_por_barbeiro) ? '' : 'display:none;'; ?>">
                            <div style="display:flex; align-items:center; gap:12px; margin-bottom:12px; padding:10px 14px; background:rgba(13,13,13,0.6); border-radius:10px;">
                                <?php if ($item['barbeiro']['foto']): ?>
                                    <img src="<?php echo $item['barbeiro']['foto']; ?>" style="width:36px;height:36px;border-radius:50%;object-fit:cover;border:2px solid rgba(40,167,69,0.2);">
                                <?php else: ?>
                                    <div style="width:36px;height:36px;border-radius:50%;background:linear-gradient(135deg,#28a745,#1e7e34);display:flex;align-items:center;justify-content:center;font-weight:700;color:#fff;">
                                        <?php echo strtoupper(substr($item['barbeiro']['nome'], 0, 1)); ?>
                                    </div>
                                <?php endif; ?>
                                <div>
                                    <strong><?php echo $item['barbeiro']['nome']; ?></strong>
                                    <span style="color:#666; font-size:0.8em; margin-left:8px;">
                                        <?php echo $item['barbeiro']['especialidades'] ? '✂️ ' . $item['barbeiro']['especialidades'] : ''; ?>
                                    </span>
                                </div>
                                <span style="margin-left:auto; color:#28a745; font-size:0.8em;">
                                    <i class="fas fa-check-circle"></i> <?php echo count($item['historico']); ?> serviços
                                </span>
                            </div>
                            
                            <div class="agendamentos-container">
                                <?php 
                                $total_valor = 0;
                                foreach ($item['historico'] as $h) $total_valor += $h['preco'] ?? 0;
                                ?>
                                <?php if (!empty($item['historico'])): ?>
                                    <div style="padding:8px 14px; background:rgba(40,167,69,0.05); border-radius:8px; margin-bottom:12px; display:flex; justify-content:space-between; flex-wrap:wrap; gap:8px;">
                                        <span style="color:#aaa;">Total: <strong style="color:#28a745;"><?php echo count($item['historico']); ?></strong> serviços</span>
                                        <span style="color:#aaa;">Valor total: <strong style="color:#c9a84c;">R$ <?php echo number_format($total_valor, 2, ',', '.'); ?></strong></span>
                                    </div>
                                <?php endif; ?>
                                
                                <?php if (empty($item['historico'])): ?>
                                    <p class="empty-message">Nenhum serviço concluído</p>
                                <?php else: ?>
                                    <?php foreach ($item['historico'] as $historico): ?>
                                        <div class="historico-item">
                                            <div class="info">
                                                <div class="data">
                                                    <i class="fas fa-check-circle"></i>
                                                    <?php echo $historico['data_formatada']; ?> 
                                                    <?php echo $historico['horario_formatado']; ?>
                                                </div>
                                                <div class="servico"><?php echo $historico['servico_nome'] ?? 'Serviço não definido'; ?></div>
                                                <div class="cliente">
                                                    <i class="fas fa-user"></i>
                                                    <?php echo $historico['cliente_nome'] ?? 'Cliente não informado'; ?>
                                                    <?php if ($historico['cliente_telefone']): ?>
                                                        <span style="color:#666; font-size:0.85em;"><?php echo $historico['cliente_telefone']; ?></span>
                                                    <?php endif; ?>
                                                </div>
                                                <?php if ($historico['observacoes']): ?>
                                                    <div style="color:#666; font-size:0.75em; margin-top:2px;"><?php echo $historico['observacoes']; ?></div>
                                                <?php endif; ?>
                                            </div>
                                            <span class="status-badge status-concluido">Concluído</span>
                                            <?php if ($historico['preco']): ?>
                                                <span class="valor">R$ <?php echo number_format($historico['preco'], 2, ',', '.'); ?></span>
                                            <?php endif; ?>
                                        </div>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>

        <!-- SECTION: PAGAMENTOS -->
        <div id="section-pagamentos" class="section-content">
            <div class="card">
                <div class="card-header">
                    <h3>Pagamentos Pendentes</h3>
                    <div class="card-actions">
                        <button onclick="location.reload()"><i class="fas fa-sync"></i> Atualizar</button>
                    </div>
                </div>
                <div id="pagamentos-content">
                    <div class="loading">
                        <div class="spinner"></div>
                        <p>Carregando...</p>
                    </div>
                </div>
            </div>
        </div>

        <!-- SECTION: BARBEIROS -->
        <div id="section-barbeiros" class="section-content">
            <div class="card">
                <div class="card-header">
                    <h3>Barbeiros</h3>
                    <div class="card-actions">
                        <button class="btn-primary" onclick="abrirModalBarbeiro()">
                            <i class="fas fa-plus"></i> Novo
                        </button>
                        <button onclick="location.reload()">
                            <i class="fas fa-sync"></i>
                        </button>
                    </div>
                </div>
                
                <div style="display:flex; gap:20px; flex-wrap:wrap; padding:12px 16px; background:rgba(13,13,13,0.6); border-radius:10px; margin-bottom:20px;">
                    <span>Total: <strong style="color:#c9a84c;"><?php echo count($barbeiros_lista); ?></strong></span>
                    <span>Ativos: <strong style="color:#28a745;">
                        <?php 
                            $ativos = 0;
                            foreach ($barbeiros_lista as $b) if ($b['ativo']) $ativos++;
                            echo $ativos;
                        ?>
                    </strong></span>
                </div>
                
                <div id="barbeiros-lista" style="display:grid; grid-template-columns:repeat(auto-fill,minmax(320px,1fr)); gap:14px;">
                    <?php foreach ($barbeiros_lista as $barbeiro): 
                        $foto = $barbeiro['foto'] ?? 'https://ui-avatars.com/api/?name=' . urlencode($barbeiro['nome']) . '&background=c9a84c&color=0a0a0a&size=150&bold=true';
                        $statusClass = $barbeiro['ativo'] ? 'ativo' : 'inativo';
                        $statusText = $barbeiro['ativo'] ? 'Ativo' : 'Inativo';
                    ?>
                        <div class="barbeiro-card">
                            <div class="barbeiro-header">
                                <img class="barbeiro-avatar" src="<?php echo $foto; ?>" alt="Barbeiro">
                                <div class="barbeiro-info">
                                    <div class="nome"><?php echo $barbeiro['nome']; ?></div>
                                    <div class="email"><?php echo $barbeiro['email']; ?></div>
                                </div>
                                <span class="barbeiro-status <?php echo $statusClass; ?>"><?php echo $statusText; ?></span>
                            </div>
                            <div class="barbeiro-detalhes">
                                <?php if ($barbeiro['telefone']): ?>
                                    <span><?php echo $barbeiro['telefone']; ?></span>
                                <?php endif; ?>
                                <?php if ($barbeiro['especialidades']): ?>
                                    <span><?php echo $barbeiro['especialidades']; ?></span>
                                <?php endif; ?>
                            </div>
                            <div class="barbeiro-acoes">
                                <button class="btn-edit" onclick="editarBarbeiro(<?php echo $barbeiro['id']; ?>)">
                                    <i class="fas fa-edit"></i> Editar
                                </button>
                                <button class="btn-reset" onclick="resetarSenhaBarbeiro(<?php echo $barbeiro['id']; ?>)">
                                    <i class="fas fa-key"></i> Resetar
                                </button>
                                <button class="btn-delete" onclick="deletarBarbeiro(<?php echo $barbeiro['id']; ?>)">
                                    <i class="fas fa-trash"></i> Excluir
                                </button>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>

        <!-- SECTION: SERVIÇOS -->
        <div id="section-servicos" class="section-content">
            <div class="card">
                <div class="card-header">
                    <h3>Serviços</h3>
                    <div class="card-actions">
                        <button onclick="location.reload()"><i class="fas fa-sync"></i> Atualizar</button>
                    </div>
                </div>
                <div id="servicos-content">
                    <div class="loading">
                        <div class="spinner"></div>
                        <p>Carregando...</p>
                    </div>
                </div>
            </div>
        </div>

        <!-- SECTION: RELATÓRIOS -->
        <div id="section-relatorios" class="section-content">
            <!-- Faturamento por Barbeiro -->
            <div class="card">
                <div class="card-header">
                    <h3>Faturamento por Barbeiro (Mês Atual)</h3>
                </div>
                <div style="display:grid; grid-template-columns:repeat(auto-fill,minmax(250px,1fr)); gap:16px;">
                    <?php foreach ($relatorio_barbeiros as $barbeiro): 
                        $foto = $barbeiro['foto'] ?? 'https://ui-avatars.com/api/?name=' . urlencode($barbeiro['nome']) . '&background=c9a84c&color=0a0a0a&size=150&bold=true';
                    ?>
                        <div class="relatorio-card">
                            <div style="display:flex; align-items:center; gap:12px; margin-bottom:8px;">
                                <img src="<?php echo $foto; ?>" class="relatorio-barbeiro-foto" alt="Barbeiro">
                                <div>
                                    <div class="relatorio-nome"><?php echo $barbeiro['nome']; ?></div>
                                    <div class="relatorio-detalhe">
                                        <?php echo ($barbeiro['total_servicos'] ?? 0); ?> serviços | 
                                        <?php echo ($barbeiro['confirmados'] ?? 0); ?> confirmados | 
                                        <?php echo ($barbeiro['concluidos'] ?? 0); ?> concluídos
                                    </div>
                                </div>
                            </div>
                            <div class="relatorio-valor">R$ <?php echo number_format($barbeiro['faturamento'] ?? 0, 2, ',', '.'); ?></div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>

            <!-- Serviços Mais Populares -->
            <div class="card">
                <div class="card-header">
                    <h3>Serviços Mais Populares</h3>
                </div>
                <div style="display:grid; grid-template-columns:repeat(auto-fill,minmax(200px,1fr)); gap:12px;">
                    <?php foreach ($servicos_populares as $servico): ?>
                        <div style="background:rgba(10,10,10,0.6); padding:14px 16px; border-radius:10px; border-left:3px solid #c9a84c;">
                            <div style="font-weight:600; font-size:0.95em;"><?php echo $servico['nome']; ?></div>
                            <div style="display:flex; gap:12px; margin-top:6px; font-size:0.8em; color:#aaa;">
                                <span>Total: <strong style="color:#fff;"><?php echo $servico['total_agendamentos'] ?? 0; ?></strong></span>
                                <span>Confirmados: <strong style="color:#28a745;"><?php echo $servico['confirmados'] ?? 0; ?></strong></span>
                                <span>Concluídos: <strong style="color:#17a2b8;"><?php echo $servico['concluidos'] ?? 0; ?></strong></span>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>

            <!-- Agendamentos por Dia da Semana -->
            <div class="two-column">
                <div class="card">
                    <div class="card-header">
                        <h3>Agendamentos por Dia da Semana</h3>
                    </div>
                    <div style="display:grid; grid-template-columns:1fr 1fr; gap:10px;">
                        <?php foreach ($agendamentos_dia_semana as $dia): ?>
                            <div style="background:rgba(10,10,10,0.6); padding:12px 16px; border-radius:8px; text-align:center;">
                                <div style="font-weight:600; font-size:0.85em; color:#c9a84c;"><?php echo $dia['dia_nome']; ?></div>
                                <div style="font-size:1.2em; font-weight:700; color:#fff;"><?php echo $dia['total'] ?? 0; ?></div>
                                <div style="font-size:0.7em; color:#666;"><?php echo ($dia['confirmados'] ?? 0); ?> confirmados | <?php echo ($dia['concluidos'] ?? 0); ?> concluídos</div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>

                <div class="card">
                    <div class="card-header">
                        <h3>Faturamento Mensal</h3>
                    </div>
                    <div style="display:grid; grid-template-columns:1fr 1fr; gap:10px;">
                        <?php foreach ($faturamento_mensal as $mes): ?>
                            <div style="background:rgba(10,10,10,0.6); padding:12px 16px; border-radius:8px; text-align:center;">
                                <div style="font-weight:600; font-size:0.85em; color:#c9a84c;"><?php echo $mes['mes_nome']; ?></div>
                                <div style="font-size:1.1em; font-weight:700; color:#28a745;">R$ <?php echo number_format($mes['total_faturamento'] ?? 0, 2, ',', '.'); ?></div>
                                <div style="font-size:0.7em; color:#666;"><?php echo $mes['total_agendamentos'] ?? 0; ?> serviços</div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>

            <!-- Dias com Mais Agendamentos -->
            <div class="card">
                <div class="card-header">
                    <h3>Dias com Mais Agendamentos (Últimos 30 dias)</h3>
                </div>
                <div style="display:grid; grid-template-columns:repeat(auto-fill,minmax(150px,1fr)); gap:10px;">
                    <?php foreach ($dias_mais_agendamentos as $dia): ?>
                        <div style="background:rgba(10,10,10,0.6); padding:12px 16px; border-radius:8px; text-align:center; border-left:3px solid #c9a84c;">
                            <div style="font-weight:600; font-size:0.9em; color:#fff;"><?php echo $dia['data_formatada']; ?></div>
                            <div style="font-size:1.3em; font-weight:700; color:#c9a84c;"><?php echo $dia['total'] ?? 0; ?></div>
                            <div style="font-size:0.7em; color:#666;"><?php echo $dia['confirmados'] ?? 0; ?> confirmados</div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    </div>

    <!-- MODAL: BARBEIRO COM UPLOAD DE FOTO -->
    <div class="modal" id="modal-barbeiro">
        <div class="modal-content">
            <h2 id="modal-barbeiro-title">Novo Barbeiro</h2>
            <form id="barbeiro-form" enctype="multipart/form-data">
                <div class="form-group">
                    <label>Nome *</label>
                    <input type="text" id="barbeiro-nome" placeholder="Nome do barbeiro" required>
                </div>
                <div class="form-group">
                    <label>Email *</label>
                    <input type="email" id="barbeiro-email" placeholder="Email do barbeiro" required>
                </div>
                <div class="form-group">
                    <label>Senha</label>
                    <input type="password" id="barbeiro-senha" placeholder="Deixe em branco para manter a atual">
                    <span style="color:#666; font-size:0.75em;">Padrão: barbeiro123</span>
                </div>
                <div class="form-group">
                    <label>Telefone</label>
                    <input type="tel" id="barbeiro-telefone" placeholder="Telefone do barbeiro">
                </div>
                <div class="form-group">
                    <label>Especialidades</label>
                    <input type="text" id="barbeiro-especialidades" placeholder="Ex: Corte, Barba, Degradê">
                </div>
                
                <!-- Upload de Foto -->
                <div class="form-group">
                    <label>Foto do Barbeiro</label>
                    <div style="display:flex; gap:16px; align-items:flex-start; flex-wrap:wrap;">
                        <div style="position:relative;">
                            <img id="barbeiro-foto-preview" src="https://ui-avatars.com/api/?name=Barbeiro&background=c9a84c&color=0a0a0a&size=150&bold=true" class="barbeiro-foto-preview">
                            <div id="upload-status">✓ Enviado</div>
                        </div>
                        <div style="flex:1; min-width:200px;">
                            <!-- Campo de URL (mantido para compatibilidade) -->
                            <input type="text" id="barbeiro-foto" placeholder="URL da imagem (ou faça upload)" style="width:100%; padding:10px 14px; border-radius:10px; border:1.5px solid #2a2a2a; background:rgba(10,10,10,0.8); color:#fff; font-family:'Inter',sans-serif; margin-bottom:8px;">
                            
                            <!-- Botão de upload -->
                            <div style="display:flex; gap:8px; flex-wrap:wrap; align-items:center;">
                                <label for="foto-upload">
                                    <i class="fas fa-upload"></i> Escolher Imagem
                                </label>
                                <input type="file" id="foto-upload" accept="image/*" style="display:none;">
                                <button type="button" onclick="gerarAvatarBarbeiro()" style="padding:8px 18px; border:none; border-radius:8px; cursor:pointer; font-size:0.8em; font-weight:500; background:rgba(23,162,184,0.12); color:#17a2b8; font-family:'Inter',sans-serif; transition:all 0.3s;">
                                    <i class="fas fa-user-circle"></i> Avatar
                                </button>
                                <button type="button" onclick="limparFotoBarbeiro()" style="padding:8px 18px; border:none; border-radius:8px; cursor:pointer; font-size:0.8em; font-weight:500; background:rgba(220,53,69,0.1); color:#dc3545; font-family:'Inter',sans-serif; transition:all 0.3s;">
                                    <i class="fas fa-times"></i> Remover
                                </button>
                            </div>
                            <div style="margin-top:6px; font-size:0.65em; color:#555;">
                                Formatos: JPG, PNG, GIF, WEBP (máx. 5MB)
                            </div>
                            <div id="upload-progress">
                                <div style="height:4px; background:#2a2a2a; border-radius:2px; overflow:hidden;">
                                    <div id="upload-bar" style="height:100%; width:0%; background:linear-gradient(90deg, #c9a84c, #a8893a); border-radius:2px; transition:width 0.3s;"></div>
                                </div>
                                <span id="upload-text">Enviando...</span>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="form-group">
                    <label>Ativo</label>
                    <select id="barbeiro-ativo">
                        <option value="1">Sim</option>
                        <option value="0">Não</option>
                    </select>
                </div>
                <input type="hidden" id="barbeiro-id">
                <div class="modal-actions">
                    <button type="button" class="btn-primary" onclick="salvarBarbeiro()">Salvar</button>
                    <button type="button" class="btn-secondary" onclick="fecharModalBarbeiro()">Cancelar</button>
                </div>
            </form>
        </div>
    </div>

    <script>
    // ============================================
    // UTILITÁRIOS
    // ============================================
    function toggleSidebar() {
        document.getElementById('sidebar').classList.toggle('open');
    }

    function showSection(section) {
        document.querySelectorAll('.section-content').forEach(el => el.classList.remove('active'));
        const sectionEl = document.getElementById('section-' + section);
        if (sectionEl) sectionEl.classList.add('active');
        
        document.querySelectorAll('.sidebar-menu a').forEach(el => el.classList.remove('active'));
        document.querySelectorAll('.sidebar-menu a').forEach(el => {
            const text = el.textContent.toLowerCase().trim();
            if (text.includes(section.toLowerCase()) || 
                (section === 'dashboard' && text.includes('dashboard')) ||
                (section === 'historico' && text.includes('histórico'))) {
                el.classList.add('active');
            }
        });
        
        document.getElementById('sidebar').classList.remove('open');
        
        if (section === 'pagamentos') carregarPagamentos();
        if (section === 'servicos') carregarServicos();
    }

    function logout() {
        if (confirm('Tem certeza que deseja sair?')) {
            window.location.href = 'logout.php';
        }
    }

    function updateDateTime() {
        const now = new Date();
        const options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric', hour: '2-digit', minute: '2-digit' };
        document.getElementById('data-hora').textContent = now.toLocaleDateString('pt-BR', options);
    }
    setInterval(updateDateTime, 1000);
    updateDateTime();

    // ============================================
    // GRÁFICOS
    // ============================================
    let chartFaturamento = null;
    let chartStatus = null;

    function initCharts() {
        const faturamentoData = <?php echo json_encode(array_values($faturamento_semana_dados)); ?>;
        const labels = <?php echo json_encode($labels_semana_formatados); ?>;
        const ctx1 = document.getElementById('chartFaturamento').getContext('2d');
        chartFaturamento = new Chart(ctx1, {
            type: 'bar',
            data: {
                labels: labels,
                datasets: [{
                    label: 'Faturamento (R$)',
                    data: faturamentoData,
                    backgroundColor: 'rgba(201, 168, 76, 0.7)',
                    borderColor: '#c9a84c',
                    borderWidth: 2,
                    borderRadius: 4
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: { legend: { labels: { color: '#aaa', font: { size: 11 } } } },
                scales: {
                    y: { beginAtZero: true, ticks: { color: '#666', callback: function(v) { return 'R$ ' + v.toFixed(2); } }, grid: { color: 'rgba(255,255,255,0.03)' } },
                    x: { ticks: { color: '#666' }, grid: { display: false } }
                }
            }
        });

        const statusData = <?php echo json_encode(array_values($status_distribution)); ?>;
        const statusLabels = <?php echo json_encode(array_keys($status_distribution)); ?>;
        const statusColors = ['#17a2b8', '#ffc107', '#28a745', '#dc3545', '#6c757d'];
        const ctx2 = document.getElementById('chartStatus').getContext('2d');
        chartStatus = new Chart(ctx2, {
            type: 'doughnut',
            data: {
                labels: statusLabels,
                datasets: [{ data: statusData, backgroundColor: statusColors, borderColor: '#0a0a0a', borderWidth: 2 }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: { legend: { position: 'bottom', labels: { color: '#aaa', font: { size: 10 }, padding: 12 } } }
            }
        });
    }

    // ============================================
    // FILTROS
    // ============================================
    function filtrarAgendamentos(barbeiroId) {
        document.querySelectorAll('#agendamento-filters .filter-btn').forEach(btn => {
            btn.classList.remove('active');
            if (btn.dataset.barbeiro == barbeiroId) btn.classList.add('active');
        });
        if (barbeiroId === 'todos') {
            document.querySelectorAll('#agendamento-filters .filter-btn').forEach(btn => {
                if (btn.dataset.barbeiro === 'todos') btn.classList.add('active');
            });
        }
        document.querySelectorAll('.agendamentos-barbeiro').forEach(el => {
            if (barbeiroId === 'todos') {
                el.style.display = 'block';
            } else {
                el.style.display = el.dataset.barbeiro == barbeiroId ? 'block' : 'none';
            }
        });
    }

    function filtrarHistorico(barbeiroId) {
        document.querySelectorAll('#historico-filters .filter-btn').forEach(btn => {
            btn.classList.remove('active');
            if (btn.dataset.barbeiro == barbeiroId) btn.classList.add('active');
        });
        if (barbeiroId === 'todos') {
            document.querySelectorAll('#historico-filters .filter-btn').forEach(btn => {
                if (btn.dataset.barbeiro === 'todos') btn.classList.add('active');
            });
        }
        document.querySelectorAll('.historico-barbeiro').forEach(el => {
            if (barbeiroId === 'todos') {
                el.style.display = 'block';
            } else {
                el.style.display = el.dataset.barbeiro == barbeiroId ? 'block' : 'none';
            }
        });
    }

    // ============================================
    // PAGAMENTOS
    // ============================================
    function carregarPagamentos() {
        $('#pagamentos-content').html('<div class="loading"><div class="spinner"></div><p>Carregando...</p></div>');
        $.ajax({
            url: 'listar_pagamentos.php',
            type: 'POST',
            dataType: 'json',
            success: function(data) {
                if (data.error) {
                    $('#pagamentos-content').html('<p class="empty-message">' + data.error + '</p>');
                    return;
                }
                if (!data || data.length === 0) {
                    $('#pagamentos-content').html('<p class="empty-message">Nenhum pagamento pendente</p>');
                    return;
                }
                let html = '<div class="agendamentos-container">';
                data.forEach(function(item) {
                    html += '<div class="agendamento-item">' +
                        '<div class="info">' +
                            '<div class="data"><i class="fas fa-user"></i> ' + (item.cliente_nome || 'Cliente não informado') + '</div>' +
                            '<div class="servico">' + (item.servico_nome || 'Serviço não definido') + '</div>' +
                            '<div class="cliente">' + (item.cliente_email || 'Sem email') + '</div>' +
                        '</div>' +
                        '<span class="status-badge status-reservado">Pendente</span>' +
                        '<span class="valor">R$ ' + parseFloat(item.valor || 0).toFixed(2).replace('.', ',') + '</span>' +
                    '</div>';
                });
                html += '</div>';
                $('#pagamentos-content').html(html);
            },
            error: function() {
                $('#pagamentos-content').html('<p class="empty-message">Erro ao carregar pagamentos</p>');
            }
        });
    }

    // ============================================
    // SERVIÇOS
    // ============================================
    function carregarServicos() {
        $('#servicos-content').html('<div class="loading"><div class="spinner"></div><p>Carregando...</p></div>');
        $.ajax({
            url: 'listar_servicos_admin.php',
            type: 'POST',
            dataType: 'json',
            success: function(data) {
                if (data.error) {
                    $('#servicos-content').html('<p class="empty-message">' + data.error + '</p>');
                    return;
                }
                if (!data || data.length === 0) {
                    $('#servicos-content').html('<p class="empty-message">Nenhum serviço cadastrado</p>');
                    return;
                }
                let html = '<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(250px,1fr));gap:12px;">';
                data.forEach(function(s) {
                    html += '<div style="background:rgba(10,10,10,0.6);padding:14px 16px;border-radius:12px;border-left:3px solid ' + (s.cor || '#c9a84c') + ';">' +
                        '<div><strong>' + s.nome + '</strong></div>' +
                        '<div style="display:flex;gap:15px;margin-top:4px;font-size:0.85em;">' +
                            '<span style="color:#c9a84c;font-weight:700;">R$ ' + parseFloat(s.preco).toFixed(2).replace('.', ',') + '</span>' +
                            '<span style="color:#aaa;">' + s.duracao_minutos + ' min</span>' +
                        '</div>' +
                        (s.descricao ? '<div style="color:#666;font-size:0.8em;margin-top:4px;">' + s.descricao + '</div>' : '') +
                    '</div>';
                });
                html += '</div>';
                $('#servicos-content').html(html);
            },
            error: function() {
                $('#servicos-content').html('<p class="empty-message">Erro ao carregar serviços</p>');
            }
        });
    }

    // ============================================
    // UPLOAD DE FOTO DO BARBEIRO
    // ============================================
    var barbeiro_id_atual = 0;

    // Configurar o input de arquivo
    document.addEventListener('DOMContentLoaded', function() {
        const uploadInput = document.getElementById('foto-upload');
        if (uploadInput) {
            uploadInput.addEventListener('change', function(e) {
                if (this.files && this.files[0]) {
                    uploadFotoBarbeiro(this.files[0]);
                }
            });
        }
    });

    function uploadFotoBarbeiro(file) {
        // Verificar tipo de arquivo
        const tiposPermitidos = ['image/jpeg', 'image/png', 'image/jpg', 'image/gif', 'image/webp'];
        if (!tiposPermitidos.includes(file.type)) {
            alert('Formato de arquivo não permitido. Use JPG, PNG, GIF ou WEBP.');
            document.getElementById('foto-upload').value = '';
            return;
        }
        
        // Verificar tamanho (max 5MB)
        if (file.size > 5 * 1024 * 1024) {
            alert('Arquivo muito grande. Máximo 5MB.');
            document.getElementById('foto-upload').value = '';
            return;
        }
        
        // Mostrar preview
        const reader = new FileReader();
        reader.onload = function(e) {
            document.getElementById('barbeiro-foto-preview').src = e.target.result;
        };
        reader.readAsDataURL(file);
        
        // Mostrar progresso
        const progressDiv = document.getElementById('upload-progress');
        const progressBar = document.getElementById('upload-bar');
        const progressText = document.getElementById('upload-text');
        progressDiv.style.display = 'block';
        progressBar.style.width = '30%';
        progressText.textContent = 'Enviando...';
        
        // Obter ID do barbeiro
        const barbeiroId = document.getElementById('barbeiro-id').value || '0';
        
        // Criar FormData
        const formData = new FormData();
        formData.append('foto', file);
        formData.append('barbeiro_id', barbeiroId);
        formData.append('senha_admin', 'admin123');
        
        $.ajax({
            url: 'upload_foto_barbeiro.php',
            type: 'POST',
            data: formData,
            processData: false,
            contentType: false,
            xhr: function() {
                const xhr = new XMLHttpRequest();
                xhr.upload.addEventListener('progress', function(e) {
                    if (e.lengthComputable) {
                        const percent = Math.round((e.loaded / e.total) * 100);
                        progressBar.style.width = percent + '%';
                        progressText.textContent = 'Enviando... ' + percent + '%';
                    }
                });
                return xhr;
            },
            success: function(response) {
                try {
                    const data = typeof response === 'string' ? JSON.parse(response) : response;
                    progressBar.style.width = '100%';
                    progressText.textContent = 'Finalizado!';
                    
                    if (data.success) {
                        // Atualizar campo URL com o caminho da imagem
                        document.getElementById('barbeiro-foto').value = data.url;
                        
                        // Mostrar status de sucesso
                        const statusEl = document.getElementById('upload-status');
                        statusEl.style.display = 'block';
                        setTimeout(function() {
                            statusEl.style.display = 'none';
                        }, 3000);
                        
                        progressText.textContent = 'Upload concluído!';
                    } else {
                        alert('Erro: ' + data.message);
                        progressText.textContent = 'Falha no upload';
                        // Reverter preview
                        const nome = document.getElementById('barbeiro-nome').value.trim() || 'Barbeiro';
                        document.getElementById('barbeiro-foto-preview').src = 'https://ui-avatars.com/api/?name=' + encodeURIComponent(nome) + '&background=c9a84c&color=0a0a0a&size=150&bold=true';
                    }
                } catch (e) {
                    alert('Erro ao processar upload: ' + e.message);
                    progressText.textContent = 'Erro no upload';
                }
                
                setTimeout(function() {
                    progressDiv.style.display = 'none';
                    progressBar.style.width = '0%';
                }, 2000);
                
                // Resetar input
                document.getElementById('foto-upload').value = '';
            },
            error: function(jqXHR, textStatus, errorThrown) {
                alert('Erro ao enviar arquivo: ' + errorThrown);
                progressText.textContent = 'Erro no upload';
                document.getElementById('foto-upload').value = '';
                
                setTimeout(function() {
                    document.getElementById('upload-progress').style.display = 'none';
                    document.getElementById('upload-bar').style.width = '0%';
                }, 2000);
            }
        });
    }

    // ============================================
    // BARBEIROS - CRUD
    // ============================================
    function abrirModalBarbeiro() {
        document.getElementById('modal-barbeiro').classList.add('active');
        document.getElementById('modal-barbeiro-title').textContent = 'Novo Barbeiro';
        document.getElementById('barbeiro-form').reset();
        document.getElementById('barbeiro-id').value = '';
        document.getElementById('barbeiro-ativo').value = '1';
        document.getElementById('barbeiro-senha').value = '';
        document.getElementById('barbeiro-foto').value = '';
        document.getElementById('barbeiro-foto-preview').src = 'https://ui-avatars.com/api/?name=Barbeiro&background=c9a84c&color=0a0a0a&size=150&bold=true';
        document.getElementById('upload-status').style.display = 'none';
        document.getElementById('upload-progress').style.display = 'none';
        document.getElementById('foto-upload').value = '';
        barbeiro_id_atual = 0;
    }

    function fecharModalBarbeiro() {
        document.getElementById('modal-barbeiro').classList.remove('active');
    }

    function gerarAvatarBarbeiro() {
        const nome = document.getElementById('barbeiro-nome').value.trim() || 'Barbeiro';
        const avatarUrl = 'https://ui-avatars.com/api/?name=' + encodeURIComponent(nome) + '&background=c9a84c&color=0a0a0a&size=200&bold=true';
        document.getElementById('barbeiro-foto').value = avatarUrl;
        document.getElementById('barbeiro-foto-preview').src = avatarUrl;
    }

    function limparFotoBarbeiro() {
        document.getElementById('barbeiro-foto').value = '';
        const nome = document.getElementById('barbeiro-nome').value.trim() || 'Barbeiro';
        document.getElementById('barbeiro-foto-preview').src = 'https://ui-avatars.com/api/?name=' + encodeURIComponent(nome) + '&background=c9a84c&color=0a0a0a&size=150&bold=true';
    }

    document.addEventListener('input', function(e) {
        if (e.target.id === 'barbeiro-foto') {
            const url = e.target.value.trim();
            if (url) document.getElementById('barbeiro-foto-preview').src = url;
            else { const nome = document.getElementById('barbeiro-nome').value.trim() || 'Barbeiro'; document.getElementById('barbeiro-foto-preview').src = 'https://ui-avatars.com/api/?name=' + encodeURIComponent(nome) + '&background=c9a84c&color=0a0a0a&size=150&bold=true'; }
        }
        if (e.target.id === 'barbeiro-nome') {
            const foto = document.getElementById('barbeiro-foto').value.trim();
            if (!foto) { const nome = e.target.value.trim() || 'Barbeiro'; document.getElementById('barbeiro-foto-preview').src = 'https://ui-avatars.com/api/?name=' + encodeURIComponent(nome) + '&background=c9a84c&color=0a0a0a&size=150&bold=true'; }
        }
    });

    function editarBarbeiro(id) {
        $.ajax({
            url: 'buscar_barbeiro.php',
            type: 'POST',
            data: { id: id },
            dataType: 'json',
            success: function(barbeiro) {
                if (barbeiro.error) { alert(barbeiro.error); return; }
                
                barbeiro_id_atual = barbeiro.id;
                document.getElementById('barbeiro-id').value = barbeiro.id;
                
                document.getElementById('modal-barbeiro-title').textContent = 'Editar Barbeiro';
                document.getElementById('barbeiro-nome').value = barbeiro.nome;
                document.getElementById('barbeiro-email').value = barbeiro.email;
                document.getElementById('barbeiro-senha').value = '';
                document.getElementById('barbeiro-telefone').value = barbeiro.telefone || '';
                document.getElementById('barbeiro-especialidades').value = barbeiro.especialidades || '';
                document.getElementById('barbeiro-foto').value = barbeiro.foto || '';
                document.getElementById('barbeiro-ativo').value = barbeiro.ativo;
                
                const foto = barbeiro.foto || 'https://ui-avatars.com/api/?name=' + encodeURIComponent(barbeiro.nome) + '&background=c9a84c&color=0a0a0a&size=150&bold=true';
                document.getElementById('barbeiro-foto-preview').src = foto;
                document.getElementById('modal-barbeiro').classList.add('active');
                
                // Resetar status de upload
                document.getElementById('upload-status').style.display = 'none';
                document.getElementById('upload-progress').style.display = 'none';
                document.getElementById('foto-upload').value = '';
            },
            error: function() {
                alert('Erro ao buscar dados do barbeiro');
            }
        });
    }

    function salvarBarbeiro() {
        const data = {
            id: document.getElementById('barbeiro-id').value,
            nome: document.getElementById('barbeiro-nome').value.trim(),
            email: document.getElementById('barbeiro-email').value.trim(),
            senha: document.getElementById('barbeiro-senha').value,
            telefone: document.getElementById('barbeiro-telefone').value.trim(),
            especialidades: document.getElementById('barbeiro-especialidades').value.trim(),
            foto: document.getElementById('barbeiro-foto').value.trim(),
            ativo: document.getElementById('barbeiro-ativo').value,
            senha_admin: 'admin123'
        };
        if (!data.nome || !data.email) { alert('Nome e email são obrigatórios'); return; }
        
        $.ajax({
            url: 'salvar_barbeiro.php',
            type: 'POST',
            data: data,
            dataType: 'json',
            success: function(response) {
                if (response.success) {
                    alert(response.message);
                    fecharModalBarbeiro();
                    location.reload();
                } else {
                    alert(response.message);
                }
            },
            error: function() {
                alert('Erro ao salvar barbeiro');
            }
        });
    }

    function deletarBarbeiro(id) {
        if (!confirm('Tem certeza que deseja deletar este barbeiro?')) return;
        $.ajax({
            url: 'deletar_barbeiro.php',
            type: 'POST',
            data: { id: id, senha_admin: 'admin123' },
            dataType: 'json',
            success: function(response) {
                if (response.success) {
                    alert(response.message);
                    location.reload();
                } else {
                    alert(response.message);
                }
            },
            error: function() {
                alert('Erro ao deletar barbeiro');
            }
        });
    }

    function resetarSenhaBarbeiro(id) {
        if (!confirm('Resetar a senha para "barbeiro123"?')) return;
        $.ajax({
            url: 'salvar_barbeiro.php',
            type: 'POST',
            data: { id: id, senha: 'barbeiro123', senha_admin: 'admin123' },
            dataType: 'json',
            success: function(response) {
                if (response.success) {
                    alert('Senha resetada para: barbeiro123');
                } else {
                    alert(response.message);
                }
            },
            error: function() {
                alert('Erro ao resetar senha');
            }
        });
    }

    // ============================================
    // INICIALIZAÇÃO
    // ============================================
    $(document).ready(function() {
        showSection('dashboard');
        setTimeout(initCharts, 500);
        setTimeout(carregarPagamentos, 1000);
        setTimeout(carregarServicos, 1500);
        
        $('.modal').on('click', function(e) {
            if (e.target === this) $(this).removeClass('active');
        });
    });
    </script>
</body>
</html>
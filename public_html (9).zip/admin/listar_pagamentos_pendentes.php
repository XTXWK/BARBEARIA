<?php
include("../config.php");

$conn = new mysqli($db_host, $db_user, $db_password, $db_name);

if ($conn->connect_error) {
    die(json_encode(['error' => 'Erro de conexão: ' . $conn->connect_error]));
}

$sql = "SELECT p.*, s.nome as servico_nome 
        FROM pagamentos p
        LEFT JOIN servicos s ON p.servico_id = s.id
        WHERE p.status = 'pending'
        ORDER BY p.data_criacao DESC";

$result = $conn->query($sql);

if (!$result) {
    die(json_encode(['error' => 'Erro na consulta: ' . $conn->error]));
}

$pagamentos = [];
while ($row = $result->fetch_assoc()) {
    $pagamentos[] = $row;
}

$conn->close();

header('Content-Type: application/json');
echo json_encode($pagamentos);
?>
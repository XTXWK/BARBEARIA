<?php
session_start();
include("../config.php");

// Verificar autenticação
if (!isset($_SESSION['admin_logado']) && !isset($_COOKIE['admin_logado'])) {
    echo json_encode(['success' => false, 'message' => 'Não autenticado']);
    exit;
}

// Verificar se o arquivo foi enviado
if (!isset($_FILES['foto']) || $_FILES['foto']['error'] !== UPLOAD_ERR_OK) {
    echo json_encode(['success' => false, 'message' => 'Nenhum arquivo enviado ou erro no upload']);
    exit;
}

// Validar tipo de arquivo
$tipos_permitidos = ['image/jpeg', 'image/png', 'image/jpg', 'image/gif', 'image/webp'];
$extensoes_permitidas = ['jpg', 'jpeg', 'png', 'gif', 'webp'];

$arquivo = $_FILES['foto'];
$nome_original = $arquivo['name'];
$tipo = $arquivo['type'];
$tamanho = $arquivo['size'];
$tmp_nome = $arquivo['tmp_name'];

// Validar tipo MIME
if (!in_array($tipo, $tipos_permitidos)) {
    echo json_encode(['success' => false, 'message' => 'Tipo de arquivo não permitido. Use JPEG, PNG, GIF ou WEBP.']);
    exit;
}

// Validar extensão
$extensao = strtolower(pathinfo($nome_original, PATHINFO_EXTENSION));
if (!in_array($extensao, $extensoes_permitidas)) {
    echo json_encode(['success' => false, 'message' => 'Extensão de arquivo não permitida. Use .jpg, .jpeg, .png, .gif ou .webp.']);
    exit;
}

// Validar tamanho (max 5MB)
if ($tamanho > 5 * 1024 * 1024) {
    echo json_encode(['success' => false, 'message' => 'Arquivo muito grande. Máximo 5MB.']);
    exit;
}

// Verificar se é uma imagem válida
$imagem_info = getimagesize($tmp_nome);
if ($imagem_info === false) {
    echo json_encode(['success' => false, 'message' => 'Arquivo inválido. Não é uma imagem.']);
    exit;
}

// Criar diretório se não existir
$diretorio = '../img/barbeiros/';
if (!file_exists($diretorio)) {
    mkdir($diretorio, 0755, true);
}

// Gerar nome único para o arquivo
$barbeiro_id = isset($_POST['barbeiro_id']) ? intval($_POST['barbeiro_id']) : 0;
$novo_nome = 'barbeiro_' . $barbeiro_id . '_' . time() . '.' . $extensao;
$caminho_completo = $diretorio . $novo_nome;

// Mover arquivo
if (move_uploaded_file($tmp_nome, $caminho_completo)) {
    // URL da imagem para salvar no banco
    $url_imagem = 'img/barbeiros/' . $novo_nome;
    
    echo json_encode([
        'success' => true,
        'message' => 'Upload realizado com sucesso!',
        'url' => $url_imagem,
        'filename' => $novo_nome
    ]);
} else {
    echo json_encode(['success' => false, 'message' => 'Erro ao salvar o arquivo.']);
}
?>
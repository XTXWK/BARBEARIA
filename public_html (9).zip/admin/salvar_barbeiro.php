<?php
include("../config.php");

header('Content-Type: application/json');

$id = $_POST['id'] ?? 0;
$nome = $_POST['nome'] ?? '';
$email = $_POST['email'] ?? '';
$senha = $_POST['senha'] ?? '';
$telefone = $_POST['telefone'] ?? '';
$especialidades = $_POST['especialidades'] ?? '';
$foto = $_POST['foto'] ?? '';
$ativo = $_POST['ativo'] ?? 1;
$senha_admin = $_POST['senha_admin'] ?? '';

if ($senha_admin !== 'admin123') {
    echo json_encode(['success' => false, 'message' => 'Senha admin incorreta']);
    exit;
}

if (!$nome || !$email) {
    echo json_encode(['success' => false, 'message' => 'Nome e email são obrigatórios']);
    exit;
}

$conn = new mysqli($db_host, $db_user, $db_password, $db_name);

if ($conn->connect_error) {
    echo json_encode(['success' => false, 'message' => 'Erro de conexão: ' . $conn->connect_error]);
    exit;
}

// Verificar se email já existe
$sql = "SELECT id FROM barbeiros WHERE email = ? AND id != ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("si", $email, $id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    echo json_encode(['success' => false, 'message' => 'Email já cadastrado para outro barbeiro']);
    $conn->close();
    exit;
}

if ($id > 0) {
    // Atualizar
    if (!empty($senha)) {
        $senha_md5 = md5($senha);
        $sql = "UPDATE barbeiros SET 
                nome = ?, 
                email = ?, 
                senha = ?, 
                telefone = ?, 
                especialidades = ?, 
                foto = ?,
                ativo = ? 
                WHERE id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ssssssii", $nome, $email, $senha_md5, $telefone, $especialidades, $foto, $ativo, $id);
    } else {
        $sql = "UPDATE barbeiros SET 
                nome = ?, 
                email = ?, 
                telefone = ?, 
                especialidades = ?, 
                foto = ?,
                ativo = ? 
                WHERE id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("sssssii", $nome, $email, $telefone, $especialidades, $foto, $ativo, $id);
    }
} else {
    // Inserir novo
    $senha_md5 = md5($senha ?: 'barbeiro123');
    $sql = "INSERT INTO barbeiros (nome, email, senha, telefone, especialidades, foto, ativo) 
            VALUES (?, ?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssssssi", $nome, $email, $senha_md5, $telefone, $especialidades, $foto, $ativo);
}

if ($stmt->execute()) {
    echo json_encode(['success' => true, 'message' => 'Barbeiro salvo com sucesso']);
} else {
    echo json_encode(['success' => false, 'message' => 'Erro ao salvar: ' . $conn->error]);
}

$conn->close();
?>
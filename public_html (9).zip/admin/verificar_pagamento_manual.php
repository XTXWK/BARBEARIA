<?php
include("../config.php");

$reference = $_POST['ref'] ?? '';
$senha = $_POST['senha'] ?? '';

if ($senha !== 'admin123') {
    die(json_encode(['success' => false, 'message' => 'Senha incorreta']));
}

if (!$reference) {
    die(json_encode(['success' => false, 'message' => 'Referência não informada']));
}

$conn = new mysqli($db_host, $db_user, $db_password, $db_name);

if ($conn->connect_error) {
    die(json_encode(['success' => false, 'message' => 'Erro de conexão']));
}

$sql = "SELECT payment_id, servico_id, valor, cliente_nome, cliente_email, 
        cliente_telefone, data_agendada, horario_agendado, observacoes 
        FROM pagamentos 
        WHERE referencia = ? AND status = 'pending'";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $reference);
$stmt->execute();
$result = $stmt->get_result();
$pagamento = $result->fetch_assoc();

if (!$pagamento) {
    $conn->close();
    die(json_encode(['success' => false, 'message' => 'Pagamento não encontrado']));
}

$paymentId = $pagamento['payment_id'];

// Consultar status no Mercado Pago
$curl = curl_init();
curl_setopt_array($curl, [
    CURLOPT_URL => 'https://api.mercadopago.com/v1/payments/' . $paymentId,
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_CUSTOMREQUEST => 'GET',
    CURLOPT_HTTPHEADER => [
        'accept: application/json',
        'content-type: application/json',
        'Authorization: Bearer ' . $acess_token
    ]
]);

$response = curl_exec($curl);
$response_data = json_decode($response, true);
curl_close($curl);

$status = $response_data['status'] ?? '';

if ($status == "approved") {
    // Processar aprovação
    $data_agendada = $pagamento['data_agendada'];
    $horario_agendado = $pagamento['horario_agendado'];
    
    // Verificar se o horário existe
    $sql = "SELECT id, status FROM horarios WHERE data = ? AND horario = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $data_agendada, $horario_agendado);
    $stmt->execute();
    $result = $conn->query($sql);
    $horario = $result->fetch_assoc();
    
    if (!$horario) {
        // Criar o horário
        $sql = "INSERT INTO horarios (data, horario, status) VALUES (?, ?, 'disponivel')";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ss", $data_agendada, $horario_agendado);
        $stmt->execute();
        $horario_id = $conn->insert_id;
    } else {
        if ($horario['status'] != 'disponivel') {
            $conn->close();
            die(json_encode(['success' => false, 'message' => 'Horário não está mais disponível']));
        }
        $horario_id = $horario['id'];
    }
    
    // Reservar horário
    $sql = "UPDATE horarios SET 
            status = 'pago',
            cliente_nome = ?,
            cliente_email = ?,
            cliente_telefone = ?,
            servico_id = ?,
            referencia_pagamento = ?,
            preco = ?,
            observacoes = ?
            WHERE id = ?";
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param(
        "sssisdsi",
        $pagamento['cliente_nome'],
        $pagamento['cliente_email'],
        $pagamento['cliente_telefone'],
        $pagamento['servico_id'],
        $reference,
        $pagamento['valor'],
        $pagamento['observacoes'],
        $horario_id
    );
    $stmt->execute();
    
    // Atualizar pagamento
    $sql = "UPDATE pagamentos SET status = 'approved', horario_id = ? WHERE referencia = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("is", $horario_id, $reference);
    $stmt->execute();
    
    $conn->close();
    echo json_encode(['success' => true, 'message' => 'Pagamento confirmado! Horário reservado.']);
} else {
    $conn->close();
    echo json_encode(['success' => false, 'message' => 'Pagamento ainda não aprovado. Status: ' . $status]);
}
?>
<?php
include("../config.php");

$id = $_POST['id'] ?? 0;

if (!$id) {
    die(json_encode(['error' => 'ID não informado']));
}

$conn = new mysqli($db_host, $db_user, $db_password, $db_name);

if ($conn->connect_error) {
    die(json_encode(['error' => 'Erro de conexão: ' . $conn->connect_error]));
}

$sql = "SELECT h.*, s.nome as servico_nome 
        FROM horarios h
        LEFT JOIN servicos s ON h.servico_id = s.id
        WHERE h.id = ?";

$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$agendamento = $result->fetch_assoc();

$conn->close();

if (!$agendamento) {
    die(json_encode(['error' => 'Agendamento não encontrado']));
}

header('Content-Type: application/json');
echo json_encode($agendamento);
?>
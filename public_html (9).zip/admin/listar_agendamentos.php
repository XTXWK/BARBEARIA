<?php
include("../config.php");

$conn = new mysqli($db_host, $db_user, $db_password, $db_name);

if ($conn->connect_error) {
    die(json_encode(['error' => 'Erro de conexão: ' . $conn->connect_error]));
}

// Buscar apenas horários pagos (agendados)
$sql = "SELECT 
            h.id,
            h.data,
            h.horario,
            h.status,
            h.cliente_nome,
            h.cliente_email,
            h.cliente_telefone,
            h.servico_id,
            h.referencia_pagamento,
            h.preco,
            h.observacoes,
            h.created_at,
            s.nome as servico_nome,
            b.nome as barbeiro_nome
        FROM horarios h
        LEFT JOIN servicos s ON h.servico_id = s.id
        LEFT JOIN barbeiros b ON h.barbeiro_id = b.id
        WHERE h.status = 'pago'
        ORDER BY h.data DESC, h.horario DESC";

$result = $conn->query($sql);

if (!$result) {
    die(json_encode(['error' => 'Erro na consulta: ' . $conn->error]));
}

$agendamentos = [];
while ($row = $result->fetch_assoc()) {
    $row['horario_formatado'] = substr($row['horario'], 0, 5);
    $agendamentos[] = $row;
}

$conn->close();

header('Content-Type: application/json');
echo json_encode($agendamentos);
?>
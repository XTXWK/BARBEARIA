<?php
include("../config.php");

$id = $_POST['id'] ?? 0;
$senha = $_POST['senha'] ?? '';

if ($senha !== 'admin123') {
    die(json_encode(['success' => false, 'message' => 'Senha incorreta']));
}

$conn = new mysqli($db_host, $db_user, $db_password, $db_name);

if ($conn->connect_error) {
    die(json_encode(['success' => false, 'message' => 'Erro de conexão']));
}

// Verificar se está disponível (só pode remover disponíveis)
$sql = "SELECT status FROM horarios WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$row = $result->fetch_assoc();

if (!$row) {
    die(json_encode(['success' => false, 'message' => 'Horário não encontrado']));
}

if ($row['status'] !== 'disponivel') {
    die(json_encode(['success' => false, 'message' => 'Não é possível remover um horário reservado, pago ou cancelado']));
}

$sql = "DELETE FROM horarios WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id);

if ($stmt->execute()) {
    echo json_encode(['success' => true, 'message' => 'Horário removido com sucesso']);
} else {
    echo json_encode(['success' => false, 'message' => 'Erro ao remover horário']);
}

$conn->close();
?>
<?php
include("../config.php");

$chave = $_POST['chave'] ?? '';
$valor = $_POST['valor'] ?? '';
$senha = $_POST['senha'] ?? '';

if ($senha !== 'admin123') {
    die(json_encode(['success' => false, 'message' => 'Senha incorreta']));
}

// Salvar em um arquivo de configuração
$config_file = '../config_custom.php';

$content = "<?php\n// Configurações personalizadas\n";

if ($chave === 'valor_padrao') {
    $valor = floatval($valor);
    $content .= "\$valor_padrao = $valor;\n";
} else if ($chave === 'senha_admin') {
    $content .= "\$senha_admin = '$valor';\n";
} else if ($chave === 'horario_funcionamento') {
    $content .= "\$horario_funcionamento = '$valor';\n";
} else {
    die(json_encode(['success' => false, 'message' => 'Chave inválida']));
}

$content .= "?>";

if (file_put_contents($config_file, $content)) {
    echo json_encode(['success' => true, 'message' => 'Configuração salva']);
} else {
    echo json_encode(['success' => false, 'message' => 'Erro ao salvar']);
}
?>
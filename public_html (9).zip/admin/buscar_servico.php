<?php
include("../config.php");

$id = $_POST['id'] ?? 0;

if (!$id) {
    die(json_encode(['error' => 'ID não informado']));
}

$conn = new mysqli($db_host, $db_user, $db_password, $db_name);

if ($conn->connect_error) {
    die(json_encode(['error' => 'Erro de conexão: ' . $conn->connect_error]));
}

$sql = "SELECT * FROM servicos WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$servico = $result->fetch_assoc();

$conn->close();

if (!$servico) {
    die(json_encode(['error' => 'Serviço não encontrado']));
}

header('Content-Type: application/json');
echo json_encode($servico);
?>
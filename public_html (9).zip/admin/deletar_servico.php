<?php
include("../config.php");

$id = $_POST['id'] ?? 0;
$senha = $_POST['senha'] ?? '';

if ($senha !== 'admin123') {
    die(json_encode(['success' => false, 'message' => 'Senha incorreta']));
}

$conn = new mysqli($db_host, $db_user, $db_password, $db_name);

if ($conn->connect_error) {
    die(json_encode(['success' => false, 'message' => 'Erro de conexão']));
}

// Verificar se o serviço tem agendamentos
$sql = "SELECT COUNT(*) as total FROM horarios WHERE servico_id = ? AND status != 'cancelado'";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$row = $result->fetch_assoc();

if ($row['total'] > 0) {
    // Apenas desativar
    $sql = "UPDATE servicos SET ativo = 0 WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id);
    $msg = "Serviço desativado (tem agendamentos)";
} else {
    // Deletar
    $sql = "DELETE FROM servicos WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id);
    $msg = "Serviço deletado";
}

if ($stmt->execute()) {
    echo json_encode(['success' => true, 'message' => $msg]);
} else {
    echo json_encode(['success' => false, 'message' => 'Erro ao deletar serviço']);
}

$conn->close();
?>
<?php
session_start();
session_destroy();
setcookie('admin_logado', '', time() - 3600, '/');
header('Location: dashboard_admin.php');
exit;
?>
<?php
include("config.php");

$curl = curl_init();

$webhook_data = [
    "url" => $notification_url,
    "events" => ["payment.created", "payment.updated"],
    "active" => true
];

curl_setopt_array($curl, [
    CURLOPT_URL => "https://api.mercadopago.com/webhooks",
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_CUSTOMREQUEST => "POST",
    CURLOPT_POSTFIELDS => json_encode($webhook_data),
    CURLOPT_HTTPHEADER => [
        "Authorization: Bearer " . $acess_token,
        "Content-Type: application/json"
    ]
]);

$response = curl_exec($curl);
$http_code = curl_getinfo($curl, CURLINFO_HTTP_CODE);
curl_close($curl);

echo "HTTP Code: $http_code\n";
echo "Resposta:\n";
print_r(json_decode($response, true));
?>